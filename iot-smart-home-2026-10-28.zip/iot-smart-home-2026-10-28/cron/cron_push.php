#!/usr/bin/php
<?php
require_once '/var/www/html/iot/config/iot_config.php';

/**
 * Cron скрипт для отправки push-уведомлений
 * Запускать каждую минуту
 * 
 * Особенности:
 * - Максимум 3 уведомления за один "цикл" срабатывания датчика
 * - Сброс счётчика при возврате датчика в норму (value = 0)
 * - Cooldown 30 секунд между уведомлениями
 * - Подробное логирование в /var/log/push_cron_debug.log
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Ошибка подключения: " . $e->getMessage());
}

// Логирование
$logFile = '/var/log/push_cron_debug.log';
file_put_contents($logFile, "\n=== " . date('Y-m-d H:i:s') . " ===\n", FILE_APPEND);

// Получаем активные правила с push
$stmt = $pdo->prepare("
    SELECT 
        id,
        name,
        trigger_topic,
        condition_type,
        condition_operator,
        condition_value,
        condition_script,
        push_topic,
        push_priority,
        cooldown_seconds,
        last_triggered,
        push_count
    FROM automations 
    WHERE enabled = 1 
    AND push_notify = 1
");
$stmt->execute();
$rules = $stmt->fetchAll(PDO::FETCH_ASSOC);

file_put_contents($logFile, "Найдено правил с push: " . count($rules) . "\n", FILE_APPEND);

foreach ($rules as $rule) {
    file_put_contents($logFile, "Проверяем правило: " . $rule['name'] . "\n", FILE_APPEND);
    
    // Проверка cooldown
    if ($rule['last_triggered'] && $rule['cooldown_seconds'] > 0) {
        $cooldown_time = strtotime($rule['last_triggered']) + $rule['cooldown_seconds'];
        if (time() < $cooldown_time) {
            file_put_contents($logFile, "  ⏳ В cooldown (осталось " . ($cooldown_time - time()) . " сек)\n", FILE_APPEND);
            continue;
        }
    }
    
    // Получаем последнее значение датчика
    if ($rule['trigger_topic']) {
        $stmt2 = $pdo->prepare("
            SELECT topic, value 
            FROM sensor_data 
            WHERE topic = ? 
            ORDER BY id DESC 
            LIMIT 1
        ");
        $stmt2->execute([$rule['trigger_topic']]);
        $sensor = $stmt2->fetch(PDO::FETCH_ASSOC);
        
        if ($sensor) {
            file_put_contents($logFile, "  Топик: " . $sensor['topic'] . " = " . substr($sensor['value'], 0, 100) . "\n", FILE_APPEND);
            
            // ПРОВЕРКА УСЛОВИЯ (поддерживает simple и script)
            $condition_met = false;
            
            if ($rule['condition_type'] === 'script' && $rule['condition_script']) {
                // --- СКРИПТОВОЕ УСЛОВИЕ ---
                try {
                    // Парсим JSON, если value это JSON
                    $sensorData = json_decode($sensor['value'], true);
                    if ($sensorData === null) {
                        // Если не JSON, используем как есть
                        $sensorData = ['value' => $sensor['value']];
                    }
                    
                    // Безопасное выполнение скрипта
                    $script = $rule['condition_script'];
                    // Заменяем sensor.xxx на $sensorData['xxx']
                    $script = preg_replace('/sensor\.([a-zA-Z0-9_]+)/', '$sensorData["$1"]', $script);
                    $script = preg_replace('/data/', '$sensor["value"]', $script);
                    
                    // Проверяем на запрещённые функции
                    $forbidden = ['eval', 'exec', 'system', 'shell_exec', 'passthru', 'assert', 'include', 'require'];
                    foreach ($forbidden as $word) {
                        if (stripos($script, $word) !== false) {
                            throw new Exception("Запрещённая функция: " . $word);
                        }
                    }
                    
                    // Выполняем
                    $result = eval("return (" . $script . ");");
                    $condition_met = (bool)$result;
                    
                    file_put_contents($logFile, "  Скрипт: " . $script . " = " . ($condition_met ? 'true' : 'false') . "\n", FILE_APPEND);
                } catch (Exception $e) {
                    file_put_contents($logFile, "  ❌ Ошибка скрипта: " . $e->getMessage() . "\n", FILE_APPEND);
                    continue;
                }
            } else {
                // --- ПРОСТОЕ УСЛОВИЕ ---
                try {
                    $value = (float)$sensor['value'];
                    $threshold = (float)$rule['condition_value'];
                    
                    switch ($rule['condition_operator']) {
                        case '>': $condition_met = $value > $threshold; break;
                        case '<': $condition_met = $value < $threshold; break;
                        case '>=': $condition_met = $value >= $threshold; break;
                        case '<=': $condition_met = $value <= $threshold; break;
                        case '==': $condition_met = $value == $threshold; break;
                        default: $condition_met = false;
                    }
                    
                    file_put_contents($logFile, "  Условие: " . $value . " " . $rule['condition_operator'] . " " . $threshold . " = " . ($condition_met ? 'true' : 'false') . "\n", FILE_APPEND);
                } catch (Exception $e) {
                    file_put_contents($logFile, "  ❌ Ошибка сравнения: " . $e->getMessage() . "\n", FILE_APPEND);
                    continue;
                }
            }
            
            // --- ЕСЛИ УСЛОВИЕ ВЫПОЛНЕНО ---
            if ($condition_met) {
                // Проверяем счётчик отправок (максимум 3)
                $push_count = (int)$rule['push_count'];
                if ($push_count >= 3) {
                    file_put_contents($logFile, "  ⛔ Достигнут лимит (3), уведомление не отправлено\n", FILE_APPEND);
                    continue;
                }
                
                $push_topic = $rule['push_topic'] ?: 'iot-alerts';
                $priority = $rule['push_priority'] ?: 'high';
                
                $command = sprintf(
                    "cd /var/www/html/iot && ./venv/bin/python push_sender.py %d '%s' '%s' %.2f '%s' '%s' 2>&1",
                    $rule['id'],
                    addslashes($rule['name']),
                    $sensor['topic'],
                    $sensor['value'],
                    $push_topic,
                    $priority
                );
                
                file_put_contents($logFile, "  🚀 Отправка (" . ($push_count + 1) . "/3): " . $command . "\n", FILE_APPEND);
                
                exec($command, $output, $return_code);
                
                if ($return_code === 0) {
                    // Увеличиваем счётчик
                    $stmt3 = $pdo->prepare("
                        UPDATE automations 
                        SET last_triggered = NOW(), push_count = push_count + 1 
                        WHERE id = ?
                    ");
                    $stmt3->execute([$rule['id']]);
                    
                    // Логируем в automation_log
                    $stmt4 = $pdo->prepare("
                        INSERT INTO automation_log 
                        (automation_id, action, status, trigger_value) 
                        VALUES (?, 'push_notification', 'sent', ?)
                    ");
                    $stmt4->execute([$rule['id'], $sensor['value']]);
                    
                    file_put_contents($logFile, "  ✅ Уведомление отправлено!\n", FILE_APPEND);
                } else {
                    file_put_contents($logFile, "  ❌ Ошибка отправки: " . implode("\n", $output) . "\n", FILE_APPEND);
                }
            } else {
                // --- ЕСЛИ УСЛОВИЕ НЕ ВЫПОЛНЕНО (датчик в норме) ---
                // Сбрасываем счётчик, чтобы при следующем срабатывании снова было 3 уведомления
                if ($rule['push_count'] > 0) {
                    $stmt5 = $pdo->prepare("
                        UPDATE automations 
                        SET push_count = 0 
                        WHERE id = ?
                    ");
                    $stmt5->execute([$rule['id']]);
                    file_put_contents($logFile, "  🔄 Счётчик сброшен (датчик в норме)\n", FILE_APPEND);
                }
            }
        } else {
            file_put_contents($logFile, "  ⚠️ Нет данных для топика: " . $rule['trigger_topic'] . "\n", FILE_APPEND);
        }
    } else {
        file_put_contents($logFile, "  ⚠️ Нет trigger_topic\n", FILE_APPEND);
    }
}

echo "✅ Push проверка завершена\n";
?>
