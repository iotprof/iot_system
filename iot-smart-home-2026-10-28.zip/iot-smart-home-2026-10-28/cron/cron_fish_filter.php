#!/usr/bin/php
<?php
require_once '/var/www/html/iot/config/iot_config.php';

/**
 * Управление светом у рыбок (state_l4)
 * Cron: 0 8 * * * /usr/bin/php /var/www/html/iot/cron_fish_light.php >> /var/log/fish-light.log 2>&1
 *       0 23 * * * /usr/bin/php /var/www/html/iot/cron_fish_light.php >> /var/log/fish-light.log 2>&1
 */

$pdo = iot_pdo();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Настройки
$commandTopic = "zigbee2mqtt/fish_power/set";
$stateTopic = "zigbee2mqtt/fish_power";
// ИСПРАВЛЕНО 29.09.2026: раньше здесь брались учётные данные АДМИНИСТРАТОРА БАЗЫ
// (IOT_DB_ADMIN_*) и передавались в mosquitto_pub. Брокер их не знает — в логе было
// "Connection Refused: not authorised", команда уходила без авторизации.
// Для MQTT есть отдельная служебная учётка — секция [mqtt] в /etc/iot/credentials.ini.
$user = IOT_MQTT_USER;
$pass = IOT_MQTT_PASS;
$maxAttempts = 5;
$waitSeconds = 3;
$emailTo = 'user@example.com';

// Определяем действие по времени
$hour = date('H');
$action = '';
$actionName = '';

if ($hour == 7) {
    $action = 'ON';
    $actionName = 'Включение';
    $lightState = ' ВКЛЮЧАЕМ';
} elseif ($hour == 1) {
    $action = 'OFF';
    $actionName = 'Выключение';
    $lightState = ' ВЫКЛЮЧАЕМ';
} else {
    exit;
}

function sendCommand($topic, $payload, $user, $pass) {
    $cmd = "/usr/bin/mosquitto_pub -h 127.0.0.1 -p 1883 -u $user -P $pass -t " . escapeshellarg($topic) . " -m " . escapeshellarg($payload) . " 2>&1";
    return shell_exec($cmd);
}

function getLightState($pdo, $stateTopic) {
    $stmt = $pdo->prepare("SELECT value, timestamp FROM sensor_data WHERE topic = ? ORDER BY timestamp DESC LIMIT 1");
    $stmt->execute([$stateTopic]);
    $state = $stmt->fetch();
    
    if ($state) {
        $data = json_decode($state['value'], true);
        $timestamp = strtotime($state['timestamp']);
        $now = time();
        $age = $now - $timestamp;
        
        return [
            'state' => $data['state_l4'] ?? 'unknown',
            'timestamp' => $state['timestamp'],
            'age_seconds' => $age,
            'fresh' => ($age < 30)
        ];
    }
    
    return ['state' => 'unknown', 'timestamp' => null, 'age_seconds' => 999, 'fresh' => false];
}

echo "\n" . str_repeat("=", 60) . "\n";
echo date('Y-m-d H:i:s') . " - $lightState фильтр рыбкам\n";

// Проверяем, не выполняли ли уже действие в этот час
$stmt = $pdo->prepare("
    SELECT COUNT(*) as done FROM email_triggers 
    WHERE rule_name = 'fish_filter' 
    AND trigger_value = ?
    AND DATE(triggered_at) = CURDATE()
    AND HOUR(triggered_at) = HOUR(NOW())
");
$stmt->execute([$action]);
$alreadyDone = $stmt->fetch();

if ($alreadyDone['done'] > 0) {
    echo "⚠️ ФИльтр уже был {$actionName} в этот час! Пропускаем.\n";
    exit;
}

// Текущее состояние до команды
$stateBefore = getLightState($pdo, $stateTopic);
echo "Состояние ДО: state_l4 = {$stateBefore['state']} (данные: {$stateBefore['age_seconds']} сек)\n";

// Если уже в нужном состоянии — выходим
if ($stateBefore['state'] == $action) {
    echo "✅ ФИльтр уже в нужном состоянии: {$action}\n";
    exit;
}

// Отправляем команду
$payload = json_encode(['state_l4' => $action]);
echo "📢 Команда: $commandTopic = $payload\n";
sendCommand($commandTopic, $payload, $user, $pass);

// Проверяем подтверждение
$confirmed = false;
$lastState = null;

for ($i = 1; $i <= $maxAttempts; $i++) {
    echo "Проверка $i из $maxAttempts (ждём {$waitSeconds} сек)...\n";
    sleep($waitSeconds);
    
    $state = getLightState($pdo, $stateTopic);
    $actualState = $state['state'];
    $fresh = $state['fresh'] ? "свежие" : "старые";
    $lastState = $actualState;
    
    echo "   Текущее состояние: state_l4 = $actualState (данные $fresh, {$state['age_seconds']} сек)\n";
    
    if ($actualState == $action && $state['fresh']) {
        $confirmed = true;
        echo "✅ $actionName ПОДТВЕРЖДЕНО!\n";
        break;
    }
    
    if ($i < $maxAttempts && $actualState != $action) {
        echo "   🔄 Повторная отправка команды...\n";
        sendCommand($commandTopic, $payload, $user, $pass);
    }
}

// Итог
if ($confirmed) {
    echo "✅✅✅ фильтре успешно " . ($action == 'ON' ? "включён" : "выключен") . "!\n";
    
    $stmt = $pdo->prepare("
        INSERT INTO email_triggers (rule_name, recipient, trigger_topic, trigger_value, sent) 
        VALUES ('fish_filter', 'system', ?, ?, 1)
    ");
    $stmt->execute([$commandTopic, $action]);
    
} else {
    echo "❌❌❌ НЕ ДОЖДАЛИСЬ ПОДТВЕРЖДЕНИЯ!\n";
    echo "Последнее известное состояние state_l4: " . ($lastState ?? 'нет данных') . "\n";
    
    // Финальная попытка
    sendCommand($commandTopic, $payload, $user, $pass);
    sleep(3);
    
    $finalState = getLightState($pdo, $stateTopic);
    if ($finalState['state'] == $action) {
        echo "✅ Финальная попытка сработала!\n";
    } else {
        $subject = "⚠️ Проблема с управлением светом рыбок";
        $body = "$actionName света не подтвердилось!\n";
        $body .= "Команда: $action\n";
        $body .= "Состояние ДО: {$stateBefore['state']}\n";
        $body .= "Состояние ПОСЛЕ: {$finalState['state']}\n";
        $body .= "Время: " . date('Y-m-d H:i:s');
        $headers = "From: it@example.com\r\n";
        mail($emailTo, $subject, $body, $headers);
        echo "📧 Уведомление отправлено\n";
    }
}

echo date('Y-m-d H:i:s') . " - 🐟 Завершено\n";
echo str_repeat("=", 60) . "\n";
