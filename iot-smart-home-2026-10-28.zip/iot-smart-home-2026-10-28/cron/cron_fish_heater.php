#!/usr/bin/php
<?php
require_once '/var/www/html/iot/config/iot_config.php';

/**
 * Управление нагревателем аквариума
 * Диапазон: 23-25°C
 * Использует историю для более точного контроля
 */

$pdo = iot_pdo();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Настройки
$tempTopic = "zigbee2mqtt/fish_reley_temp/temperature";
$commandTopic = "zigbee2mqtt/fish_power/set";
$stateTopic = "zigbee2mqtt/fish_power";
// ИСПРАВЛЕНО 29.09.2026: раньше здесь брались учётные данные АДМИНИСТРАТОРА БАЗЫ
// (IOT_DB_ADMIN_*) и передавались в mosquitto_pub. Брокер их не знает — в логе было
// "Connection Refused: not authorised", команда уходила без авторизации.
// Для MQTT есть отдельная служебная учётка — секция [mqtt] в /etc/iot/credentials.ini.
$user = IOT_MQTT_USER;
$pass = IOT_MQTT_PASS;
$minTemp = 23;
$maxTemp = 25;
$emailTo = 'user@example.com';
$timeWindow = 15; // минут для анализа

function sendCommand($topic, $payload, $user, $pass) {
    $cmd = "/usr/bin/mosquitto_pub -h 127.0.0.1 -p 1883 -u $user -P $pass -t " . escapeshellarg($topic) . " -m " . escapeshellarg($payload) . " 2>&1";
    return shell_exec($cmd);
}

function getHeaterState($pdo, $stateTopic) {
    // Получаем последнее состояние из sensor_data (быстро)
    $stmt = $pdo->prepare("SELECT value FROM sensor_data WHERE topic = ? ORDER BY timestamp DESC LIMIT 1");
    $stmt->execute([$stateTopic]);
    $state = $stmt->fetch();
    if ($state) {
        $data = json_decode($state['value'], true);
        return $data['state_l3'] ?? 'unknown';
    }
    return 'unknown';
}

function getAverageTemperature($pdo, $tempTopic, $minutes) {
    // СРЕДНЯЯ температура за последние N минут (сглаживание)
    $stmt = $pdo->prepare("
        SELECT 
            AVG(CAST(value AS DECIMAL(5,2))) as avg_temp,
            MIN(CAST(value AS DECIMAL(5,2))) as min_temp,
            MAX(CAST(value AS DECIMAL(5,2))) as max_temp,
            COUNT(*) as readings,
            MAX(timestamp) as last_time
        FROM sensor_history 
        WHERE topic = ? 
        AND timestamp > DATE_SUB(NOW(), INTERVAL ? MINUTE)
    ");
    $stmt->execute([$tempTopic, $minutes]);
    $result = $stmt->fetch();
    
    if ($result && $result['readings'] > 0) {
        return [
            'avg' => round($result['avg_temp'], 1),
            'min' => $result['min_temp'],
            'max' => $result['max_temp'],
            'count' => $result['readings'],
            'last_time' => $result['last_time']
        ];
    }
    return null;
}

echo "\n============================================================\n";
echo date('Y-m-d H:i:s') . " - 🌡️ ПРОВЕРКА НАГРЕВАТЕЛЯ\n";

// Получаем среднюю температуру за последние 15 минут
$tempData = getAverageTemperature($pdo, $tempTopic, $timeWindow);
if (!$tempData) {
    echo "⚠️ Нет данных о температуре за последние $timeWindow минут\n";
    exit;
}

$avgTemp = $tempData['avg'];
$minTempActual = $tempData['min'];
$maxTempActual = $tempData['max'];
$currentState = getHeaterState($pdo, $stateTopic);

echo "Температура (средняя за {$timeWindow} мин): {$avgTemp}°C\n";
echo "  - Минимальная: {$minTempActual}°C\n";
echo "  - Максимальная: {$maxTempActual}°C\n";
echo "  - Замеров: {$tempData['count']}\n";
echo "Нагреватель: " . ($currentState == 'ON' ? 'ВКЛЮЧЕН' : 'ВЫКЛЮЧЕН') . "\n";

$action = null;
$reason = "";

// Используем СРЕДНЮЮ температуру для принятия решения
if ($avgTemp <= $minTemp && $currentState != 'ON') {
    $action = 'ON';
    $reason = "средняя температура {$avgTemp}°C ≤ {$minTemp}°C (мин: {$minTempActual}°C)";
} elseif ($avgTemp >= $maxTemp && $currentState != 'OFF') {
    $action = 'OFF';
    $reason = "средняя температура {$avgTemp}°C ≥ {$maxTemp}°C (макс: {$maxTempActual}°C)";
}

if ($action) {
    echo "📢 Команда: " . ($action == 'ON' ? 'ВКЛЮЧИТЬ' : 'ВЫКЛЮЧИТЬ') . " - $reason\n";
    
    // Отправляем команду
    $payload = json_encode(['state_l3' => $action]);
    $output = sendCommand($commandTopic, $payload, $user, $pass);
    if ($output) {
        echo "   Ответ MQTT: $output\n";
    }
    
    // Проверяем несколько раз с задержкой
    $confirmed = false;
    for ($i = 1; $i <= 5; $i++) {
        sleep(3);
        $newState = getHeaterState($pdo, $stateTopic);
        echo "   Попытка $i: состояние = $newState\n";
        if ($newState == $action) {
            $confirmed = true;
            echo "✅ Успешно " . ($action == 'ON' ? 'включён' : 'выключен') . "\n";
            
            // Отправляем уведомление об успешном действии
            $subject = $action == 'ON' ? "🔥 Нагреватель включён" : "❄️ Нагреватель выключен";
            $body = "Температура: {$avgTemp}°C\nПричина: $reason";
            mail($emailTo, $subject, $body, "From: it@example.com\r\n");
            break;
        }
    }
    
    if (!$confirmed) {
        echo "❌ НЕ УДАЛОСЬ ПОДТВЕРДИТЬ ПОСЛЕ 5 ПОПЫТОК!\n";
        $subject = "⚠️ СРОЧНО: Проблема с нагревателем!";
        $body = "Не удалось " . ($action == 'ON' ? 'включить' : 'выключить') . " нагреватель!\n";
        $body .= "Температура: средняя {$avgTemp}°C (мин: {$minTempActual}, макс: {$maxTempActual})\n";
        $body .= "Текущее состояние: $currentState\n";
        $body .= "Команда была: $action\n\n";
        $body .= "Проверь нагреватель вручную!";
        mail($emailTo, $subject, $body, "From: it@example.com\r\n");
    }
} else {
    echo "✅ Температура в норме (средняя {$avgTemp}°C, диапазон {$minTemp}-{$maxTemp}°C)\n";
}

echo date('Y-m-d H:i:s') . " - 🐟 ЗАВЕРШЕНО\n";
echo "============================================================\n";
