#!/usr/bin/php
<?php
require_once '/var/www/html/iot/config/iot_config.php';

/**
 * Скрипт для отправки email по правилам автоматизации
 * Проверяет таблицу automations и отправляет email если правило сработало
 * Cron: * * * * * /usr/bin/php /var/www/html/iot/cron_automation_emails.php >> /var/log/cron_automation_emails.log 2>&1
 */

try {
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("❌ Ошибка БД: " . $e->getMessage() . "\n");
}

// Проверяем, что таблица отметок о письмах есть и читается.
// ИСПРАВЛЕНО 12.10.2026: раньше здесь при каждом прогоне (раз в минуту!) выполнялся запрос
// «CREATE TABLE IF NOT EXISTS». Права CREATE у учётки сайта (iot_app) нет, а MariaDB проверяет
// права РАНЬШЕ, чем смотрит, существует ли таблица, — поэтому даже при живой таблице в лог
// каждую минуту летела ложная тревога «1142 CREATE command denied». Теперь наличие таблицы
// проверяется обычным чтением, а создаёт её администратор под root — готовый запрос лежит рядом:
// /var/www/html/iot/db/automation_email_sent.sql
try {
    $pdo->query('SELECT 1 FROM automation_email_sent LIMIT 1');
} catch (PDOException $e) {
    echo "⚠️ Таблицы automation_email_sent нет — рассылка пропущена, чтобы не слать письма повторно.\n";
    echo "   Создайте её под root: mysql iot_db < /var/www/html/iot/db/automation_email_sent.sql\n";
    exit(0);
}

// Настройки
$emailFrom = 'it@example.com'; // Ваш email отправителя
$checkMinutes = 60; // Проверяем за последний час

// Получаем все активные правила с email уведомлениями
$stmt = $pdo->prepare("
    SELECT * FROM automations 
    WHERE enabled = 1 
    AND email_notify = 1 
    AND email_recipient IS NOT NULL 
    AND email_recipient != ''
");
$stmt->execute();
$rules = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo date('Y-m-d H:i:s') . " - Проверка " . count($rules) . " правил с email\n";

foreach ($rules as $rule) {
    $ruleId = $rule['id'];
    $ruleName = $rule['name'];
    $recipient = $rule['email_recipient'];
    $hourKey = date('Y-m-d-H'); // Ключ для текущего часа (2024-01-15-14)
    
    // Проверяем, не отправляли ли уже письмо за этот час
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as sent 
        FROM automation_email_sent 
        WHERE rule_id = ? AND hour_key = ?
    ");
    $stmt->execute([$ruleId, $hourKey]);
    $alreadySent = $stmt->fetch()['sent'] > 0;
    
    if ($alreadySent) {
        echo "  ⏸️ [{$ruleName}] Письмо уже отправлено за этот час\n";
        continue;
    }
    
    // Проверяем срабатывания правила за последний час
    $triggers = [];
    
    if ($rule['schedule_type'] !== 'none') {
        // Для расписания - проверяем по last_triggered
        $lastTriggered = $rule['last_triggered'];
        if ($lastTriggered && strtotime($lastTriggered) > strtotime("-{$checkMinutes} minutes")) {
            $triggers[] = [
                'trigger_topic' => 'schedule',
                'trigger_value' => $rule['schedule_time'],
                'triggered_at' => $lastTriggered
            ];
        }
    } else {
        // Для триггерных правил - проверяем логи
        $stmt = $pdo->prepare("
            SELECT * FROM automation_log 
            WHERE rule_id = ? 
            AND skipped = 0
            AND triggered_at > DATE_SUB(NOW(), INTERVAL ? MINUTE)
            ORDER BY triggered_at DESC
        ");
        $stmt->execute([$ruleId, $checkMinutes]);
        $triggers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    if (count($triggers) > 0) {
        // Были срабатывания — отправляем email.
        // ИСПРАВЛЕНО 12.10.2026: убраны обрывки старого текста письма (в них оставалась
        // чужая строка «обнаружена протечка» и выводился payload действия вместо значения
        // датчика). Осталось только то, что действительно известно из базы.
        $triggerCount = count($triggers);
        $lastTrigger  = $triggers[0];

        $subject  = "Умный дом: сработало правило «{$ruleName}»";
        $message  = "Сработало правило автоматизации.\n\n";
        $message .= "Правило: {$ruleName}\n";
        $message .= "Время: " . date('Y-m-d H:i:s') . "\n";
        $message .= "Срабатываний за час: {$triggerCount}\n\n";

        if ($rule['schedule_type'] !== 'none') {
            $message .= "Тип: расписание, время " . substr((string)$rule['schedule_time'], 0, 5) . "\n";
            if ($rule['schedule_type'] === 'weekly' && !empty($rule['schedule_days'])) {
                $message .= "Дни: {$rule['schedule_days']}\n";
            }
        } else {
            $message .= "Датчик: {$rule['trigger_topic']}\n";
            if ($rule['condition_type'] === 'simple') {
                $message .= "Условие: {$rule['condition_operator']} {$rule['condition_value']}\n";
            }
            if (!empty($lastTrigger['actual_state'])) {
                $message .= "Состояние устройства: {$lastTrigger['actual_state']}\n";
            }
        }

        if (!empty($rule['action_topic'])) {
            $message .= "\nДействие:\n  топик: {$rule['action_topic']}\n  команда: {$rule['action_payload']}\n";
        } else {
            $message .= "\nДействия по правилу нет — письмо только уведомляет.\n";
        }
        if ((int)$rule['delay_seconds'] > 0) {
            $message .= "Задержка: {$rule['delay_seconds']} с\n";
        }
        $message .= "\nЗначения датчиков и полный журнал срабатываний — в панели, раздел «Журнал».\n";
        // Отправляем email
        $headers = "From: {$emailFrom}\r\n";
        $headers .= "Content-Type: text/plain; charset=utf-8\r\n";
        $subjectEncoded = '=?UTF-8?B?' . base64_encode($subject) . '?=';
        
        if (mail($recipient, $subjectEncoded, $message, $headers)) {
            // Записываем в лог отправки
            $stmt = $pdo->prepare("
                INSERT INTO automation_email_sent (rule_id, trigger_topic, trigger_value, recipient, hour_key)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $ruleId,
                $rule['trigger_topic'] ?? 'schedule',
                $lastTrigger['action_payload'] ?? $rule['schedule_time'],
                $recipient,
                $hourKey
            ]);
            
            echo "  ✅ [{$ruleName}] Email отправлен на {$recipient} (срабатываний: {$triggerCount})\n";
        } else {
            echo "  ❌ [{$ruleName}] Ошибка отправки email\n";
        }
    } else {
        echo "  ⏸️ [{$ruleName}] Нет срабатываний за последний час\n";
    }
}

// Очищаем старые записи (старше 7 дней)
$stmt = $pdo->prepare("DELETE FROM automation_email_sent WHERE sent_at < DATE_SUB(NOW(), INTERVAL 7 DAY)");
$stmt->execute();
echo "🧹 Очищено старых записей: " . $stmt->rowCount() . "\n";

echo date('Y-m-d H:i:s') . " - Готово\n";
?>
