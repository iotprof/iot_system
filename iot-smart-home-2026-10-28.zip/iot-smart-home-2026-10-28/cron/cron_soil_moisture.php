#!/usr/bin/php
<?php
require_once '/var/www/html/iot/config/iot_config.php';

/**
 * Скрипт для отправки email по влажности почвы (можжевельник)
 * Проверяет СРЕДНЮЮ влажность за последний час
 * Cron: 0 * * * * /usr/bin/php /var/www/html/iot/cron_soil_moisture.php >> /var/log/iot-soil.log 2>&1
 */

$pdo = iot_pdo();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Настройки
$moistureTopic = 'zigbee2mqtt/gorshok_big/humidity';
$emailTo = 'user@example.com';
$dryThreshold = 30;        // Ниже 30% - сухо
$checkMinutes = 60;        // Смотрим за последний час

// 1. Получаем СРЕДНЮЮ влажность за последний час из истории
$stmt = $pdo->prepare("
    SELECT 
        AVG(CAST(value AS DECIMAL(5,2))) as avg_moisture,
        MIN(value) as min_moisture,
        MAX(value) as max_moisture,
        COUNT(*) as readings_count,
        MAX(timestamp) as last_time
    FROM sensor_history 
    WHERE topic = ? 
    AND timestamp > DATE_SUB(NOW(), INTERVAL ? MINUTE)
");
$stmt->execute([$moistureTopic, $checkMinutes]);
$data = $stmt->fetch();

// Если нет данных за последний час
if (!$data || $data['readings_count'] == 0) {
    echo date('Y-m-d H:i:s') . " ⚠️ Нет данных за последний час по топику: $moistureTopic\n";
    exit;
}

$avgMoisture = round($data['avg_moisture'], 1);
$minMoisture = $data['min_moisture'];
$maxMoisture = $data['max_moisture'];

// 2. Проверяем, не отправляли ли уже сегодня письмо
$stmt = $pdo->prepare("
    SELECT COUNT(*) as sent FROM email_triggers 
    WHERE rule_name = 'soil_moisture' 
    AND DATE(triggered_at) = CURDATE()
");
$stmt->execute();
$sent = $stmt->fetch();

// 3. Если средняя влажность ниже порога и письмо ещё не отправляли сегодня
if ($avgMoisture < $dryThreshold && $sent['sent'] == 0) {
    
    // Определяем уровень сухости
    if ($avgMoisture < 10) $level = "🔥 КРИТИЧЕСКИ СУХО!!! СРОЧНО ПОЛИТЬ!";
    elseif ($avgMoisture < 20) $level = "⚠️ Очень сухо, нужно полить";
    elseif ($avgMoisture < 30) $level = "💧 Сухо, пора поливать";
    else $level = "✅ Нормально";
    
    $subject = "💧 Можжевельник хочет пить!";
    $message = "🌵 Можжевельник (gorshok_big):\n";
    $message .= "━━━━━━━━━━━━━━━━━━━━━━\n";
    $message .= "📊 Данные за последний час:\n";
    $message .= "• Средняя влажность: {$avgMoisture}%\n";
    $message .= "• Минимальная: {$minMoisture}%\n";
    $message .= "• Максимальная: {$maxMoisture}%\n";
    $message .= "• Количество замеров: {$data['readings_count']}\n";
    $message .= "• Последний замер: {$data['last_time']}\n\n";
    $message .= "🎯 Состояние: {$level}\n";
    $message .= "💧 Порог: ниже {$dryThreshold}%\n\n";
    $message .= "💡 Совет: полей растение и проверь через час.\n";
    $message .= "\n---\n🕐 Время проверки: " . date('Y-m-d H:i:s');
    
    $headers = "From: it@example.com\r\n";
    $headers .= "Content-Type: text/plain; charset=utf-8\r\n";
    
    if (mail($emailTo, $subject, $message, $headers)) {
        $stmt = $pdo->prepare("
            INSERT INTO email_triggers (rule_id, rule_name, recipient, trigger_topic, trigger_value, sent) 
            VALUES (0, 'soil_moisture', ?, ?, ?, 1)
        ");
        $stmt->execute([$emailTo, $moistureTopic, $avgMoisture]);
        
        echo date('Y-m-d H:i:s') . " ✅ Email отправлен (средняя влажность: {$avgMoisture}%, min: {$minMoisture}%)\n";
    } else {
        echo date('Y-m-d H:i:s') . " ❌ Ошибка отправки email\n";
    }
} elseif ($avgMoisture >= $dryThreshold) {
    echo date('Y-m-d H:i:s') . " 💚 Влажность в норме: средняя {$avgMoisture}% (≥ {$dryThreshold}%)\n";
} else {
    echo date('Y-m-d H:i:s') . " ⏸️ Письмо уже отправлено сегодня (средняя влажность: {$avgMoisture}%)\n";
}

// 4. Очищаем старые записи (старше 30 дней)
$deleted = $pdo->exec("DELETE FROM email_triggers WHERE triggered_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
if ($deleted > 0) {
    echo date('Y-m-d H:i:s') . " 🧹 Удалено старых записей: $deleted\n";
}
