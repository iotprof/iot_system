#!/usr/bin/php
<?php
require_once '/var/www/html/iot/config/iot_config.php';

/**
 * Кормушка для рыб - БЕЗОПАСНАЯ ВЕРСИЯ
 * Главное: убедиться, что кормушка ВЫКЛЮЧИЛАСЬ!
 * Если не выключилась - шлём СРОЧНОЕ уведомление и продолжаем попытки
 */

$pdo = iot_pdo();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$topic = "zigbee2mqtt/fish_power/set";
$stateTopic = "zigbee2mqtt/fish_power";
// ИСПРАВЛЕНО 29.09.2026: раньше здесь брались учётные данные АДМИНИСТРАТОРА БАЗЫ
// (IOT_DB_ADMIN_*) и передавались в mosquitto_pub. Брокер их не знает — в логе было
// "Connection Refused: not authorised", команда уходила без авторизации.
// Для MQTT есть отдельная служебная учётка — секция [mqtt] в /etc/iot/credentials.ini.
$user = IOT_MQTT_USER;
$pass = IOT_MQTT_PASS;
$feedSeconds = 2;           // Время работы кормушки
$maxRetries = 5;            // Максимум попыток выключения
$waitAfterCommand = 2;      // Секунд ждём после команды
$emailTo = 'user@example.com';
$emergencyPhone = 'user@example.com'; // Можно добавить SMS-шлюз

function sendCommand($topic, $payload, $user, $pass) {
    $cmd = "/usr/bin/mosquitto_pub -h 127.0.0.1 -p 1883 -u $user -P $pass -t " . escapeshellarg($topic) . " -m " . escapeshellarg($payload) . " 2>&1";
    return shell_exec($cmd);
}

function getStateL5($pdo, $stateTopic) {
    // Получаем состояние из sensor_data
    $stmt = $pdo->prepare("SELECT value, timestamp FROM sensor_data WHERE topic = ? ORDER BY timestamp DESC LIMIT 1");
    $stmt->execute([$stateTopic]);
    $state = $stmt->fetch();
    
    if ($state) {
        $data = json_decode($state['value'], true);
        $timestamp = strtotime($state['timestamp']);
        $now = time();
        $age = $now - $timestamp;
        
        return [
            'state' => $data['state_l5'] ?? 'unknown',
            'timestamp' => $state['timestamp'],
            'age_seconds' => $age,
            'fresh' => ($age < 10)  // Данные свежие если младше 10 секунд
        ];
    }
    return ['state' => 'unknown', 'timestamp' => null, 'age_seconds' => 999, 'fresh' => false];
}

function sendEmergencyAlert($subject, $message, $emailTo) {
    // Шлём несколько уведомлений для надёжности
    $headers = "From: it@example.com\r\n";
    $headers .= "X-Priority: 1\r\n";
    $headers .= "X-MSMail-Priority: High\r\n";
    
    mail($emailTo, $subject, $message, $headers);
    
    // Можно добавить Telegram бота
    // file_get_contents("https://api.telegram.org/bot<TOKEN>/sendMessage?chat_id=<CHAT_ID>&text=" . urlencode($message));
}

echo "\n" . str_repeat("=", 70) . "\n";
echo date('Y-m-d H:i:s') . " - 🐟 НАЧАЛО КОРМЛЕНИЯ\n";

// Проверяем, не кормили ли уже в этот час
$stmt = $pdo->prepare("
    SELECT COUNT(*) as sent FROM email_triggers 
    WHERE rule_name = 'fish_feeder' 
    AND DATE(triggered_at) = CURDATE()
    AND HOUR(triggered_at) = HOUR(NOW())
");
$stmt->execute();
$alreadyFed = $stmt->fetch();

if ($alreadyFed['sent'] > 0) {
    echo "⚠️ Кормление уже было в этот час! Пропускаем.\n";
    exit;
}

// Проверяем текущее состояние перед кормлением
$stateBefore = getStateL5($pdo, $stateTopic);
echo "Состояние ДО кормления: {$stateBefore['state']} (данные: {$stateBefore['age_seconds']} сек)\n";

if ($stateBefore['state'] == 'ON') {
    echo "⚠️⚠️⚠️ КОРМУШКА УЖЕ ВКЛЮЧЕНА! Возможно, зависла!\n";
    sendEmergencyAlert(
        "🚨 КРИТИЧЕСКАЯ ОШИБКА! Кормушка уже включена!",
        "Кормушка для рыб была включена до начала кормления!\n" .
        "Состояние: {$stateBefore['state']}\n" .
        "Время: " . date('Y-m-d H:i:s') . "\n" .
        "Попытка принудительно выключить...",
        $emailTo
    );
    
    // Пытаемся выключить
    sendCommand($topic, json_encode(['state_l5' => 'OFF']), $user, $pass);
    sleep(3);
}

// 1. ВКЛЮЧАЕМ КОРМУШКУ
$payloadOn = json_encode(['state_l5' => 'ON']);
echo "🔛 Включаем кормушку\n";
sendCommand($topic, $payloadOn, $user, $pass);

// Проверяем включение
sleep(2);
$stateOn = getStateL5($pdo, $stateTopic);
echo "   Состояние после включения: {$stateOn['state']}\n";

if ($stateOn['state'] != 'ON') {
    echo "⚠️ Не удалось подтвердить включение, но продолжаем...\n";
}

// 2. КОРМИМ
echo "⏳ Кормим рыбок {$feedSeconds} секунд...\n";
for ($i = 1; $i <= $feedSeconds; $i++) {
    echo "   ... $i сек\r";
    sleep(1);
}
echo "\n";

// 3. ВЫКЛЮЧАЕМ (САМОЕ ВАЖНОЕ!)
$payloadOff = json_encode(['state_l5' => 'OFF']);
echo "🔴 ВЫКЛЮЧАЕМ кормушку\n";
sendCommand($topic, $payloadOff, $user, $pass);

// 4. ПРОВЕРЯЕМ ВЫКЛЮЧЕНИЕ - МНОГОКРАТНО
$confirmed = false;
$emergencySent = false;

for ($attempt = 1; $attempt <= $maxRetries; $attempt++) {
    sleep($waitAfterCommand);
    
    $state = getStateL5($pdo, $stateTopic);
    $stateStr = $state['state'];
    $freshStr = $state['fresh'] ? "свежие" : "старые";
    
    echo "   Проверка $attempt/$maxRetries: состояние = {$stateStr} (данные {$freshStr}, {$state['age_seconds']} сек)\n";
    
    if ($stateStr == 'OFF' && $state['fresh']) {
        $confirmed = true;
        echo "✅✅✅ КОРМУШКА УСПЕШНО ВЫКЛЮЧЕНА! Рыбки в безопасности.\n";
        break;
    }
    
    if ($stateStr == 'OFF' && !$state['fresh']) {
        echo "   ⚠️ Состояние OFF, но данные старые. Отправляем повторную команду...\n";
        sendCommand($topic, $payloadOff, $user, $pass);
    } elseif ($stateStr != 'OFF') {
        echo "   ⚠️ Кормушка всё ещё {$stateStr}! Отправляем повторную команду...\n";
        sendCommand($topic, $payloadOff, $user, $pass);
    }
    
    // Если 3 попытки не удались - шлём СРОЧНОЕ уведомление
    if ($attempt == 3 && !$emergencySent) {
        $emergencySent = true;
        sendEmergencyAlert(
            "🚨🚨🚨 СРОЧНО! Кормушка не выключается!",
            "Кормушка для рыб НЕ ВЫКЛЮЧИЛАСЬ после 3 попыток!\n" .
            "Состояние: {$stateStr}\n" .
            "Время: " . date('Y-m-d H:i:s') . "\n\n" .
            "НЕОБХОДИМО РУЧНОЕ ВМЕШАТЕЛЬСТВО!\n" .
            "Рыбки могут объесться и погибнуть!",
            $emailTo
        );
        echo "   🚨 СРОЧНОЕ УВЕДОМЛЕНИЕ ОТПРАВЛЕНО!\n";
    }
}

// 5. ФИНАЛЬНЫЙ ИТОГ
if ($confirmed) {
    echo "✅✅✅ КОРМЛЕНИЕ ЗАВЕРШЕНО БЕЗОПАСНО!\n";
    
    $stmt = $pdo->prepare("
        INSERT INTO email_triggers (rule_id, rule_name, recipient, trigger_topic, trigger_value, sent) 
        VALUES (0, 'fish_feeder', ?, ?, 'success', 1)
    ");
    $stmt->execute([$emailTo, $topic]);
    
} else {
    echo "\n" . str_repeat("!", 70) . "\n";
    echo "❌❌❌ КРИТИЧЕСКАЯ ОШИБКА! КОРМУШКА НЕ ВЫКЛЮЧИЛАСЬ!\n";
    echo "❌❌❌ РЫБКИ В ОПАСНОСТИ! НЕОБХОДИМО РУЧНОЕ ВМЕШАТЕЛЬСТВО!\n";
    echo str_repeat("!", 70) . "\n";
    
    // Финальное СРОЧНОЕ уведомление
    sendEmergencyAlert(
        "🚨🚨🚨 КРИТИЧЕСКАЯ ОШИБКА! Кормушка НЕ ВЫКЛЮЧИЛАСЬ!",
        "⚠️⚠️⚠️ КОРМУШКА ДЛЯ РЫБ НЕ ВЫКЛЮЧИЛАСЬ ПОСЛЕ {$maxRetries} ПОПЫТОК! ⚠️⚠️⚠️\n\n" .
        "Это ОЧЕНЬ ОПАСНО для рыбок!\n" .
        "Они могут объесться и погибнуть!\n\n" .
        "НЕМЕДЛЕННО проверь кормушку и выключи вручную!\n" .
        "Аквариум: fish_power state_l5\n\n" .
        "Время: " . date('Y-m-d H:i:s'),
        $emailTo
    );
    
    // Записываем ошибку в лог
    $stmt = $pdo->prepare("
        INSERT INTO email_triggers (rule_id, rule_name, recipient, trigger_topic, trigger_value, sent) 
        VALUES (0, 'fish_feeder_error', ?, ?, 'FAILED', 1)
    ");
    $stmt->execute([$emailTo, $topic]);
}

echo date('Y-m-d H:i:s') . " - 🐟 КОРМЛЕНИЕ ЗАВЕРШЕНО\n";
echo str_repeat("=", 70) . "\n";
