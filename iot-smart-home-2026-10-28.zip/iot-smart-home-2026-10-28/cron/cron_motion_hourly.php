#!/usr/bin/php
<?php
require_once '/var/www/html/iot/config/iot_config.php';

/**
 * Скрипт для отправки email по движению (раз в час)
 * Считает РЕАЛЬНЫЕ движения (переход из 0 в 1)
 * Cron: 0 * * * * /usr/bin/php /var/www/html/iot/cron_motion_hourly.php >> /var/log/cron_motion.log 2>&1
 */

$pdo = iot_pdo();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Настройки
$motionTopic = 'zigbee2mqtt/motion_sensor/presence';
$emailTo = 'user@example.com';
$checkMinutes = 60; // Проверяем за последний час

// 1. Считаем РЕАЛЬНЫЕ движения (переход из 0 в 1)
$stmt = $pdo->prepare("
    SELECT COUNT(*) as real_motions
    FROM (
        SELECT 
            value,
            LAG(value) OVER (ORDER BY timestamp) as prev_value
        FROM sensor_history 
        WHERE topic = ? 
        AND timestamp > DATE_SUB(NOW(), INTERVAL ? MINUTE)
    ) as transitions
    WHERE value = '1' AND (prev_value = '0' OR prev_value IS NULL)
");
$stmt->execute([$motionTopic, $checkMinutes]);
$motion = $stmt->fetch();

// 2. Проверяем, не отправляли ли уже письмо за этот час
$stmt = $pdo->prepare("
    SELECT COUNT(*) as sent FROM email_triggers 
    WHERE rule_name = 'motion_hourly' 
    AND DATE(triggered_at) = CURDATE()
    AND HOUR(triggered_at) = HOUR(NOW())
");
$stmt->execute();
$sent = $stmt->fetch();

// 3. Если было движение и письмо ещё не отправляли
if ($motion['real_motions'] > 0 && $sent['sent'] == 0) {
    
    // Получаем детали для письма
    $stmt = $pdo->prepare("
        SELECT 
            MIN(timestamp) as first_motion,
            MAX(timestamp) as last_motion
        FROM sensor_history 
        WHERE topic = ? AND value = '1'
        AND timestamp > DATE_SUB(NOW(), INTERVAL ? MINUTE)
    ");
    $stmt->execute([$motionTopic, $checkMinutes]);
    $times = $stmt->fetch();
    
    $subject = "📡 Движение за последний час";
    $message = "За последние $checkMinutes минут:\n";
    $message .= "- Реальных движений: {$motion['real_motions']}\n";
    $message .= "- Первое движение: {$times['first_motion']}\n";
    $message .= "- Последнее движение: {$times['last_motion']}\n";
    $message .= "\nВремя проверки: " . date('Y-m-d H:i:s');
    
    $headers = "From: it@example.com\r\n";
    $headers .= "Content-Type: text/plain; charset=utf-8\r\n";
    
    if (mail($emailTo, $subject, $message, $headers)) {
        $stmt = $pdo->prepare("
            INSERT INTO email_triggers (rule_id, rule_name, recipient, trigger_topic, trigger_value, sent) 
            VALUES (0, 'motion_hourly', ?, ?, ?, 1)
        ");
        $stmt->execute([$emailTo, $motionTopic, $motion['real_motions']]);
        
        echo date('Y-m-d H:i:s') . " ✅ Email отправлен (реальных движений: {$motion['real_motions']})\n";
    } else {
        echo date('Y-m-d H:i:s') . " ❌ Ошибка отправки email\n";
    }
} else {
    if ($motion['real_motions'] == 0) {
        echo date('Y-m-d H:i:s') . " ⏸️ Движения не было\n";
    } else {
        echo date('Y-m-d H:i:s') . " ⏸️ Письмо уже отправлено за этот час\n";
    }
}
