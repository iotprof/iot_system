/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `anomaly_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `anomaly_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `watcher_id` int(11) NOT NULL,
  `kind` varchar(30) NOT NULL COMMENT 'limit_high|limit_low|spike|dip|no_data',
  `severity` varchar(10) NOT NULL DEFAULT 'warning' COMMENT 'info|warning|critical',
  `value` decimal(16,4) DEFAULT NULL,
  `baseline` decimal(16,4) DEFAULT NULL COMMENT 'Норма (медиана) на момент срабатывания',
  `deviation` decimal(16,4) DEFAULT NULL COMMENT 'Отклонение от нормы',
  `note` varchar(255) DEFAULT NULL,
  `detected_at` datetime DEFAULT current_timestamp(),
  `acknowledged` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_watcher_time` (`watcher_id`,`detected_at`),
  CONSTRAINT `anomaly_events_fk` FOREIGN KEY (`watcher_id`) REFERENCES `anomaly_watchers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `anomaly_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `anomaly_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `watcher_id` int(11) NOT NULL,
  `request_id` int(11) DEFAULT NULL,
  `provider` varchar(40) DEFAULT '',
  `model` varchar(80) DEFAULT '',
  `period_from` datetime DEFAULT NULL,
  `period_to` datetime DEFAULT NULL,
  `samples_used` int(11) DEFAULT 0,
  `events_used` int(11) DEFAULT 0,
  `summary` text DEFAULT NULL COMMENT 'Статистика по данным (считаем сами)',
  `response` mediumtext DEFAULT NULL COMMENT 'Ответ нейросети',
  `status` varchar(15) DEFAULT 'ok',
  `error` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_watcher_time` (`watcher_id`,`created_at`),
  CONSTRAINT `anomaly_reports_fk` FOREIGN KEY (`watcher_id`) REFERENCES `anomaly_watchers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `anomaly_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `anomaly_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `watcher_id` int(11) NOT NULL,
  `prompt` text DEFAULT NULL COMMENT 'Промпт на момент запроса (копия)',
  `status` varchar(15) DEFAULT 'pending' COMMENT 'pending|running|done|failed',
  `error` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `anomaly_requests_fk` (`watcher_id`),
  CONSTRAINT `anomaly_requests_fk` FOREIGN KEY (`watcher_id`) REFERENCES `anomaly_watchers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `anomaly_samples`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `anomaly_samples` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `watcher_id` int(11) NOT NULL,
  `value` decimal(16,4) NOT NULL,
  `taken_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_watcher_time` (`watcher_id`,`taken_at`),
  CONSTRAINT `anomaly_samples_fk` FOREIGN KEY (`watcher_id`) REFERENCES `anomaly_watchers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=297 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `anomaly_watchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `anomaly_watchers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL COMMENT 'Название карточки',
  `topic` varchar(255) NOT NULL COMMENT 'Топик-источник (в sensor_data)',
  `unit` varchar(20) DEFAULT '' COMMENT 'Единица измерения: V, W, °C ...',
  `enabled` tinyint(1) DEFAULT 1,
  `collect_interval` int(11) DEFAULT 60 COMMENT 'Как часто снимать значение, сек',
  `window_hours` int(11) DEFAULT 24 COMMENT 'Окно для расчёта нормы, часов',
  `min_samples` int(11) DEFAULT 20 COMMENT 'Сколько точек нужно, прежде чем искать аномалии',
  `limit_min` decimal(12,3) DEFAULT NULL COMMENT 'Жёсткий предел снизу',
  `limit_max` decimal(12,3) DEFAULT NULL COMMENT 'Жёсткий предел сверху',
  `spike_factor` decimal(6,2) DEFAULT 6.00 COMMENT 'Во сколько сигм считать выбросом',
  `cooldown_events` int(11) DEFAULT 900 COMMENT 'Не повторять однотипную аномалию чаще, сек',
  `gap_intervals` int(11) DEFAULT 3 COMMENT 'Пропуск данных больше N интервалов = аномалия',
  `prompt` text DEFAULT NULL COMMENT 'Промпт для нейросети',
  `ai_enabled` tinyint(1) DEFAULT 0,
  `ai_provider` varchar(40) DEFAULT '' COMMENT 'Пусто = взять из настроек',
  `ai_model` varchar(80) DEFAULT '',
  `status` varchar(20) DEFAULT 'collecting' COMMENT 'collecting|ready|analyzing',
  `started_at` datetime DEFAULT current_timestamp(),
  `last_sample_at` datetime DEFAULT NULL,
  `last_report_at` datetime DEFAULT NULL,
  `samples_count` int(11) DEFAULT 0,
  `notes` varchar(255) DEFAULT NULL,
  `notify_email` varchar(150) DEFAULT NULL COMMENT 'кому писать об аномалиях (пусто = никому)',
  `notify_min_severity` enum('info','warning','critical') DEFAULT 'critical' COMMENT 'с какой важности писать',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name` (`name`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `automation_email_sent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `automation_email_sent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_id` int(11) NOT NULL,
  `trigger_topic` varchar(255) DEFAULT NULL,
  `trigger_value` text DEFAULT NULL,
  `recipient` varchar(255) NOT NULL,
  `sent_at` timestamp NULL DEFAULT current_timestamp(),
  `hour_key` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rule_hour` (`rule_id`,`hour_key`),
  CONSTRAINT `automation_email_sent_ibfk_1` FOREIGN KEY (`rule_id`) REFERENCES `automations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `automation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `automation_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_id` int(11) DEFAULT NULL,
  `rule_name` varchar(255) NOT NULL,
  `action_topic` varchar(255) NOT NULL,
  `action_payload` text DEFAULT NULL,
  `triggered_at` timestamp NULL DEFAULT current_timestamp(),
  `skipped` tinyint(1) DEFAULT 0,
  `confirmed` tinyint(1) DEFAULT 0,
  `confirmed_at` datetime DEFAULT NULL,
  `expected_state` varchar(255) DEFAULT NULL,
  `actual_state` text DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `is_retry` tinyint(1) DEFAULT 0,
  `retry_count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rule_id` (`rule_id`),
  KEY `idx_triggered_at` (`triggered_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5803 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `automations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `automations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT 'Название правила',
  `group_name` varchar(64) DEFAULT NULL,
  `trigger_topic` varchar(255) NOT NULL COMMENT 'Топик-триггер',
  `condition_operator` enum('>','<','==','!=','>=','<=') DEFAULT NULL,
  `condition_value` varchar(50) DEFAULT NULL,
  `action_topic` varchar(255) NOT NULL COMMENT 'Топик для действия',
  `action_payload` text NOT NULL COMMENT 'Payload для отправки',
  `delay_seconds` int(11) DEFAULT 0,
  `cooldown_seconds` int(11) DEFAULT 30,
  `schedule_type` enum('none','daily','weekly','once') DEFAULT 'none',
  `schedule_time` time DEFAULT NULL COMMENT 'Время срабатывания (например, 19:00:00)',
  `schedule_days` set('mon','tue','wed','thu','fri','sat','sun') DEFAULT NULL COMMENT 'Дни недели для weekly',
  `enabled` tinyint(1) DEFAULT 1 COMMENT 'Активно ли правило',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `condition_duration` int(11) DEFAULT 0 COMMENT 'Условие должно соблюдаться N секунд (0 = мгновенно)',
  `hysteresis` float DEFAULT 0 COMMENT 'Гистерезис для исключения дребезга',
  `confirmation_topic` varchar(255) DEFAULT NULL COMMENT 'Топик для подтверждения выполнения',
  `confirmation_timeout` int(11) DEFAULT 30 COMMENT 'Таймаут ожидания подтверждения (сек)',
  `max_retries` int(11) DEFAULT 3 COMMENT 'Максимум попыток отправки, если нет подтверждения',
  `retry_delay` int(11) DEFAULT 5 COMMENT 'Задержка между попытками (сек)',
  `time_restriction_start` time DEFAULT NULL COMMENT 'Ограничение: не раньше этого времени',
  `time_restriction_end` time DEFAULT NULL COMMENT 'Ограничение: не позже этого времени',
  `dependency_topic` varchar(255) DEFAULT NULL COMMENT 'Топик-зависимость (например, окно открыто?)',
  `dependency_value` varchar(50) DEFAULT NULL COMMENT 'Значение зависимости (например, closed)',
  `last_triggered` timestamp NULL DEFAULT NULL COMMENT 'Когда последний раз сработало',
  `push_count` int(11) DEFAULT 0,
  `last_confirmed` timestamp NULL DEFAULT NULL COMMENT 'Когда последний раз подтвердилось',
  `failure_count` int(11) DEFAULT 0 COMMENT 'Сколько раз не подтвердилось',
  `condition_type` enum('simple','script') DEFAULT 'simple',
  `condition_script` text DEFAULT NULL COMMENT 'JS-подобное выражение для сложных условий',
  `in_progress` tinyint(1) DEFAULT 0 COMMENT 'Правило в процессе выполнения',
  `persistent` tinyint(1) DEFAULT 0 COMMENT 'Не удалять после выполнения (для повторяющихся задач)',
  `email_notify` tinyint(1) DEFAULT 0,
  `email_recipient` varchar(255) DEFAULT NULL,
  `email_condition_duration` int(11) DEFAULT 0,
  `push_notify` tinyint(1) DEFAULT 0,
  `push_topic` varchar(255) DEFAULT NULL,
  `push_priority` enum('low','high','urgent') DEFAULT 'high',
  `last_action_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_last_action` (`last_action_time`)
) ENGINE=InnoDB AUTO_INCREMENT=215 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `battery_spec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `battery_spec` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device` varchar(100) NOT NULL COMMENT 'friendly_name из zigbee2mqtt',
  `title` varchar(150) DEFAULT NULL COMMENT 'человеческое название для панели',
  `room` varchar(100) DEFAULT NULL,
  `battery_type` varchar(40) DEFAULT NULL COMMENT 'CR2032 / AAA / AA ...',
  `cells` tinyint(4) DEFAULT NULL COMMENT 'сколько элементов',
  `nominal_v` decimal(5,2) DEFAULT NULL COMMENT 'номинал всей батареи, В',
  `warn_v` decimal(5,2) DEFAULT NULL COMMENT 'напряжение «пора менять», В',
  `dead_v` decimal(5,2) DEFAULT NULL COMMENT 'напряжение «уже не работает», В',
  `warn_pct` decimal(5,1) DEFAULT 20.0,
  `dead_pct` decimal(5,1) DEFAULT 5.0,
  `has_voltage` tinyint(4) NOT NULL DEFAULT 0 COMMENT '1 = отдаёт voltage в милливольтах',
  `active` tinyint(4) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 100,
  `note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_device` (`device`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `daily_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reset_date` date NOT NULL,
  `reset_time` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `reset_date` (`reset_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `email_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_triggers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_id` int(11) DEFAULT 0,
  `rule_name` varchar(255) DEFAULT NULL,
  `recipient` varchar(255) DEFAULT NULL,
  `trigger_topic` varchar(255) DEFAULT NULL,
  `trigger_value` varchar(50) DEFAULT NULL,
  `condition_operator` varchar(10) DEFAULT NULL,
  `condition_value` varchar(50) DEFAULT NULL,
  `triggered_at` timestamp NULL DEFAULT current_timestamp(),
  `sent` tinyint(4) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `log_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(50) DEFAULT NULL,
  `count` int(11) DEFAULT 0,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_keyword_date` (`keyword`,`date`)
) ENGINE=InnoDB AUTO_INCREMENT=3846 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `pending_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pending_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kind` enum('delay','confirm') NOT NULL,
  `rule_id` int(11) NOT NULL,
  `rule_name` varchar(255) DEFAULT NULL,
  `topic` varchar(255) NOT NULL,
  `payload` text DEFAULT NULL,
  `expected` text DEFAULT NULL,
  `run_at` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_run` (`run_at`),
  KEY `idx_kind` (`kind`)
) ENGINE=InnoDB AUTO_INCREMENT=1907 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `push_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `push_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_id` int(11) DEFAULT NULL,
  `topic_name` varchar(255) NOT NULL,
  `message` text DEFAULT NULL,
  `metric_value` decimal(15,2) DEFAULT NULL,
  `status` enum('pending','sent','failed') DEFAULT 'pending',
  `retry_count` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `sent_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rule_id` (`rule_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `push_notifications_ibfk_1` FOREIGN KEY (`rule_id`) REFERENCES `automations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `rpi_monitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rpi_monitor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cpu_temp` varchar(10) DEFAULT NULL,
  `cpu_load` varchar(10) DEFAULT NULL,
  `mem_total` varchar(10) DEFAULT NULL,
  `mem_used` varchar(10) DEFAULT NULL,
  `mem_percent` varchar(10) DEFAULT NULL,
  `disk_usage` varchar(10) DEFAULT NULL,
  `volt_core` varchar(10) DEFAULT 'N/A',
  `uptime` text DEFAULT NULL,
  `ip_addresses` text DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `nvme_temp` varchar(10) DEFAULT 'N/A',
  `fan_speed` varchar(50) DEFAULT 'N/A',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105635 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `rs485_commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rs485_commands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` varchar(20) NOT NULL,
  `command` varchar(100) NOT NULL,
  `status` enum('pending','sent','error','timeout') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `rs485_sensor_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rs485_sensor_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` varchar(20) NOT NULL,
  `temperature` float DEFAULT NULL,
  `humidity` float DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `sensor_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sensor_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_topic` (`topic`),
  KEY `idx_topic_timestamp` (`topic`,`timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=79891545 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `sensor_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sensor_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9577493 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `sensor_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sensor_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `room` varchar(255) DEFAULT NULL,
  `group_name` varchar(255) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `save_history` tinyint(1) NOT NULL DEFAULT 0,
  `command_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `topic` (`topic`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `sensors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sensors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` float NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `zz_test_perm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `zz_test_perm` (
  `id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

