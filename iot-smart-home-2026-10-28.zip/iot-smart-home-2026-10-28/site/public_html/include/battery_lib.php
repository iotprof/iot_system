<?php
/**
 * battery_lib.php — единая логика состояния элементов питания.
 *
 * Подключение:  require_once __DIR__ . '/include/battery_lib.php';
 *
 * ПОЧЕМУ отдельный файл, а не код прямо в страницах:
 * состояние батареек нужно в трёх местах — сводная карточка на главной,
 * страница /admin/batteries.php и ночная проверка в cron (check_battery.py).
 * Если логику копировать, через месяц панель и письмо начнут говорить разное.
 * Поэтому пороги живут в таблице battery_spec — одна точка правды.
 *
 * ГЛАВНАЯ ТОНКОСТЬ ЭТОГО ДОМА (из-за неё всё и делается через справочник):
 * поле voltage у Zigbee-устройства С БАТАРЕЙКОЙ — это МИЛЛИВОЛЬТЫ (2500…3000),
 * а у розетки с измерением мощности то же самое поле voltage — это вольты сети
 * (207…253). Поэтому нельзя просто «взять все топики, где встречается voltage»:
 * получите 4xAA и «пора менять» на розетке с 218 В. Список устройств берётся из
 * battery_spec, где известно и что за элемент, и какой у него порог.
 */

if (!function_exists('iot_battery_specs')) {

    /** Справочник устройств с батарейками (таблица battery_spec). */
    function iot_battery_specs(PDO $pdo): array
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }
        try {
            $cache = $pdo->query(
                "SELECT * FROM battery_spec WHERE active = 1 ORDER BY sort_order, device"
            )->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            error_log('battery_lib: таблица battery_spec недоступна — ' . $e->getMessage());
            $cache = [];
        }
        return $cache;
    }

    /** Описание элемента: «CR2032 ×1 (3,0 В)». */
    function iot_battery_element(array $spec): string
    {
        $type  = trim((string)($spec['battery_type'] ?? ''));
        $typ   = $type !== '' ? $type : '—';
        $cells = ($spec['cells'] !== null && $spec['cells'] !== '') ? (int)$spec['cells'] : null;
        $out   = $cells ? sprintf('%s ×%d', $typ, $cells) : $typ;
        if ($spec['nominal_v'] !== null && $spec['nominal_v'] !== '') {
            $out .= sprintf(' (%.1f В)', (float)$spec['nominal_v']);
        }
        return $out;
    }

    /** Пороги текстом: «менять ≤ 2.70 В / 20 % · мёртвая ≤ 2.40 В / 5 %». */
    function iot_battery_thresholds(array $spec): string
    {
        $hv = (int)$spec['has_voltage'] === 1;
        $w  = [];
        $d  = [];
        if ($hv && ($spec['warn_v'] ?? '') !== '') { $w[] = sprintf('%.2f В', (float)$spec['warn_v']); }
        if (($spec['warn_pct'] ?? '') !== '')      { $w[] = sprintf('%.0f %%', (float)$spec['warn_pct']); }
        if ($hv && ($spec['dead_v'] ?? '') !== '') { $d[] = sprintf('%.2f В', (float)$spec['dead_v']); }
        if (($spec['dead_pct'] ?? '') !== '')      { $d[] = sprintf('%.0f %%', (float)$spec['dead_pct']); }

        $out = '';
        if ($w) { $out .= 'менять ≤ ' . implode(' / ', $w); }
        if ($d) { $out .= ($out !== '' ? ' · ' : '') . 'мёртвая ≤ ' . implode(' / ', $d); }
        return $out;
    }

    /** Иконка, подпись и CSS-класс значка для состояния. */
    function iot_battery_state_meta(string $state): array
    {
        $map = [
            'dead'    => ['⛔', 'вышла из строя', 'badge-error'],
            'replace' => ['🟠', 'пора менять',    'badge-warning'],
            'stale'   => ['🕓', 'нет связи',      'badge-info'],
            'unknown' => ['⚪', 'нет данных',     'badge-info'],
            'ok'      => ['🟢', 'в норме',        'badge-success'],
        ];
        return $map[$state] ?? ['⚪', $state, 'badge-info'];
    }

    /**
     * Состояние всех батарейных устройств.
     * Возвращает массив строк, худшие — в начале.
     *
     * Каждая строка:
     *   device, title, room, element, thresholds, note,
     *   pct, mv, low_flag, state, icon, badge_label, badge_class, reason,
     *   seen, stale_days, batt_ts, trend_v, trend_p
     */
    function iot_battery_status(PDO $pdo): array
    {
        $specs = iot_battery_specs($pdo);
        if (!$specs) {
            return [];
        }

        // 1. Один запрос на все нужные топики: battery, battery_low и voltage.
        $topics = [];
        foreach ($specs as $s) {
            $topics[] = 'zigbee2mqtt/' . $s['device'] . '/battery';
            $topics[] = 'zigbee2mqtt/' . $s['device'] . '/battery_low';
            if ((int)$s['has_voltage'] === 1) {
                $topics[] = 'zigbee2mqtt/' . $s['device'] . '/voltage';
            }
        }
        $live = [];
        try {
            $in   = implode(',', array_fill(0, count($topics), '?'));
            $stmt = $pdo->prepare("SELECT topic, value, timestamp FROM sensor_data WHERE topic IN ($in)");
            $stmt->execute($topics);
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $live[$r['topic']] = $r;
            }
        } catch (Throwable $e) {
            error_log('battery_lib: не прочитать sensor_data — ' . $e->getMessage());
        }

        // 2. Свежесть: самое новое сообщение по устройству ВООБЩЕ (не только battery).
        //    Нужно, чтобы отличить «батарейка садится» от «устройство молчит».
        $fresh = [];
        try {
            $rows = $pdo->query(
                "SELECT topic, MAX(timestamp) AS t FROM sensor_data
                 WHERE topic LIKE 'zigbee2mqtt/%' GROUP BY topic"
            )->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $r) {
                $parts = explode('/', $r['topic']);
                if (count($parts) < 3) { continue; }
                $dev = $parts[1];
                if (!isset($fresh[$dev]) || $r['t'] > $fresh[$dev]) { $fresh[$dev] = $r['t']; }
            }
        } catch (Throwable $e) {
            error_log('battery_lib: не посчитать свежесть — ' . $e->getMessage());
        }

        // 3. Тренд за 7 суток из истории (появляется после включения save_history).
        //    REGEXP отсекает мусор: value — varchar, слепой CAST дал бы нули.
        $trend = [];
        try {
            $rows = $pdo->query(
                "SELECT topic,
                        MIN(CAST(value AS DECIMAL(10,2))) AS mn,
                        MAX(CAST(value AS DECIMAL(10,2))) AS mx,
                        COUNT(*) AS n
                 FROM sensor_history
                 WHERE timestamp > NOW() - INTERVAL 7 DAY
                   AND value REGEXP '^[0-9]+([.][0-9]+)?$'
                   AND (topic LIKE 'zigbee2mqtt/%/battery' OR topic LIKE 'zigbee2mqtt/%/voltage')
                 GROUP BY topic"
            )->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $r) {
                $trend[$r['topic']] = $r;
            }
        } catch (Throwable $e) {
            // истории может не быть — это не ошибка
        }

        // 4. Решение по каждому устройству.
        $now  = time();
        $rank = ['dead' => 0, 'replace' => 1, 'stale' => 2, 'unknown' => 3, 'ok' => 4];
        $out  = [];

        foreach ($specs as $s) {
            $dev  = $s['device'];
            $batt = $live['zigbee2mqtt/' . $dev . '/battery'] ?? null;
            $volt = $live['zigbee2mqtt/' . $dev . '/voltage'] ?? null;
            $low  = $live['zigbee2mqtt/' . $dev . '/battery_low'] ?? null;

            $pct = ($batt !== null && $batt['value'] !== '') ? (float)$batt['value'] : null;

            // Напряжение берём только если оно похоже на батареечное. Значение
            // меньше 1000 — это не милливольты, а что-то другое: не считаем его.
            $mv = null;
            if ((int)$s['has_voltage'] === 1 && $volt !== null) {
                $v = (float)$volt['value'];
                if ($v >= 1000) { $mv = $v; }
            }

            $low_flag = ($low !== null && (string)$low['value'] === '1');

            $seen     = $fresh[$dev] ?? null;
            $stale_h  = $seen ? (int)round(($now - strtotime($seen)) / 3600) : null;
            $batt_ts  = $batt['timestamp'] ?? null;

            $warn_v = ($s['warn_v'] ?? '') !== '' ? (float)$s['warn_v'] : null;
            $dead_v = ($s['dead_v'] ?? '') !== '' ? (float)$s['dead_v'] : null;
            $warn_p = ($s['warn_pct'] ?? '') !== '' ? (float)$s['warn_pct'] : 20.0;
            $dead_p = ($s['dead_pct'] ?? '') !== '' ? (float)$s['dead_pct'] : 5.0;

            // ВАЖНО О ЕДИНИЦАХ. Пороги в battery_spec записаны в ВОЛЬТАХ (2.70),
            // потому что так их читает человек и так они подписываются на странице.
            // А с устройства voltage приходит в МИЛЛИВОЛЬТАХ (2700). Сравнивать
            // напрямую нельзя: 2500 <= 2.70 — это ложь, и разряженная батарейка
            // молча уедет в «в норме». Поэтому пороги переводим в мВ.
            $warn_mv = $warn_v !== null ? $warn_v * 1000 : null;
            $dead_mv = $dead_v !== null ? $dead_v * 1000 : null;

            // Берём ХУДШИЙ из двух сигналов: процент у Z2M считается по
            // приблизительной кривой, вольтаж — сырой факт с устройства.
            $state  = 'ok';
            $reason = '';

            if ($low_flag) {
                $state  = 'dead';
                $reason = 'устройство само сообщает «батарея разряжена»';
            } elseif ($mv !== null && $dead_mv !== null && $mv <= $dead_mv) {
                $state  = 'dead';
                $reason = sprintf('напряжение %.0f мВ не выше предела %.2f В', $mv, $dead_v);
            } elseif ($pct !== null && $pct <= $dead_p) {
                $state  = 'dead';
                $reason = sprintf('заряд %.1f %% не выше %.0f %%', $pct, $dead_p);
            } elseif ($mv !== null && $warn_mv !== null && $mv <= $warn_mv) {
                $state  = 'replace';
                $reason = sprintf('напряжение %.0f мВ дошло до порога %.2f В', $mv, $warn_v);
            } elseif ($pct !== null && $pct <= $warn_p) {
                $state  = 'replace';
                $reason = sprintf('заряд %.1f %% дошёл до порога %.0f %%', $pct, $warn_p);
            } elseif ($pct === null && $mv === null) {
                $state  = 'unknown';
                $reason = 'устройство не отдаёт ни заряда, ни напряжения';
            }

            // Молчание дольше 3 суток — отдельное состояние. Показывать цифры
            // как «текущие» нельзя: это замороженный снимок с последнего сеанса.
            if ($state !== 'dead') {
                if ($seen === null) {
                    $state  = 'unknown';
                    $reason = 'устройства нет в базе значений';
                } elseif ($stale_h > 72) {
                    $state  = 'stale';
                    $reason = sprintf('нет данных %d дн. — цифры устарели, проверь связь', (int)round($stale_h / 24));
                }
            }

            $meta = iot_battery_state_meta($state);

            // Тренд текстом, если история уже накопилась.
            $tv = '';
            $tp = '';
            if (isset($trend['zigbee2mqtt/' . $dev . '/voltage'])) {
                $t  = $trend['zigbee2mqtt/' . $dev . '/voltage'];
                $tv = sprintf('%d…%d мВ (%s точек)', (int)$t['mn'], (int)$t['mx'], $t['n']);
            }
            if (isset($trend['zigbee2mqtt/' . $dev . '/battery'])) {
                $t  = $trend['zigbee2mqtt/' . $dev . '/battery'];
                $tp = sprintf('%s…%s %% (%s точек)', rtrim(rtrim(number_format((float)$t['mn'], 1, '.', ''), '0'), '.'), rtrim(rtrim(number_format((float)$t['mx'], 1, '.', ''), '0'), '.'), $t['n']);
            }

            $out[] = [
                'device'      => $dev,
                'title'       => ($s['title'] ?? '') !== '' ? $s['title'] : $dev,
                'room'        => $s['room'] ?? '',
                'element'     => iot_battery_element($s),
                'thresholds'  => iot_battery_thresholds($s),
                'note'        => $s['note'] ?? '',
                'pct'         => $pct,
                'mv'          => $mv,
                'low_flag'    => $low_flag,
                'state'       => $state,
                'icon'        => $meta[0],
                'badge_label' => $meta[1],
                'badge_class' => $meta[2],
                'reason'      => $reason,
                'seen'        => $seen,
                'stale_days'  => $stale_h !== null ? round($stale_h / 24, 1) : null,
                'batt_ts'     => $batt_ts,
                'trend_v'     => $tv,
                'trend_p'     => $tp,
                '_rank'       => $rank[$state] ?? 9,
            ];
        }

        usort($out, function ($a, $b) {
            if ($a['_rank'] !== $b['_rank']) { return $a['_rank'] <=> $b['_rank']; }
            $ap = $a['pct'] ?? 999;
            $bp = $b['pct'] ?? 999;
            if ($ap !== $bp) { return $ap <=> $bp; }
            return strcmp($a['device'], $b['device']);
        });

        return $out;
    }

    /** Счётчики по состояниям: dead / replace / stale / unknown / ok / total. */
    function iot_battery_counts(array $rows): array
    {
        $c = ['dead' => 0, 'replace' => 0, 'stale' => 0, 'unknown' => 0, 'ok' => 0, 'total' => count($rows)];
        foreach ($rows as $r) {
            if (isset($c[$r['state']])) { $c[$r['state']]++; }
        }
        return $c;
    }

    /** Строка «сколько дней назад» по метке времени. */
    function iot_battery_ago(?string $ts): string
    {
        if (!$ts) { return '—'; }
        $h = (int)round((time() - strtotime($ts)) / 3600);
        if ($h < 1) { return 'только что'; }
        if ($h < 24) { return $h . ' ч назад'; }
        return (int)round($h / 24) . ' дн назад';
    }
}
