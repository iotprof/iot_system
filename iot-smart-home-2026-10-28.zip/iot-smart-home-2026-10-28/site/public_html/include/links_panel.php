
<?php
// links_panel.php - единая панель навигации с адаптивным меню и переключателем темы
$current_page = basename($_SERVER['PHP_SELF']);
?>
<style>

    /* Базовые CSS переменные (темная тема по умолчанию) */
    :root {
        --bg-card: #1e1e2e;
        --bg-card-secondary: #2a2a3a;
        --bg-panel: #1a1a2a;
        --bg-input: #2d2d3a;
        --bg-hover: #2a2a3a;
        --text-primary: #ffffff;
        --text-secondary: #a0a0b0;
        --border: #3a3a4a;
        --border-light: #2a2a3a;
        --accent: #4f9ef7;
    }
    
    /* Светлая тема */
    body.light {
        --bg-card: #ffffff;
        --bg-card-secondary: #f0f0f5;
        --bg-panel: #f5f5fa;
        --bg-input: #e8e8ed;
        --bg-hover: #e8e8ed;
        --text-primary: #1a1a2e;
        --text-secondary: #4a4a5a;
        --border: #d0d0da;
        --border-light: #e0e0ea;
        --accent: #4f9ef7;
    }
    
    body {
        background: var(--bg-panel);
        color: var(--text-primary);
        transition: background 0.3s ease, color 0.3s ease;
        margin: 0;
        padding: 20px;
        font-family: system-ui, -apple-system, sans-serif;
    }
    
    .nav-panel {
        margin-bottom: 1.5rem;
        font-family: system-ui, -apple-system, sans-serif;
    }
    
    .nav-desktop {
        display: flex;
        flex-wrap: wrap;
        gap: 0.75rem;
        align-items: center;
        justify-content: space-between;
    }
    
    .nav-left {
        display: flex;
        flex-wrap: wrap;
        gap: 0.75rem;
        align-items: center;
    }
    
    .nav-right {
        display: flex;
        gap: 0.75rem;
        align-items: center;
    }
    
    .nav-logo {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        background: var(--bg-card-secondary);
        padding: 0.5rem 1rem;
        border-radius: 30px;
        color: var(--text-primary);
        border: 1px solid var(--border);
        font-weight: 600;
    }
    
    .nav-link {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        background: var(--bg-card);
        padding: 0.5rem 1rem;
        border-radius: 30px;
        text-decoration: none;
        transition: all 0.2s ease;
        border: 1px solid var(--border-light);
        font-size: 0.9rem;
        color: var(--text-secondary);
    }
    
    .nav-link:hover {
        transform: translateY(-2px);
        background: var(--bg-hover);
        border-color: var(--accent);
        color: var(--accent);
    }
    
    .nav-link.active {
        background: var(--accent);
        color: #fff;
        border-color: var(--accent);
    }
    
    /* Переключатель темы */
    .theme-switch-wrapper {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        background: var(--bg-card);
        padding: 0.25rem 0.75rem;
        border-radius: 40px;
        border: 1px solid var(--border);
    }
    
    .theme-switch {
        position: relative;
        display: inline-block;
        width: 50px;
        height: 24px;
    }
    
    .theme-switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .theme-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: var(--bg-input);
        transition: 0.3s;
        border-radius: 34px;
    }
    
    .theme-slider:before {
        position: absolute;
        content: "🌙";
        height: 20px;
        width: 20px;
        left: 3px;
        bottom: 2px;
        background-color: var(--accent);
        transition: 0.3s;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
    }
    
    input:checked + .theme-slider:before {
        transform: translateX(26px);
        content: "☀️";
    }
    
    .theme-icon {
        font-size: 0.9rem;
    }
    
    /* Мобильное меню */
    .nav-mobile {
        display: none;
    }
    
    .burger-btn {
        display: flex;
        align-items: center;
        justify-content: space-between;
        width: 100%;
        background: var(--bg-card);
        border: 1px solid var(--border);
        border-radius: 40px;
        padding: 0.7rem 1rem;
        cursor: pointer;
        font-size: 1rem;
        color: var(--text-primary);
        transition: all 0.2s ease;
    }
    
    .burger-btn:hover {
        background: var(--bg-hover);
        border-color: var(--accent);
    }
    
    .burger-icon {
        font-size: 1.3rem;
    }
    
    .burger-arrow {
        transition: transform 0.3s ease;
    }
    
    .burger-arrow.open {
        transform: rotate(180deg);
    }
    
    .mobile-menu {
        display: none;
        flex-direction: column;
        gap: 0.5rem;
        margin-top: 0.75rem;
        padding: 0.75rem;
        background: var(--bg-panel);
        border-radius: 20px;
        border: 1px solid var(--border);
        animation: fadeIn 0.2s ease;
    }
    
    .mobile-menu.open {
        display: flex;
    }
    
    .mobile-menu .nav-link {
        justify-content: center;
        padding: 0.7rem;
    }
    
    .mobile-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.5rem;
        padding-bottom: 0.5rem;
        border-bottom: 1px solid var(--border);
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    @media (max-width: 768px) {
        .nav-desktop {
            display: none;
        }
        .nav-mobile {
            display: block;
        }
    }
    
    @media (min-width: 769px) and (max-width: 1024px) {
        .nav-desktop {
            gap: 0.5rem;
        }
        .nav-link {
            padding: 0.4rem 0.8rem;
            font-size: 0.8rem;
        }
        .nav-logo {
            padding: 0.4rem 0.8rem;
            font-size: 0.8rem;
        }
    }
</style>
<div class="nav-panel">
    <!-- Десктопное меню -->
    <div class="nav-desktop">
        <div class="nav-left">
            <div class="nav-logo">
                <span>🏠</span> IoT Система
            </div>
            <a href="/index.php" class="nav-link home <?= $current_page == 'index.php' ? 'active' : '' ?>">
                <span>🏠</span> Главная
            </a>
            <a href="/graf.php" class="nav-link graf <?= $current_page == 'graf.php' ? 'active' : '' ?>">
                <span>📊</span> Графики
            </a>
            <a href="/admin/logic.php" class="nav-link logic <?= $current_page == 'logic.php' ? 'active' : '' ?>">
                <span>⚙️</span> Правила
            </a>
            <a href="/admin/anomalies.php" class="nav-link anomalies <?= $current_page == 'anomalies.php' ? 'active' : '' ?>">
                <span>🔍</span> Аномалии
            </a>
            <a href="/admin/automation_log.php" class="nav-link automation_log <?= $current_page == 'automation_log.php' ? 'active' : '' ?>">
                <span>📜</span> Логи автоматизаций
            </a>
            <a href="/admin/sensors.php" class="nav-link sensors_meta <?= $current_page == 'sensors.php' ? 'active' : '' ?>">
                <span>📡</span> Метаданные
            </a>
            <a href="/admin/batteries.php" class="nav-link batteries <?= $current_page == 'batteries.php' ? 'active' : '' ?>">
                <span>🔋</span> Батарейки
            </a>
            <a href="/admin/log_viewer.php" class="nav-link log_viewer <?= $current_page == 'log_viewer.php' ? 'active' : '' ?>">
                <span>📋</span> Логи сервисов
            </a>
            <a href="/admin/cron_logs.php" class="nav-link cron_logs <?= $current_page == 'cron_logs.php' ? 'active' : '' ?>">
                <span>⏰</span> Cron логи
            </a>
            <a href="/admin/cottage_panel.php" class="nav-link cottage <?= $current_page == 'cottage_panel.php' ? 'active' : '' ?>">
                <span>🏡</span> Коттедж
            </a>
        </div>
        <div class="nav-right">
            <div class="theme-switch-wrapper">
                <span class="theme-icon">🌙</span>
                <label class="theme-switch">
                    <input type="checkbox" id="themeToggle">
                    <span class="theme-slider"></span>
                </label>
                <span class="theme-icon">☀️</span>
            </div>
        </div>
    </div>
    
    <!-- Мобильное меню (бургер) -->
    <div class="nav-mobile">
        <div class="burger-btn" onclick="toggleMobileMenu()">
            <span class="burger-icon">☰</span>
            <span>Меню</span>
            <span class="burger-arrow">▼</span>
        </div>
        <div class="mobile-menu" id="mobileMenu">
            <div class="mobile-top">
                <span>🌓 Тема</span>
                <label class="theme-switch">
                    <input type="checkbox" id="themeToggleMobile">
                    <span class="theme-slider"></span>
                </label>
            </div>
            <a href="/index.php" class="nav-link home">
                <span>🏠</span> Главная
            </a>
            <a href="/graf.php" class="nav-link graf">
                <span>📊</span> Графики
            </a>
            <a href="/admin/logic.php" class="nav-link logic">
                <span>⚙️</span> Правила
            </a>
            <a href="/admin/anomalies.php" class="nav-link anomalies">
                <span>🔍</span> Аномалии
            </a>
            <a href="/admin/automation_log.php" class="nav-link automation_log">
                <span>📜</span> Логи автоматизаций
            </a>
            <a href="/admin/sensors.php" class="nav-link sensors_meta">
                <span>📡</span> Метаданные
            </a>
            <a href="/admin/batteries.php" class="nav-link batteries <?= $current_page == 'batteries.php' ? 'active' : '' ?>">
                <span>🔋</span> Батарейки
            </a>
            <a href="/admin/log_viewer.php" class="nav-link log_viewer">
                <span>📋</span> Логи сервисов
            </a>
            <a href="/admin/cron_logs.php" class="nav-link cron_logs">
                <span>⏰</span> Cron логи
            </a>
            <a href="/smarthome_architecture.html" class="nav-link doc" target="_blank" style="opacity:.85"><span>📐</span> Архитектура</a>
            <a href="/batteries_doc.html" class="nav-link doc" target="_blank" style="opacity:.85"><span>🔋</span> Статья: батарейки</a>
            <a href="/anomaly_article.html" class="nav-link doc" target="_blank" style="opacity:.85"><span>📖</span> Статья: аномалии</a>
            <a href="/anomaly_module_doc.html" class="nav-link doc" target="_blank" style="opacity:.85"><span>🔍</span> Статья: раздел Аномалии</a>
            <a href="/smarthome_round2_report.html" class="nav-link doc" target="_blank" style="opacity:.85"><span>🧾</span> Отчёт доработки</a>
            <a href="/admin/cottage_panel.php" class="nav-link cottage">
                <span>🏡</span> Коттедж
            </a>
        </div>
    </div>
</div>

<script>
function setTheme(isDark) {
    if (isDark) {
        document.body.classList.remove('light');
        localStorage.setItem('theme', 'dark');
    } else {
        document.body.classList.add('light');
        localStorage.setItem('theme', 'light');
    }
    
    // Синхронизируем оба переключателя
    const toggles = document.querySelectorAll('#themeToggle, #themeToggleMobile');
    toggles.forEach(toggle => {
        if (toggle) {
            toggle.checked = !isDark;
        }
    });
}

function initTheme() {
    const savedTheme = localStorage.getItem('theme');
    // Если тема не сохранена или это светлая тема
    const isDark = savedTheme !== 'light';
    setTheme(isDark);
    
    // Добавляем обработчики для переключателей
    const toggles = document.querySelectorAll('#themeToggle, #themeToggleMobile');
    toggles.forEach(toggle => {
        if (toggle) {
            toggle.addEventListener('change', (e) => {
                setTheme(!e.target.checked);
            });
        }
    });
}

function toggleMobileMenu() {
    const menu = document.getElementById('mobileMenu');
    const arrow = document.querySelector('.burger-arrow');
    
    if (menu.classList.contains('open')) {
        menu.classList.remove('open');
        arrow.classList.remove('open');
    } else {
        menu.classList.add('open');
        arrow.classList.add('open');
    }
}

// Запускаем инициализацию темы после загрузки DOM
document.addEventListener('DOMContentLoaded', initTheme);
</script>
