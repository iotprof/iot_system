<?php
try {
    // Подключаемся к SQLite
    $db = new PDO('sqlite:/var/www/html/db/sensors.db');

    // Получаем последние значения по каждому топику
    $stmt_latest = $db->query("
        SELECT topic, value, MAX(timestamp) as last_time 
        FROM sensor_data 
        GROUP BY topic
    ");
    $latestData = $stmt_latest->fetchAll(PDO::FETCH_ASSOC);

    $topics = [];
    $topicTimestamps = [];

    foreach ($latestData as $row) {
        $topics[$row['topic']] = $row['value'];
        $topicTimestamps[$row['topic']] = $row['last_time'];
    }

    // Получаем историю температуры за последние 24 часа
    $stmt_temp = $db->prepare("
        SELECT value, timestamp 
        FROM sensor_data 
        WHERE topic = 'sensors/living_room/temperature'
          AND timestamp >= datetime('now', '-24 hours')
        ORDER BY timestamp ASC
    ");
    $stmt_temp->execute();
    $temperatureHistory = $stmt_temp->fetchAll(PDO::FETCH_ASSOC);

    // Получаем историю влажности за последние 24 часа
    $stmt_hum = $db->prepare("
        SELECT value, timestamp 
        FROM sensor_data 
        WHERE topic = 'sensors/living_room/humidity'
          AND timestamp >= datetime('now', '-24 hours')
        ORDER BY timestamp ASC
    ");
    $stmt_hum->execute();
    $humidityHistory = $stmt_hum->fetchAll(PDO::FETCH_ASSOC);

    // Список устройств
    $deviceList = [
        'sensors/living_room/temperature' => ['name' => 'Гостиная', 'type' => 'temperature', 'unit' => '°C'],
        'sensors/living_room/humidity'   => ['name' => 'Гостиная', 'type' => 'humidity', 'unit' => '%'],
        'sensors/greenhouse/temperature' => ['name' => 'Теплица', 'type' => 'temperature', 'unit' => '°C'],
        'sensors/greenhouse/soil_moisture' => ['name' => 'Теплица', 'type' => 'soil_moisture', 'unit' => '%'],
        'sensors/boiler_room/status' => ['name' => 'Котельная', 'type' => 'status', 'unit' => ''],
        'sensors/garage/door' => ['name' => 'Гараж', 'type' => 'door', 'unit' => ''],
        'sensors/shed/light' => ['name' => 'Сарай', 'type' => 'light', 'unit' => 'лк'],
    ];

    $devices = [];

    foreach ($deviceList as $topic => $info) {
        if (isset($topics[$topic])) {
            $info['topic'] = $topic;
            $info['value'] = $topics[$topic];
            $info['control'] = in_array($topic, ['sensors/living_room/light', 'sensors/garage/door', 'sensors/shed/light']) ? 'switch' : '';
            $info['command_topic'] = str_replace('sensors/', 'commands/', $topic);
            $devices[] = $info;
        }
    }

} catch (PDOException $e) {
    die("Ошибка базы данных: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>📡 Умный дом</title>
    <link rel="stylesheet" href="/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> 
</head>
<body>

<header>🏡 Умный дом</header>

<main>
    <?php if (empty($devices)): ?>
        <p>Нет данных от датчиков.</p>
    <?php else: ?>
        <?php foreach ($devices as $device): ?>
            <div class="card <?= htmlspecialchars($device['type']) ?>">
                <div class="title">
                    <span class="icon">📡</span>
                    <?= htmlspecialchars($device['name']) ?>
                </div>
                <div class="value">
                    <?= htmlspecialchars($device['value']) ?><?= htmlspecialchars($device['unit']) ?>
                </div>
                <div class="topic"><?= htmlspecialchars($device['topic']) ?></div>

                <!-- Время последнего обновления -->
                <?php if (isset($topicTimestamps[$device['topic']])): ?>
                    <div class="timestamp">🕒 <?= date("H:i:s", strtotime($topicTimestamps[$device['topic']])) ?></div>
                <?php endif; ?>

                <!-- График температуры -->
                <?php if ($device['type'] === 'temperature' && isset($temperatureHistory) && !empty($temperatureHistory)): ?>
                    <canvas id="chart-temp" height="100"></canvas>
                    <script>
                        document.addEventListener('DOMContentLoaded', function () {
                            const ctx = document.getElementById('chart-temp').getContext('2d');
                            new Chart(ctx, {
                                type: 'line',
                                data: {
                                    labels: [
                                        <?php foreach ($temperatureHistory as $point): ?>
                                            '<?= date("H:i", strtotime($point['timestamp'])) ?>',
                                        <?php endforeach; ?>
                                    ],
                                    datasets: [{
                                        label: 'Температура',
                                        data: [
                                            <?php foreach ($temperatureHistory as $point): ?>
                                                <?= floatval($point['value']) ?>,
                                            <?php endforeach; ?>
                                        ],
                                        borderColor: '#00c6ff',
                                        backgroundColor: 'rgba(0, 198, 255, 0.1)',
                                        fill: true,
                                        tension: 0.4,
                                        pointRadius: 0
                                    }]
                                },
                                options: {
                                    responsive: true,
                                    plugins: { legend: { display: false } },
                                    scales: { x: { display: false }, y: { beginAtZero: false } }
                                }
                            });
                        });
                    </script>
                <?php endif; ?>

                <!-- График влажности -->
                <?php if ($device['type'] === 'humidity' && isset($humidityHistory) && !empty($humidityHistory)): ?>
                    <canvas id="chart-hum" height="100"></canvas>
                    <script>
                        document.addEventListener('DOMContentLoaded', function () {
                            const ctx = document.getElementById('chart-hum').getContext('2d');
                            new Chart(ctx, {
                                type: 'line',
                                data: {
                                    labels: [
                                        <?php foreach ($humidityHistory as $point): ?>
                                            '<?= date("H:i", strtotime($point['timestamp'])) ?>',
                                        <?php endforeach; ?>
                                    ],
                                    datasets: [{
                                        label: 'Влажность',
                                        data: [
                                            <?php foreach ($humidityHistory as $point): ?>
                                                <?= floatval($point['value']) ?>,
                                            <?php endforeach; ?>
                                        ],
                                        borderColor: '#00c6ff',
                                        backgroundColor: 'rgba(0, 198, 255, 0.1)',
                                        fill: true,
                                        tension: 0.4,
                                        pointRadius: 0
                                    }]
                                },
                                options: {
                                    responsive: true,
                                    plugins: { legend: { display: false } },
                                    scales: { x: { display: false }, y: { beginAtZero: false } }
                                }
                            });
                        });
                    </script>
                <?php endif; ?>

                <!-- Кнопки управления -->
                <?php if (isset($device['control'])): ?>
                    <form method="post" action="/mqtt/publish.php" style="margin-top: 1rem;">
                        <input type="hidden" name="topic" value="<?= htmlspecialchars($device['command_topic']) ?>">

                        <?php if ($device['control'] === 'switch'): ?>
                            <label class="switch">
                                <input type="checkbox" name="payload" value="toggle">
                                <span class="slider"></span>
                            </label>
                        <?php elseif ($device['control'] === 'thermostat'): ?>
                            <label>🌡️ Температура:
                                <input type="number" step="0.1" min="10" max="35" name="payload" value="<?= htmlspecialchars($device['value']) ?>">
                            </label>
                            <button type="submit">✅ Сохранить</button>
                        <?php endif; ?>
                    </form>
                <?php endif; ?>
            </div>
        <?php endforeach ?>
    <?php endif; ?>
</main>

<footer>
    &copy; <?= date('Y') ?> — Интерфейс умного дома на Raspberry Pi + MQTT + SQLite
</footer>

</body>
</html>
