<?php
require_once '/var/www/html/iot/config/iot_config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    // Подключение к БД
    $host = '127.0.0.1';
    $db   = 'iot_db';
    $user = 'IOT_DB_USER';
    $pass = IOT_DB_PASS;
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, $user, $pass, $opt);

    // Получаем список всех топиков
    $stmt = $pdo->query("
        SELECT topic 
        FROM sensor_data
        GROUP BY topic
    ");
    $topics = $stmt->fetchAll(PDO::FETCH_COLUMN);

} catch (PDOException $e) {
    die("Ошибка базы данных: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>📡 Все графики</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js "></script>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f9f9f9; }
        h1 { color: #333; }
        .chart-container {
            background: white;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 30px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }
        canvas {
            width: 100% !important;
            height: auto !important;
        }
    </style>
</head>
<body>

<h1>📉 Все графики датчиков</h1>

<?php if (empty($topics)): ?>
    <p>Нет данных для отображения.</p>
<?php else: ?>
    <?php foreach ($topics as $topic): ?>
        <?php
            // Получаем последнее значение для этого топика
            $stmt = $pdo->prepare("
                SELECT value, MAX(timestamp) as last_time
                FROM sensor_history
                WHERE topic = ?
                GROUP BY topic
            ");
            $stmt->execute([$topic]);
            $row = $stmt->fetch();

            $value = $row['value'] ?? 'Нет данных';
            $timestamp = $row['last_time'] ?? '—';

            // Определяем тип и единицы измерения
            $type = basename($topic);
            $unit = match($type) {
                'temperature' => '°C',
                'humidity' => '%',
                'light' => 'лк',
                'pm25' => 'мкг/м³',
                'co2' => 'ppm',
                'water_pressure' => 'бар',
                default => ''
            };
        ?>

        <div class="chart-container" id="<?= htmlspecialchars((string)$topic) ?>">
            <h3><?= htmlspecialchars($type) ?> <small>(<?= htmlspecialchars($topic) ?>)</small></h3>
            <p><strong>Последнее значение:</strong> <?= htmlspecialchars($value) ?> <?= $unit ? "$unit" : '' ?><br>
               <strong>Время:</strong> <?= htmlspecialchars((string)$timestamp) ?></p>
            <div class="chart-wrapper">
                <?php if ($value === 'Нет данных'): ?>
                    <p>❌ Нет данных для построения графика</p>
                <?php else: ?>
                    <canvas id="chart-<?= htmlspecialchars((string)$topic) ?>" height="100"></canvas>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('canvas[id^="chart-"]').forEach(canvas => {
        const topic = canvas.id.replace('chart-', '');

        fetch('/api/history.php?topic=' + encodeURIComponent(topic))
            .then(res => res.json())
            .then(data => {
                if (!data || !Array.isArray(data) || data.length === 0) {
                    canvas.parentNode.innerHTML = '<p style="color:red;">❌ Нет исторических данных</p>';
                    return;
                }

                const labels = data.map(p => p.timestamp.split(' ')[1]);
                const values = data.map(p => parseFloat(p.value)).filter(v => !isNaN(v));

                if (values.length === 0) {
                    canvas.parentNode.innerHTML = '<p style="color:red;">⚠️ Все значения некорректны</p>';
                    return;
                }

                new Chart(canvas.getContext('2d'), {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: '',
                            data: values,
                            borderColor: '#00c6ff',
                            backgroundColor: 'rgba(0, 198, 255, 0.1)',
                            fill: true,
                            tension: 0.4,
                            pointRadius: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: { legend: false },
                        scales: {
                            x: { display: false },
                            y: { beginAtZero: false }
                        }
                    }
                });
            })
            .catch(err => {
                console.error(`Ошибка графика для ${topic}:`, err);
                canvas.parentNode.innerHTML = '<p style="color:red;">⚠️ Ошибка загрузки данных</p>';
            });
    });
});
</script>
</body>
</html>
