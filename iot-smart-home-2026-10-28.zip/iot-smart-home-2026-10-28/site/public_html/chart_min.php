<?php
require_once '/var/www/html/iot/config/iot_config.php';

// Подключение к БД
$pdo = iot_pdo();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Топик для отображения
$topic = 'sensors/livingroom/temperature';

// Получаем последнее значение
$stmt = $pdo->prepare("SELECT value, timestamp FROM sensor_data WHERE topic = ?");
$stmt->execute([$topic]);
$data = $stmt->fetch();

$value = $data['value'] ?? 'Нет данных';
$timestamp = $data['timestamp'] ?? '—';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>🌡️ График температуры</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js "></script>
</head>
<body>

<h2>Гостиная: Температура</h2>
<p><strong>Последнее значение:</strong> <?= htmlspecialchars($value) ?> °C  
<br>
<strong>Время:</strong> <?= htmlspecialchars($timestamp) ?></p>

<canvas id="chart" width="600" height="200"></canvas>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const ctx = document.getElementById('chart').getContext('2d');

    fetch('/api/history.php?topic=sensors/livingroom/temperature')
        .then(res => res.json())
        .then(data => {
            if (!data.length) {
                document.getElementById('chart').style.display = 'none';
                document.body.innerHTML += '<p>Нет данных для построения графика</p>';
                return;
            }

            const labels = data.map(p => p.timestamp.split(' ')[1]);
            const values = data.map(p => parseFloat(p.value));

            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Температура (°C)',
                        data: values,
                        borderColor: '#ff5722',
                        backgroundColor: 'rgba(255, 87, 34, 0.1)',
                        fill: true,
                        tension: 0.4,
                        pointRadius: 0
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: false
                    },
                    scales: {
                        x: { display: false },
                        y: {
                            beginAtZero: false,
                            title: {
                                display: true,
                                text: '°C'
                            }
                        }
                    }
                }
            });
        })
        .catch(err => {
            console.error('Ошибка загрузки истории:', err);
            document.getElementById('chart').style.display = 'none';
            document.body.innerHTML += '<p style="color:red;">Ошибка загрузки данных</p>';
        });
});
</script>

</body>
</html>
