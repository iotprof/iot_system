<?php
require_once '/var/www/html/iot/config/iot_config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->query("
        SELECT s.topic, s.value, MAX(s.timestamp) as last_time, i.name, i.room, i.icon
        FROM sensor_data s
        LEFT JOIN sensor_info i ON s.topic = i.topic
        GROUP BY s.topic
    ");
    $rows = $stmt->fetchAll();

    $topics = [];
    foreach ($rows as $row) {
        $type = basename($row['topic']);
        $unit = match($type) {
            'temperature' => '°C',
            'humidity' => '%',
            'light' => 'лк',
            'pm25' => 'мкг/м³',
            'co2' => 'ppm',
            default => ''
        };

        if (!empty($unit)) {
            $topics[] = [
                'topic' => $row['topic'],
                'value' => $row['value'],
                'timestamp' => $row['last_time'],
                'name' => $row['name'] ?: ucfirst($type),
                'room' => $row['room'] ?: 'Неизвестная комната',
                'icon' => $row['icon'] ?? '📡',
                'unit' => $unit
            ];
        }
    }

} catch (PDOException $e) {
    die("Ошибка базы данных: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>📊 Графики по кнопке</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js "></script>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f9f9f9; }
        h1 { color: #333; }
        .sensor-card {
            background: white;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }
        canvas {
            width: 100% !important;
            height: auto !important;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<h1>📉 Графики датчиков (по кнопке)</h1>

<?php if (empty($topics)): ?>
    <p>Нет данных для построения графиков.</p>
<?php else: ?>

    <?php foreach ($topics as $data): ?>
        <div class="sensor-card" id="card-<?= rawurlencode((string)$data['topic']) ?>">
            <h3><?= htmlspecialchars($data['name']) ?> (<?= htmlspecialchars($data['room']) ?>)</h3>
            <p><strong>Последнее значение:</strong> <?= htmlspecialchars($data['value']) ?> <?= htmlspecialchars($data['unit']) ?> 
                &nbsp;&nbsp;<em><?= htmlspecialchars($data['timestamp']) ?></em></p>
            <button onclick="loadChart('<?= rawurlencode((string)$data['topic']) ?>')">Показать график</button>
            <div class="chart-container"></div>
        </div>
    <?php endforeach; ?>

<?php endif; ?>


<script>
function loadChart(encodedTopic) {
    console.log('loadChart вызвана с encodedTopic:', encodedTopic);
    
    const topic = decodeURIComponent(encodedTopic);
    console.log('Расшифрованный topic:', topic);

    const container = document.querySelector(`#card-${encodedTopic} .chart-container`);
    console.log('Контейнер для графика:', container);

    if (!container) {
        console.error('Ошибка: контейнер не найден!');
        return;
    }

    container.innerHTML = '<p>⏳ Загрузка данных...</p>';

    fetch(`/api/history.php?topic=${encodeURIComponent(topic)}`)
        .then(res => {
            console.log('Статус ответа:', res.status);
            return res.json();
        })
        .then(data => {
            console.log('Полученные данные:', data);

            if (!data || !data.length) {
                container.innerHTML = '<p style="color:red;">❌ Нет данных</p>';
                return;
            }

            const labels = data.map(p => p.timestamp.split(' ')[1]);
            const values = data.map(p => parseFloat(p.value));

            const canvasId = `chart-${Date.now()}`;
            container.innerHTML = `<canvas id="${canvasId}" height="100"></canvas>`;
            
            new Chart(document.getElementById(canvasId).getContext('2d'), {
                type: 'line',
                 {
                    labels: labels,
                    datasets: [{
                        label: '°C',
                         values,
                        borderColor: '#00c6ff',
                        backgroundColor: 'rgba(0, 198, 255, 0.1)',
                        fill: true,
                        tension: 0.4,
                        pointRadius: 0
                    }]
                },
                options: {
                    responsive: true,
                    plugins: { legend: false },
                    scales: {
                        x: { display: false },
                        y: { beginAtZero: false }
                    }
                }
            });
        })
        .catch(err => {
            console.error(`❌ Ошибка загрузки графика для ${topic}:`, err);
            container.innerHTML += `<p style="color:red;">Ошибка: ${err.message}</p>`;
        });
}
</script>

</body>
</html>
