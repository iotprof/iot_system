<body>
    <!-- Блок погоды -->
    <div class="card weather-card">
        <div class="title">🌤 Погода сейчас</div>
        <div id="weather-moscow">Загрузка... Москва</div>
        <div id="weather-kaluga">Загрузка... Калуга</div>
    </div>

    <!-- Тестовая группа -->
    <div class="group">
        <h2 onclick="toggleGroup(this)">
            Тестовая группа <span class="arrow">▼</span>
        </h2>
        <div class="group-content" id="group-content">
            <div class="card">
                <div class="title">📡 Датчик</div>
                <div class="value">25 °C</div>
            </div>
        </div>
    </div>

    <!-- Скрипты -->
    <script>
        function toggleGroup(header) {
            const group = header.closest('.group');
            const content = group.querySelector('.group-content');
            const arrow = header.querySelector('.arrow');

            const isHidden = content.classList.contains('hidden');
            content.classList.toggle('hidden', !isHidden);

            if (arrow) {
                arrow.style.transform = isHidden ? 'rotate(-90deg)' : 'rotate(0deg)';
            }
        }

        async function getWeather(lat, lon, city) {
            try {
                const res = await fetch(` https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`);
                const data = await res.json();

                const temp = data.current_weather.temperature;
                const wind = data.current_weather.windspeed;

                document.getElementById(`weather-${city.toLowerCase()}`).innerHTML = `
                    📍 ${city}<br>
                    Температура: <strong>${temp}°C</strong><br>
                    Ветер: <strong>${wind} км/ч</strong>
                `;
            } catch (e) {
                document.getElementById(`weather-${city.toLowerCase()}`).innerText = `Ошибка загрузки (${city})`;
            }
        }

        getWeather(55.75, 37.62, 'Moscow');
        getWeather(54.52, 36.25, 'Kaluga');
    </script>
</body>
