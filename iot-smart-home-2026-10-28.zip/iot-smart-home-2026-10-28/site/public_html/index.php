<?php
require_once '/var/www/html/iot/config/iot_config.php';

date_default_timezone_set('Europe/Moscow');

try {
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // === Последнее выполненное правило ===
    $stmt_last = $pdo->prepare("
        SELECT 
            rule_name as name,
            triggered_at as last_triggered,
            action_topic,
            action_payload,
            confirmed,
            confirmed_at
        FROM automation_log
        WHERE skipped = 0
        ORDER BY triggered_at DESC
        LIMIT 1
    ");
    $stmt_last->execute();
    $last_executed_rule = $stmt_last->fetch(PDO::FETCH_ASSOC);

    if ($last_executed_rule && !empty($last_executed_rule['action_payload'])) {
        $payload = json_decode($last_executed_rule['action_payload'], true);
        $last_executed_rule['payload_str'] = is_array($payload)
            ? implode(', ', array_map(fn($k, $v) => "$k: $v", array_keys($payload), array_values($payload)))
            : $last_executed_rule['action_payload'];
    }

    // === Ближайшие автоматизации ===
    $upcoming_tasks = [];
    $stmt_tasks = $pdo->prepare("
        SELECT id, name, schedule_type, schedule_time, schedule_days,
               action_topic, action_payload, delay_seconds, enabled
        FROM automations
        WHERE enabled = 1 AND schedule_type != 'none'
        ORDER BY
            CASE WHEN schedule_type = 'daily' THEN schedule_time END ASC,
            CASE WHEN schedule_type = 'weekly' THEN schedule_time END ASC
    ");
    $stmt_tasks->execute();
    $tasks = $stmt_tasks->fetchAll(PDO::FETCH_ASSOC);

    foreach ($tasks as $task) {
        $next_run = null;
        $display_time = '';
        if ($task['schedule_type'] === 'daily') {
            $now = new DateTime();
            $run_time = new DateTime($task['schedule_time']);
            $run_time->setDate($now->format('Y'), $now->format('m'), $now->format('d'));
            if ($run_time < $now) $run_time->modify('+1 day');
            $next_run = $run_time;
            $display_time = substr($task['schedule_time'], 0, 5);
        } elseif ($task['schedule_type'] === 'weekly') {
            $days_map = ['mon' => 1, 'tue' => 2, 'wed' => 3, 'thu' => 4, 'fri' => 5, 'sat' => 6, 'sun' => 0];
            $now = new DateTime();
            $scheduled_days = explode(',', $task['schedule_days'] ?? '');
            $next_day = null;
            foreach ($scheduled_days as $day) {
                if (!isset($days_map[$day])) continue;
                $day_num = $days_map[$day];
                $current_day = (int)$now->format('N');
                $days_ahead = ($day_num - $current_day + 7) % 7;
                if ($days_ahead == 0 && $now->format('H:i:s') >= $task['schedule_time']) {
                    $days_ahead = 7;
                }
                $candidate = clone $now;
                $candidate->modify("+{$days_ahead} days");
                $candidate->setTime((int)substr($task['schedule_time'], 0, 2), (int)substr($task['schedule_time'], 3, 2), 0);
                if (!$next_day || $candidate < $next_day) $next_day = $candidate;
            }
            $next_run = $next_day;
            $display_time = substr($task['schedule_time'], 0, 5);
        }
        $action_desc = json_decode($task['action_payload'], true);
        $payload_str = is_array($action_desc)
            ? implode(', ', array_map(fn($k, $v) => "$k: $v", array_keys($action_desc), array_values($action_desc)))
            : $task['action_payload'];
        $upcoming_tasks[] = [
            'name' => $task['name'],
            'time' => $display_time,
            'action' => $task['action_topic'],
            'payload' => $payload_str,
            'next_run' => $next_run ? $next_run->format('Y-m-d H:i:s') : null,
            'status' => '⏳ Ожидает',
            'id' => $task['id']
        ];
    }
    if (!empty($upcoming_tasks)) {
        usort($upcoming_tasks, fn($a, $b) => strtotime($a['next_run']) <=> strtotime($b['next_run']));
        $next_scheduled = $upcoming_tasks[0];
    } else {
        $next_scheduled = null;
    }

    // === RPi данные ===
    $rpi_data = null;
    $stmt_rpi = $pdo->query("SELECT * FROM rpi_monitor ORDER BY timestamp DESC LIMIT 1");
    $rpi_data = $stmt_rpi->fetch(PDO::FETCH_ASSOC);

    // === Лог-статистика ===
    $log_stats = [];
    $stmt_log = $pdo->prepare("SELECT keyword, count FROM log_stats WHERE date = ?");
    $stmt_log->execute([date('Y-m-d')]);
    $log_rows = $stmt_log->fetchAll(PDO::FETCH_ASSOC);
    foreach ($log_rows as $row) {
        $log_stats[$row['keyword']] = (int)$row['count'];
    }

    // === Статусы сервисов ===
    $services_to_check = [
        'iot-automation.service',
        'mqtt-to-mysql.service',
        'zigbee2mqtt.service',
        'mosquitto.service',
    ];
    $service_statuses = [];
    // === ПОЛУЧЕНИЕ CRON ЗАДАЧ ===
    $user_cron_tasks = [];
    $cron_file = __DIR__ . '/crontab_all.txt';
    
    if (file_exists($cron_file) && is_readable($cron_file)) {
        $cron_content = file_get_contents($cron_file);
        $lines = explode("\n", $cron_content);
        
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line) || str_starts_with($line, '#')) continue;
            
            if (preg_match('/^(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(.+)$/', $line, $matches)) {
                $schedule = "{$matches[1]} {$matches[2]} {$matches[3]} {$matches[4]} {$matches[5]}";
                $command = $matches[6];
                
                if (strpos($command, 'anacron') !== false) continue;
                if (strpos($command, 'e2scrub') !== false) continue;
                
                // Человеко-читаемое описание
                $human_desc = $schedule;
                if (preg_match('/^\*\/(\d+)$/', $matches[1], $m) && $matches[2] == '*' && $matches[3] == '*' && $matches[4] == '*' && $matches[5] == '*') {
                    $human_desc = "🔄 Каждые {$m[1]} минут";
                } elseif ($matches[1] == '0' && $matches[2] == '*' && $matches[3] == '*' && $matches[4] == '*' && $matches[5] == '*') {
                    $human_desc = "⏰ Каждый час";
                } elseif ($matches[1] == '0' && is_numeric($matches[2]) && $matches[3] == '*' && $matches[4] == '*' && $matches[5] == '*') {
                    $human_desc = "📅 Ежедневно в " . str_pad($matches[2], 2, '0', STR_PAD_LEFT) . ":00";
                }
                
                $user_cron_tasks[] = [
                    'schedule' => $schedule,
                    'command' => $command,
                    'human_desc' => $human_desc,
                ];
            }
        }
    }

    // Системные задачи из /etc/crontab
    $system_cron = [];
    if (file_exists('/etc/crontab')) {
        $system_lines = file('/etc/crontab', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($system_lines as $line) {
            $line = trim($line);
            if (empty($line) || str_starts_with($line, '#')) continue;
            
            if (preg_match('/^(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(.+)$/', $line, $matches)) {
                $schedule = "{$matches[1]} {$matches[2]} {$matches[3]} {$matches[4]} {$matches[5]}";
                $user = $matches[6];
                $command = $matches[7];
                
                if (str_contains($command, 'anacron')) continue;
                
                $system_cron[] = [
                    'schedule' => $schedule,
                    'user' => $user,
                    'command' => $command,
                ];
            }
        }
    }

    foreach ($services_to_check as $service) {
        $status = trim(shell_exec("systemctl is-active " . escapeshellarg($service) . " 2>&1"));
        $is_active = ($status === 'active');
        $service_statuses[] = [
            'name' => str_replace('.service', '', $service),
            'status' => $status,
            'is_active' => $is_active,
        ];
    }

    // === Батарейки: сводка для карточки. Расчёт — include/battery_lib.php ===
    // Пороги живут в таблице battery_spec (элементы разные: CR2032, AAA, AA),
    // поэтому одна общая константа тут не годится.
    require_once __DIR__ . '/include/battery_lib.php';
    $battery_rows   = [];
    $battery_counts = ['dead' => 0, 'replace' => 0, 'stale' => 0, 'unknown' => 0, 'ok' => 0, 'total' => 0];
    try {
        $battery_rows   = iot_battery_status($pdo);
        $battery_counts = iot_battery_counts($battery_rows);
    } catch (Throwable $e) {
        error_log('index.php: батарейки — ' . $e->getMessage());
    }

} catch (Exception $e) {
    die("Ошибка БД: " . htmlspecialchars($e->getMessage()));
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <meta name="theme-color" content="#0a0e12">
    <title>⚡️ IoT Суперпанель</title>
    <link rel="stylesheet" href="/css/style.css">
<!-- PWA Support -->
<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#0a0e12">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="IoT Home">

</head>
<body>

<div class="container">
    <?php include '/var/www/html/iot/public_html/include/links_panel.php';?>

    <h1>⚡️ IoT Система</h1>

    <!-- Вкладки -->
    <div class="tabs">
        <button class="tab-btn active" onclick="switchTab('dashboard')">📊 Дашборд</button>
        <button class="tab-btn" onclick="switchTab('cron')">⏰ Cron Задачи</button>
    </div>

    <!-- ==================== ВКЛАДКА ДАШБОРД ==================== -->
    <div id="tab-dashboard" class="tab-content active">
        
        <!-- Первая строка: Статус автоматизации + Железо -->
        <div class="sensors-grid" style="margin-bottom: 1rem;">
            <!-- Карточка статуса автоматизации -->
            <div class="sensor-card">
                <div class="card-header">
                    <span class="sensor-icon">🧠</span>
                    <span class="sensor-topic">Статус автоматизации</span>
                    <span class="history-badge history-yes">🟢 Активно</span>
                </div>
                <div class="card-body">
                    <div class="sensor-property">
                        <span class="property-label">🕔 Текущее время</span>
                        <span class="property-value" id="current-time"><?= date('Y-m-d H:i:s') ?></span>
                    </div>
                    <?php if ($last_executed_rule): ?>
                    <div class="sensor-property">
                        <span class="property-label">✅ Последнее правило</span>
                        <span class="property-value">
                            <strong><?= htmlspecialchars($last_executed_rule['name']) ?></strong><br>
                            <small><?= htmlspecialchars($last_executed_rule['last_triggered']) ?></small>
                        </span>
                    </div>
                    <div class="sensor-property">
                        <span class="property-label">📦 Действие</span>
                        <span class="property-value">
                            <code><?= htmlspecialchars($last_executed_rule['action_topic']) ?></code>
                        </span>
                    </div>
                    <div class="sensor-property">
                        <span class="property-label">📨 Payload</span>
                        <span class="property-value">
                            <code><?= htmlspecialchars($last_executed_rule['payload_str']) ?></code>
                        </span>
                    </div>
                    <div class="sensor-property">
                        <span class="property-label">✅ Подтверждение</span>
                        <?php $le_conf = $last_executed_rule['confirmed']; ?>
                        <span class="property-value <?= ($le_conf === null || (int)$le_conf === 1) ? 'success' : 'warning' ?>">
                            <?= $le_conf === null ? 'Выполнено (подтверждение не требуется)'
                                  : ((int)$le_conf === 1 ? 'Подтверждено' : 'Ждём ответа устройства...') ?>
                        </span>
                    </div>
                    <?php else: ?>
                    <div class="sensor-property">
                        <span class="property-label">✅ Последнее правило</span>
                        <span class="property-value">— нет данных —</span>
                    </div>
                    <?php endif; ?>
                    <?php if ($next_scheduled): ?>
                    <div class="sensor-property">
                        <span class="property-label">⏱️ Следующее</span>
                        <span class="property-value">
                            <strong><?= htmlspecialchars($next_scheduled['name']) ?></strong><br>
                            <small>в <?= htmlspecialchars($next_scheduled['next_run']) ?></small>
                        </span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Карточка статуса железа (полная) -->
            <?php if ($rpi_data): 
                $temp = floatval($rpi_data['cpu_temp'] ?? 0);
                $temp_class = $temp > 70 ? 'error' : ($temp > 60 ? 'warning' : 'success');
                $disk = floatval($rpi_data['disk_usage'] ?? 0);
                $disk_class = $disk > 90 ? 'error' : ($disk > 70 ? 'warning' : 'success');
                $nvme_temp = floatval($rpi_data['nvme_temp'] ?? 0);
                $nvme_class = $nvme_temp > 70 ? 'error' : ($nvme_temp > 60 ? 'warning' : 'success');
                $volt = floatval($rpi_data['volt_core'] ?? 0);
                $volt_class = $volt < 4.8 ? 'error' : ($volt < 5.0 ? 'warning' : 'success');
            ?>
            <div class="sensor-card">
                <div class="card-header">
                    <span class="sensor-icon">🖥️</span>
                    <span class="sensor-topic">Статус железа</span>
                    <span class="history-badge history-yes">Raspberry Pi</span>
                </div>
                <div class="card-body">
                    <div class="sensor-property">
                        <span class="property-label">🌡️ Температура CPU</span>
                        <span class="property-value <?= $temp_class ?>"><?= htmlspecialchars($rpi_data['cpu_temp']) ?>°C</span>
                    </div>
                    <div class="sensor-property">
                        <span class="property-label">⚡ Загрузка CPU</span>
                        <span class="property-value"><?= htmlspecialchars($rpi_data['cpu_load']) ?>%</span>
                    </div>
                    <div class="sensor-property">
                        <span class="property-label">🧠 Память</span>
                        <span class="property-value"><?= htmlspecialchars($rpi_data['mem_used']) ?> / <?= htmlspecialchars($rpi_data['mem_total']) ?> MB</span>
                    </div>
                    <div class="sensor-property">
                        <span class="property-label">💽 Диск</span>
                        <span class="property-value <?= $disk_class ?>"><?= htmlspecialchars($rpi_data['disk_usage']) ?>%</span>
                    </div>
                    <div class="sensor-property">
                        <span class="property-label">💾 NVMe температура</span>
                        <span class="property-value <?= $nvme_class ?>"><?= htmlspecialchars($rpi_data['nvme_temp'] ?? 'N/A') ?>°C</span>
                    </div>
                    <div class="sensor-property">
                        <span class="property-label">🌀 Вентилятор</span>
                        <span class="property-value"><?= htmlspecialchars($rpi_data['fan_speed'] ?? 'N/A') ?></span>
                    </div>
                    <div class="sensor-property">
                        <span class="property-label">🔋 Напряжение ядра</span>
                        <span class="property-value <?= $volt_class ?>"><?= htmlspecialchars($rpi_data['volt_core'] ?? 'N/A') ?>V</span>
                    </div>
                    <div class="sensor-timestamp">🏠 IP: <?= htmlspecialchars($rpi_data['ip_addresses']) ?></div>
                    <div class="sensor-timestamp">⏱️ Uptime: <?= htmlspecialchars($rpi_data['uptime']) ?></div>
                    <div class="sensor-timestamp">🕒 Обновлено: <?= htmlspecialchars($rpi_data['timestamp']) ?></div>
                </div>
            </div>

            <!-- Карточка активности сервисов + анализ логов -->
            <div class="sensor-card">
                <div class="card-header">
                    <span class="sensor-icon">🔧</span>
                    <span class="sensor-topic">Сервисы и логи</span>
                    <span class="history-badge history-yes">systemd</span>
                </div>
                <div class="card-body">
                    <div class="sensor-property">
                        <span class="property-label">🤖 IoT Automation</span>
                        <span class="property-value <?= $service_statuses[0]['is_active'] ? 'success' : 'error' ?>">
                            <?= $service_statuses[0]['is_active'] ? '✅ active' : '❌ inactive' ?>
                        </span>
                    </div>
                    <div class="sensor-property">
                        <span class="property-label">💾 MQTT to MySQL</span>
                        <span class="property-value <?= $service_statuses[1]['is_active'] ? 'success' : 'error' ?>">
                            <?= $service_statuses[1]['is_active'] ? '✅ active' : '❌ inactive' ?>
                        </span>
                    </div>
                    <div class="sensor-property">
                        <span class="property-label">🔌 Zigbee2MQTT</span>
                        <span class="property-value <?= $service_statuses[2]['is_active'] ? 'success' : 'error' ?>">
                            <?= $service_statuses[2]['is_active'] ? '✅ active' : '❌ inactive' ?>
                        </span>
                    </div>
                    <div class="sensor-property">
                        <span class="property-label">📡 Mosquitto</span>
                        <span class="property-value <?= $service_statuses[3]['is_active'] ? 'success' : 'error' ?>">
                            <?= $service_statuses[3]['is_active'] ? '✅ active' : '❌ inactive' ?>
                        </span>
                    </div>
                    <?php if (!empty($log_stats)): ?>
                    <hr style="margin: 0.5rem 0;">
                    <div class="sensor-property">
                        <span class="property-label">📊 Анализ логов</span>
                        <span class="property-value">
                            <?php foreach ($log_stats as $keyword => $count): ?>
                                <div><?= ucfirst(htmlspecialchars($keyword)) ?>: <strong><?= $count ?></strong></div>
                            <?php endforeach; ?>
                        </span>
                    </div>
                    <div class="sensor-timestamp">Обновляется каждый час</div>
                    <?php endif; ?>
                    <div class="sensor-timestamp">🕒 Проверено: <?= date('H:i:s') ?></div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Ближайшие автоматизации -->
        <div class="card" style="margin-bottom: 1.5rem;">
            <div class="card-header">
                <span class="card-title">⏰ Ближайшие автоматизации</span>
            </div>
            <div class="card-body">
                <?php if (!empty($upcoming_tasks)): ?>
                    <div class="sensors-grid">
                        <?php foreach (array_slice($upcoming_tasks, 0, 6) as $task): ?>
                            <div class="sensor-card" style="margin: 0;">
                                <div class="card-header">
                                    <span class="sensor-icon">📅</span>
                                    <span class="sensor-topic"><?= htmlspecialchars($task['name']) ?></span>
                                    <span class="history-badge history-yes">⏳</span>
                                </div>
                                <div class="card-body">
                                    <div class="sensor-property">
                                        <span class="property-label">⏰ Время</span>
                                        <span class="property-value"><?= htmlspecialchars($task['time']) ?></span>
                                    </div>
                                    <div class="sensor-property">
                                        <span class="property-label">🔧 Действие</span>
                                        <span class="property-value"><code><?= htmlspecialchars($task['action']) ?></code></span>
                                    </div>
                                    <div class="sensor-property">
                                        <span class="property-label">📦 Payload</span>
                                        <span class="property-value"><code><?= htmlspecialchars($task['payload']) ?></code></span>
                                    </div>
                                    <div class="sensor-property">
                                        <span class="property-label">⏱️ Следующий запуск</span>
                                        <span class="property-value"><small><?= htmlspecialchars($task['next_run']) ?></small></span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">Нет активных автоматизаций</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Погода -->
        <div class="card">
            <div class="card-header">
                <span class="card-title">🌤️ Погода сейчас</span>
            </div>
            <div class="card-body">
                <div class="sensors-grid">
                    <div class="sensor-card" style="margin: 0;">
                        <div class="card-header">
                            <span class="sensor-icon">📍</span>
                            <span class="sensor-topic">Москва</span>
                        </div>
                        <div class="card-body" id="weather-moscow">Загрузка...</div>
                    </div>
                    <div class="sensor-card" style="margin: 0;">
                        <div class="card-header">
                            <span class="sensor-icon">📍</span>
                            <span class="sensor-topic">Калуга</span>
                        </div>
                        <div class="card-body" id="weather-kaluga">Загрузка...</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <!-- Батарейки: сводка. Логика — include/battery_lib.php, полная таблица — /admin/batteries.php -->
        <div class="card" style="margin-bottom: 1.5rem;">
            <div class="card-header">
                <span class="card-title">🔋 Батарейки</span>
                <?php if (!empty($battery_rows)): ?>
                    <span class="history-badge <?= $battery_counts['dead'] ? 'badge-error' : 'badge-success' ?>">
                        ⛔ вышли из строя: <?= $battery_counts['dead'] ?>
                    </span>
                    <span class="history-badge <?= $battery_counts['replace'] ? 'badge-warning' : 'badge-success' ?>">
                        🟠 пора менять: <?= $battery_counts['replace'] ?>
                    </span>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <?php if (empty($battery_rows)): ?>
                    <div class="empty-state">Нет данных — проверь таблицу battery_spec</div>
                <?php else: ?>
                    <?php
                    // В карточку на главной выносим только то, что требует внимания.
                    // Полный список со всеми цифрами — на /admin/batteries.php.
                    $card_rows = array_values(array_filter($battery_rows, fn($r) => $r['state'] !== 'ok'));
                    ?>
                    <?php if (empty($card_rows)): ?>
                        <div class="sensor-property">
                            <span class="property-label">Состояние</span>
                            <span class="property-value success">
                                🟢 Все <?= (int)$battery_counts['total'] ?> устройств с батарейками в норме
                            </span>
                        </div>
                    <?php else: ?>
                        <?php foreach ($card_rows as $r): ?>
                            <div class="sensor-property">
                                <span class="property-label">
                                    <?= $r['icon'] ?> <?= htmlspecialchars($r['title']) ?>
                                </span>
                                <span class="property-value <?= $r['state'] === 'dead' ? 'error' : ($r['state'] === 'replace' ? 'warning' : '') ?>">
                                    <?= htmlspecialchars($r['badge_label']) ?>
                                    <?php if ($r['pct'] !== null): ?> · <?= rtrim(rtrim(number_format($r['pct'], 1, ',', ' '), '0'), ',') ?> %<?php endif; ?>
                                    <?php if ($r['mv'] !== null): ?> · <?= number_format($r['mv'], 0, ',', ' ') ?> мВ<?php endif; ?>
                                    <br>
                                    <small>
                                        <?= htmlspecialchars($r['element']) ?><?= $r['reason'] !== '' ? ' — ' . htmlspecialchars($r['reason']) : '' ?>
                                        <?php if ($r['state'] === 'stale' && $r['batt_ts']): ?> · последние данные: <?= htmlspecialchars(iot_battery_ago($r['batt_ts'])) ?><?php endif; ?>
                                    </small>
                                </span>
                            </div>
                        <?php endforeach; ?>
                        <?php if ($battery_counts['ok']): ?>
                            <div class="sensor-timestamp">🟢 ещё <?= (int)$battery_counts['ok'] ?> в норме</div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <div style="margin-top: 0.85rem;">
                        <a href="/admin/batteries.php" class="nav-link" style="display:inline-flex">🔎 Все устройства, пороги и история напряжений</a>
                    </div>
                    <div class="sensor-timestamp">🕒 Проверено: <?= date('H:i:s') ?> · пороги — таблица battery_spec</div>
                <?php endif; ?>
            </div>
        </div>

    <!-- ==================== ВКЛАДКА CRON ЗАДАЧИ ==================== -->
    <!-- ==================== ВКЛАДКА CRON ЗАДАЧИ ==================== -->
    <div id="tab-cron" class="tab-content">
        
        <!-- Пользовательские задачи -->
        <div class="card" style="margin-bottom: 1.5rem;">
            <div class="card-header">
                <span class="card-title">👤 Ваши Cron задачи</span>
                <span class="history-badge history-yes">crontab -u mazzick</span>
            </div>
            <div class="card-body">
                <?php if (!empty($user_cron_tasks)): ?>
                    <?php foreach ($user_cron_tasks as $task): ?>
                        <div class="sensor-card" style="margin-bottom: 0.75rem;">
                            <div class="card-header">
                                <span class="sensor-icon">⏰</span>
                                <span class="sensor-topic"><?= htmlspecialchars($task['human_desc']) ?></span>
                                <span class="cron-badge"><?= htmlspecialchars($task['schedule']) ?></span>
                            </div>
                            <div class="card-body">
                                <div class="command" style="font-size: 0.7rem; background: var(--bg-input); padding: 0.5rem; border-radius: 8px; overflow-x: auto;">
                                    <?= htmlspecialchars($task['command']) ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">📭 Нет пользовательских cron задач</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Системные задачи -->
        <?php if (!empty($system_cron)): ?>
        <div class="card" style="margin-bottom: 1.5rem;">
            <div class="card-header">
                <span class="card-title">⚙️ Системные Cron задачи</span>
                <span class="history-badge history-yes">/etc/crontab</span>
            </div>
            <div class="card-body">
                <?php foreach ($system_cron as $task): ?>
                    <div class="sensor-card" style="margin-bottom: 0.75rem;">
                        <div class="card-header">
                            <span class="sensor-icon">⚙️</span>
                            <span class="sensor-topic"><?= htmlspecialchars($task['schedule']) ?></span>
                            <span class="cron-badge">👤 <?= htmlspecialchars($task['user']) ?></span>
                        </div>
                        <div class="card-body">
                            <div class="command" style="font-size: 0.7rem; background: var(--bg-input); padding: 0.5rem; border-radius: 8px; overflow-x: auto;">
                                <?= htmlspecialchars($task['command']) ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Информация -->
        <div class="card">
            <div class="card-header">
                <span class="card-title">ℹ️ О Cron задачах</span>
            </div>
            <div class="card-body">
                <div class="sensor-property">
                    <span class="property-label">📌 Управление задачами</span>
                    <span class="property-value"><code>crontab -e</code></span>
                </div>
                <div class="sensor-property">
                    <span class="property-label">📌 Системные задачи</span>
                    <span class="property-value"><code>/etc/crontab</code></span>
                </div>
                <div class="sensor-property">
                    <span class="property-label">💡 Примеры</span>
                    <span class="property-value">
                        <code>*/5 * * * *</code> — каждые 5 минут<br>
                        <code>0 * * * *</code> — каждый час<br>
                        <code>0 9 * * *</code> — ежедневно в 09:00
                    </span>
                </div>
                <div class="sensor-timestamp">🔄 Обновлено: <?= date('Y-m-d H:i:s') ?></div>
            </div>
        </div>
    </div>


</div>

<script>
    function switchTab(tabName) {
        document.querySelectorAll('.tab-content').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.getElementById(`tab-${tabName}`).classList.add('active');
        event.target.classList.add('active');
    }

    async function getWeather(lat, lon, city) {
        try {
            const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&hourly=relativehumidity_2m,pressure_msl&timezone=auto`);
            const d = await res.json();
            const t = d.current_weather.temperature;
            const w = d.current_weather.windspeed;
            const p = d.hourly.pressure_msl[0]?.toFixed(0) || '?';
            const h = d.hourly.relativehumidity_2m[0] || '?';
            document.getElementById(`weather-${city.toLowerCase()}`).innerHTML = `
                <div class="sensor-property"><span class="property-label">🌡️ Температура</span><span class="property-value">${t}°C</span></div>
                <div class="sensor-property"><span class="property-label">💨 Ветер</span><span class="property-value">${w} км/ч</span></div>
                <div class="sensor-property"><span class="property-label">💧 Влажность</span><span class="property-value">${h}%</span></div>
                <div class="sensor-property"><span class="property-label">📊 Давление</span><span class="property-value">${p} гПа</span></div>
            `;
        } catch (e) {
            document.getElementById(`weather-${city.toLowerCase()}`).innerHTML = `<div class="empty-state">⚠️ Ошибка загрузки</div>`;
        }
    }

    function updateSystemPanel() {
        fetch('/api/live_system_data.php')
            .then(r => r.json())
            .then(data => {
                document.getElementById('current-time').textContent = data.current_time;
            })
            .catch(console.error);
    }

    document.addEventListener('DOMContentLoaded', () => {
        getWeather(55.75, 37.62, 'Moscow');
        getWeather(54.52, 36.25, 'Kaluga');
        updateSystemPanel();
        setInterval(updateSystemPanel, 30000);
    });
</script>

</body>
</html>
