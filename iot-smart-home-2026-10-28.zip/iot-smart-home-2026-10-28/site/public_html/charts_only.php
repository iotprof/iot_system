<?php
require_once '/var/www/html/iot/config/iot_config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Подключение к БД
$pdo = iot_pdo();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Получаем все топики с последними значениями + info
$stmt = $pdo->query("
    SELECT s.topic, s.value, MAX(s.timestamp) as last_time, i.name, i.room, i.group_name, i.icon
    FROM sensor_data s
    LEFT JOIN sensor_info i ON s.topic = i.topic
    GROUP BY s.topic
");
$rows = $stmt->fetchAll();

// Формируем массив
$topics = [];
foreach ($rows as $row) {
    $type = basename($row['topic']);
    $unit = match($type) {
        'temperature' => '°C',
        'humidity' => '%',
        'light' => 'лк',
        'pm25' => 'мкг/м³',
        'co2' => 'ppm',
        default => ''
    };

    if (!empty($unit)) {
        $topics[$row['topic']] = [
            'value' => $row['value'],
            'timestamp' => $row['last_time'],
            'name' => $row['name'] ?: ucfirst(basename($row['topic'])),
            'room' => $row['room'] ?: 'Неизвестная комната',
            'group' => $row['group_name'] ?: 'Без группы',
            'type' => $type,
            'unit' => $unit,
            'icon' => $row['icon'] ?? '📡'
        ];
    }
}



?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>📊 Все графики</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js "></script>
</head>
<body>

<h1>📉 Графики датчиков</h1>

<?php if (empty($topics)): ?>
    <p>Нет данных для построения графиков.</p>
<?php else: ?>

    <?php foreach ($topics as $topic => $data): ?>
        <div style="width: 600px; margin-bottom: 40px;">
            <h3><?= htmlspecialchars($data['name']) ?> (<?= htmlspecialchars($data['room']) ?>)</h3>
            <p><strong>Последнее значение:</strong> <?= htmlspecialchars($data['value']) ?> <?= htmlspecialchars($data['unit']) ?></p>
            <canvas id="chart-<?= urlencode((string)$data['topic']) ?>" height="100"></canvas>
        </div>
    <?php endforeach; ?>

<?php endif; ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('canvas[id^="chart-"]').forEach(canvas => {
        const topic = canvas.id.replace('chart-', '');

        fetch('/api/history.php?topic=' + decodeURIComponent(topic))
            .then(res => res.json())
            .then(data => {
                if (!data.length) return;

                const labels = data.map(p => p.timestamp.split(' ')[1]);
                const values = data.map(p => parseFloat(p.value));

                new Chart(canvas.getContext('2d'), {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: '',
                            data: values,
                            borderColor: '#00c6ff',
                            backgroundColor: 'rgba(0, 198, 255, 0.1)',
                            fill: true,
                            tension: 0.4,
                            pointRadius: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: { legend: false },
                        scales: {
                            x: { display: false },
                            y: { beginAtZero: false }
                        }
                    }
                });
            })
            .catch(err => {
                console.error('Ошибка графика:', err);
                canvas.parentNode.innerHTML += '<p style="color:red;">Ошибка загрузки данных</p>';
            });
    });
});
</script>

</body>
</html>
