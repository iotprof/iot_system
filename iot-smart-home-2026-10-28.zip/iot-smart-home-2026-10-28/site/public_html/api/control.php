<?php
header("Content-Type: application/json");

$topic = $_GET['topic'] ?? '';
$state = strtoupper($_GET['state'] ?? '');

if (!$topic || !$state) {
    echo json_encode(['status' => 'error', 'message' => 'Неверные параметры']);
    exit;
}

// Поддерживаемые типы устройств
$valid_types = ['valve'];

$type = basename(urldecode($topic));

if (!in_array($type, $valid_types)) {
    echo json_encode(['status' => 'error', 'message' => 'Этот тип не поддерживает управление']);
    exit;
}

// Пример: valve → zigbee2mqtt/sensors/bathroom/valve/set → {"state": "ON"}
$mqtt_topic = escapeshellarg("zigbee2mqtt/" . urldecode($topic) . "/set");
$payload = escapeshellarg(json_encode(["state" => $state]));

exec("mosquitto_pub -h 127.0.0.1 -p 1883 -t $mqtt_topic -m $payload");

echo json_encode([
    'status' => 'ok',
    'topic' => $topic,
    'command' => $state
]);
