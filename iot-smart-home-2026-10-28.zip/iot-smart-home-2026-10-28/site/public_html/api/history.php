<?php
require_once '/var/www/html/iot/config/iot_config.php';

// /var/www/html/iot/public_html/api/history.php
header('Content-Type: application/json');

date_default_timezone_set('Europe/Moscow');

$topic = $_GET['topic'] ?? '';
$period = $_GET['period'] ?? 'day';

if (empty($topic)) {
    echo json_encode([]);
    exit;
}

// Маппинг периодов в SQL-интервалы
$intervals = [
    'hour'  => 'INTERVAL 1 HOUR',
    'day'   => 'INTERVAL 1 DAY',
    'week'  => 'INTERVAL 7 DAY',
    'month' => 'INTERVAL 30 DAY',
    'year'  => 'INTERVAL 365 DAY'
];

$interval = $intervals[$period] ?? 'INTERVAL 1 DAY';

try {
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Для больших периодов (месяц, год) — усредняем по часам, чтобы не тормозить
    if ($period === 'month' || $period === 'year') {
        $query = "
            SELECT 
                DATE_FORMAT(timestamp, '%Y-%m-%d %H:00:00') as timestamp,
                AVG(value) as value
            FROM sensor_history
            WHERE topic = :topic 
                AND timestamp > NOW() - $interval
            GROUP BY DATE_FORMAT(timestamp, '%Y-%m-%d %H:00:00')
            ORDER BY timestamp ASC
        ";
    } else {
        $query = "
            SELECT 
                timestamp,
                value
            FROM sensor_history
            WHERE topic = :topic 
                AND timestamp > NOW() - $interval
            ORDER BY timestamp ASC
        ";
    }

    $stmt = $pdo->prepare($query);
    $stmt->execute([':topic' => $topic]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Ограничиваем количество точек для производительности
    $maxPoints = 500;
    if (count($rows) > $maxPoints) {
        $step = ceil(count($rows) / $maxPoints);
        $rows = array_filter($rows, function($key) use ($step) {
            return $key % $step === 0;
        }, ARRAY_FILTER_USE_KEY);
        $rows = array_values($rows);
    }

    echo json_encode($rows, JSON_NUMERIC_CHECK);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
