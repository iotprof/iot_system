<?php
require_once '/var/www/html/iot/config/iot_config.php';

// /var/www/html/iot/public_html/api/clear_history.php
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$topic = $input['topic'] ?? '';

if (empty($topic)) {
    http_response_code(400);
    echo json_encode(['error' => 'Topic is required']);
    exit;
}

try {
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Удаляем только записи по конкретному топику
    $stmt = $pdo->prepare("DELETE FROM sensor_history WHERE topic = :topic");
    $stmt->execute([':topic' => $topic]);

    echo json_encode(['success' => true, 'deleted' => $stmt->rowCount()]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
