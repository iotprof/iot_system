<?php
require_once '/var/www/html/iot/config/iot_config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

try {
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Проверяем ежедневный сброс
    $stmt_check = $pdo->prepare("SELECT 1 FROM daily_resets WHERE reset_date = ?");
    $stmt_check->execute([date('Y-m-d')]);
    $daily_reset_today = $stmt_check->fetch() !== false;
    
    echo json_encode([
        'current_time' => date('Y-m-d H:i:s'),
        'daily_reset_today' => $daily_reset_today,
        'timestamp' => time()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'current_time' => date('Y-m-d H:i:s'),
        'daily_reset_today' => false,
        'error' => $e->getMessage()
    ]);
}
?>
