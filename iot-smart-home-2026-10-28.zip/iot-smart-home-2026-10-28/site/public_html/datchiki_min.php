<?php
require_once '/var/www/html/iot/config/iot_config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Подключение к БД
$pdo = iot_pdo();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Получаем последние значения с информацией о типе
$stmt = $pdo->query("
    SELECT s.topic, s.value, MAX(s.timestamp) as last_time, i.name, i.room, i.group_name, i.icon
    FROM sensor_data s
    LEFT JOIN sensor_info i ON s.topic = i.topic
    GROUP BY s.topic
");
$rows = $stmt->fetchAll();

// Формируем массив с данными
$topics = [];
foreach ($rows as $row) {
    $type = basename($row['topic']);
    $unit = match($type) {
        'temperature' => '°C',
        'humidity' => '%',
        'light' => 'лк',
        'pm25' => 'мкг/м³',
        'co2' => 'ppm',
        default => ''
    };

    if ($unit !== '') {
        $topics[$row['topic']] = [
            'value' => $row['value'],
            'timestamp' => $row['last_time'],
            'name' => $row['name'] ?: ucfirst(basename($row['topic'])),
            'room' => $row['room'] ?: 'Неизвестная комната',
            'group' => $row['group_name'] ?: 'Без группы',
            'type' => $type,
            'unit' => $unit,
            'icon' => $row['icon'] ?? '📡'
        ];
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>📊 Графики</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js "></script>
</head>
<body>

<h2>🌡️ Температура и влажность</h2>

<main>
    <?php foreach ($topics as $data): ?>
        <div class="card <?= htmlspecialchars((string)$data['type']) ?>">
            <div class="title">
                <?= htmlspecialchars((string)$data['name']) ?> (<?= htmlspecialchars((string)$data['room']) ?>)
            </div>
            <div class="value">
                <?= htmlspecialchars((string)$data['value']) ?><?= htmlspecialchars((string)$data['unit']) ?>
            </div>
            <div class="timestamp">🕒 <?= date("H:i:s", strtotime((string)$data['timestamp'])) ?></div>

            <!-- График -->
            <canvas id="chart-<?= urlencode((string)$data['topic']) ?>" class="sensor-chart" height="100"></canvas>
        </div>
    <?php endforeach ?>
</main>

<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('canvas.sensor-chart').forEach(canvas => {
        const topic = canvas.id.replace('chart-', '');

        fetch('/api/history.php?topic=' + decodeURIComponent(topic))
            .then(res => res.json())
            .then(data => {
                if (!data.length) return;

                const labels = data.map(p => p.timestamp.split(' ')[1]);
                const values = data.map(p => parseFloat(p.value));

                new Chart(canvas.getContext('2d'), {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: '',
                             values,
                            borderColor: '#00c6ff',
                            backgroundColor: 'rgba(0, 198, 255, 0.1)',
                            fill: true,
                            tension: 0.4,
                            pointRadius: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: { legend: false },
                        scales: { x: { display: false }, y: { beginAtZero: false } }
                    }
                });
            })
            .catch(err => console.error('Ошибка графика:', err));
    });
});
</script>

</body>
</html>
