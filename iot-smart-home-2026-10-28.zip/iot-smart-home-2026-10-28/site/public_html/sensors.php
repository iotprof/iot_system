<?php
require_once '/var/www/html/iot/config/iot_config.php';

date_default_timezone_set('Europe/Moscow');

try {
    $pdo = iot_pdo();

    // Напряжение батарейки приходит в МИЛЛИВОЛЬТАХ, напряжение сети — в вольтах.
    // Без этого график батарейки подписывался бы «В» и вводил в заблуждение.
    $battery_mv_topics = [];
    try {
        foreach ($pdo->query("SELECT device FROM battery_spec WHERE active=1 AND has_voltage=1")
                     ->fetchAll(PDO::FETCH_COLUMN) as $__bd) {
            $battery_mv_topics["zigbee2mqtt/$__bd/voltage"] = true;
        }
    } catch (Throwable $e) {}

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare("
        SELECT 
            s.topic,
            s.value,
            s.timestamp as last_time,
            i.name,
            i.room,
            i.group_name,
            i.icon,
            h.first_seen
        FROM sensor_info i
        INNER JOIN sensor_data s ON i.topic = s.topic
        INNER JOIN (
            SELECT topic, MAX(timestamp) as max_time
            FROM sensor_data
            GROUP BY topic
        ) latest ON s.topic = latest.topic AND s.timestamp = latest.max_time
        INNER JOIN (
            SELECT topic, MIN(timestamp) as first_seen
            FROM sensor_history
            GROUP BY topic
        ) h ON i.topic = h.topic
        ORDER BY i.group_name, i.name
    ");

    $stmt->execute();
    $rows = $stmt->fetchAll();

    $topics = [];
    foreach ($rows as $row) {
        $type = basename($row['topic']);
        $is_batt_mv = isset($battery_mv_topics[$row['topic']]);

        $unit = match($type) {
            'temperature' => '°C',
            'humidity' => '%',
            'light', 'illuminance' => 'лк',
            'pm25' => 'мкг/м³',
            'co2' => 'ppm',
            'voltage' => $is_batt_mv ? 'мВ' : 'В',
            'current' => 'А',
            'power' => 'Вт',
            'energy' => 'кВт·ч',
            'battery' => '%',
            'pressure' => 'гПа',
            default => ''
        };

        $topics[] = [
            'topic' => $row['topic'],
            'value' => $row['value'] ?? 'Нет данных',
            'timestamp' => $row['last_time'] ?? '—',
            'name' => $row['name'] ?: ucfirst($type),
            'room' => $row['room'] ?: 'Неизвестная комната',
            'group' => $row['group_name'] ?: 'Без группы',
            'type' => $type,
            'unit' => $unit,
            'icon' => $row['icon'] ?? '📡',
            'first_seen' => $row['first_seen'] 
        ];
    }

    // Группировка
    $groups = [];
    foreach ($topics as $data) {
        $groupName = $data['group'];
        if (empty($groupName) || $groupName === 'Без группы') {
            $groupName = 'Общие';
        }
        if (!isset($groups[$groupName])) $groups[$groupName] = [];
        $groups[$groupName][] = $data;
    }

    $preferredOrder = ['Дом', 'Дача', 'Общие'];
    uksort($groups, function($a, $b) use ($preferredOrder) {
        $posA = array_search($a, $preferredOrder);
        $posB = array_search($b, $preferredOrder);
        if ($posA === false) $posA = 999;
        if ($posB === false) $posB = 999;
        return $posA - $posB;
    });

} catch (Exception $e) {
    die("Ошибка БД: " . htmlspecialchars($e->getMessage()));
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <meta name="theme-color" content="#0a0e12">
    <title>📊 IoT Датчики с графиками</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="/css/style.css">
    <style>
        canvas {
            max-height: 140px;
            width: 100%;
            margin-top: 0.75rem;
        }
        .sensor-card {
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        .sensor-card .card-body {
            flex: 1;
        }
        .sensor-value {
            text-align: center;
            padding: 0.5rem 0;
        }
        .sensor-value .value {
            font-size: 1.8rem;
            font-weight: 700;
        }
        .sensor-value .unit {
            color: var(--text-muted);
            font-size: 0.9rem;
        }
        @media (max-width: 480px) {
            .sensor-value .value {
                font-size: 1.4rem;
            }
            canvas {
                max-height: 100px;
            }
        }
        h2 {
            margin-top: 1.5rem;
            margin-bottom: 1rem;
        }
        h2:first-of-type {
            margin-top: 0;
        }
    </style>
</head>
<body>

<div class="container">
    <?php include '/var/www/html/iot/public_html/include/links_panel.php';?>

    <h1>📊 Датчики с графиками</h1>

    <?php if (empty($topics)): ?>
        <div class="empty-state">Нет доступных датчиков с графиками</div>
    <?php else: ?>
        <?php foreach ($groups as $groupName => $groupItems): ?>
            <h2><?= htmlspecialchars($groupName) ?></h2>
            <div class="sensors-grid">
                <?php foreach ($groupItems as $data): 
                    $safeId = 'sensor-' . base64_encode($data['topic']);
                    $chartId = 'chart-' . preg_replace('/[^a-zA-Z0-9]/', '_', $data['topic']);
                    
                    // Определяем класс для значения
                    $valueClass = '';
                    if ($data['type'] === 'temperature') {
                        $temp = floatval($data['value']);
                        if ($temp > 30) $valueClass = 'error';
                        elseif ($temp > 25) $valueClass = 'warning';
                        else $valueClass = 'success';
                    } elseif ($data['type'] === 'humidity') {
                        $hum = floatval($data['value']);
                        if ($hum > 70 || $hum < 30) $valueClass = 'warning';
                        else $valueClass = 'success';
                    } elseif ($data['type'] === 'battery') {
                        $bat = floatval($data['value']);
                        if ($bat < 20) $valueClass = 'error';
                        elseif ($bat < 50) $valueClass = 'warning';
                        else $valueClass = 'success';
                    }
                ?>
                    <div class="sensor-card" data-topic="<?= htmlspecialchars($data['topic']) ?>">
                        <div class="card-header">
                            <span class="sensor-icon"><?= htmlspecialchars($data['icon']) ?></span>
                            <span class="sensor-topic">
                                <?= htmlspecialchars($data['name']) ?>
                                <small style="color: var(--text-muted);">(<?= htmlspecialchars($data['room']) ?>)</small>
                            </span>
                            <span class="history-badge history-yes">📊</span>
                        </div>
                        <div class="card-body">
                            <div class="sensor-value">
                                <span class="value <?= $valueClass ?>"><?= htmlspecialchars($data['value']) ?></span>
                                <span class="unit"><?= htmlspecialchars($data['unit']) ?></span>
                            </div>
                            <div class="sensor-timestamp" style="text-align: center;">
                                🕔 <?= htmlspecialchars(date('j M Y, H:i', strtotime($data['timestamp']))) ?>
                            </div>
                            <?php if (!empty($data['first_seen'])): ?>
                                <div class="sensor-timestamp" style="text-align: center; font-size: 0.65rem;">
                                    📅 с <?= htmlspecialchars(date('j M Y', strtotime($data['first_seen']))) ?>
                                </div>
                            <?php endif; ?>
                            <canvas id="chart-<?= $chartId ?>"></canvas>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<script>
    const charts = {};

    document.querySelectorAll('canvas[id^="chart-"]').forEach(canvas => {
        const card = canvas.closest('.sensor-card');
        const topic = card ? card.getAttribute('data-topic') : null;
        if (!topic) return;

        const chart = new Chart(canvas.getContext('2d'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: '',
                    data: [],
                    borderColor: '#58a6ff',
                    backgroundColor: 'rgba(88, 166, 255, 0.1)',
                    fill: true,
                    tension: 0.3,
                    pointRadius: 0,
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: { 
                    legend: { display: false },
                    tooltip: { enabled: false }
                },
                scales: { 
                    x: { display: false },
                    y: { 
                        display: true,
                        grid: { color: 'rgba(255,255,255,0.05)' },
                        ticks: { color: '#8b949e', font: { size: 9 } }
                    }
                },
                animation: false
            }
        });
        charts[topic] = chart;
        loadChartData(topic);
    });

    async function loadChartData(topic) {
        try {
            const response = await fetch('/api/history.php?topic=' + encodeURIComponent(topic));
            const data = await response.json();
            if (!Array.isArray(data) || data.length < 2) return;
            
            const labels = data.map(p => {
                const time = p.timestamp.split(' ')[1];
                return time ? time.substring(0, 5) : '';
            });
            const values = data.map(p => parseFloat(p.value)).filter(v => !isNaN(v));
            if (values.length === 0) return;
            
            const chart = charts[topic];
            if (chart) {
                chart.data.labels = labels.slice(-30);
                chart.data.datasets[0].data = values.slice(-30);
                chart.update('none');
            }
        } catch (error) {
            console.error('Ошибка загрузки графика:', error);
        }
    }

    function getSafeId(topic) {
        return 'sensor-' + btoa(topic);
    }

    async function updateValues() {
        try {
            const response = await fetch('/api/live_data.php');
            const data = await response.json();
            if (!data.topics) return;
            
            data.topics.forEach(item => {
                const card = document.querySelector(`.sensor-card[data-topic="${item.topic}"]`);
                if (!card) return;
                
                const valueEl = card.querySelector('.value');
                const timeEl = card.querySelector('.sensor-timestamp');
                
                if (valueEl) {
                    valueEl.textContent = item.value;
                    
                    // Обновляем цвет для температуры
                    if (item.topic.includes('temperature')) {
                        const val = parseFloat(item.value);
                        valueEl.classList.remove('success', 'warning', 'error');
                        if (val > 30) valueEl.classList.add('error');
                        else if (val > 25) valueEl.classList.add('warning');
                        else valueEl.classList.add('success');
                    }
                }
                if (timeEl && timeEl.textContent.includes('🕔')) {
                    const newTimeEl = card.querySelector('.sensor-timestamp');
                    if (newTimeEl && !newTimeEl.textContent.includes('📅')) {
                        newTimeEl.innerHTML = '🕔 ' + item.timestamp;
                    }
                }
            });
        } catch (error) {
            console.error('Ошибка обновления:', error);
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        updateValues();
        setInterval(updateValues, 30000);
        setInterval(() => Object.keys(charts).forEach(loadChartData), 60000);
    });
</script>

</body>
</html>
