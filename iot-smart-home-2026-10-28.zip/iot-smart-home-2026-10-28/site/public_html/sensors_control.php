<?php
require_once '/var/www/html/iot/config/iot_config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Получаем все датчики + информация из sensor_info
    $stmt = $pdo->query("
        SELECT s.topic, MAX(s.value) AS value, MAX(s.timestamp) AS last_time,
               i.name, i.room, i.group_name, i.icon
        FROM sensor_data s
        LEFT JOIN sensor_info i ON s.topic = i.topic
        GROUP BY s.topic
    ");
    $rows = $stmt->fetchAll();

    $topics = [];

    foreach ($rows as $row) {
        $type = basename($row['topic']);
        $unit = match($type) {
            'temperature' => '°C',
            'humidity' => '%',
            'light' => 'лк',
            'pm25' => 'мкг/м³',
            'co2' => 'ppm',
            'water_pressure' => 'бар',
            'valve' => 'Вкл/Выкл',
            default => ''
        };

        if (!in_array($type, ['valve', 'temperature', 'humidity', 'light', 'pm25', 'co2'])) {
            continue;
        }

        $topics[] = [
            'topic' => $row['topic'],
            'value' => $row['value'] ?? 'Нет данных',
            'timestamp' => $row['last_time'] ?? '—',
            'type' => $type,
            'unit' => $unit,
            'name' => $row['name'] ?: ucfirst($type),
            'room' => $row['room'] ?: 'Неизвестная комната',
            'group' => $row['group_name'] ?: 'Без группы',
            'icon' => $row['icon'] ?: '📡'
        ];
    }

} catch (PDOException $e) {
    die("Ошибка базы данных: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>🎛️ Управление датчиками</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js "></script>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #121212;
            color: #fff;
            padding: 20px;
        }

        h1 {
            color: #00c6ff;
        }

        .group-section {
            margin-bottom: 40px;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }

        .card {
            background-color: #1f1f1f;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(0, 198, 255, 0.3);
        }

        .title {
            font-size: 18px;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
        }

        .icon {
            font-size: 20px;
        }

        .value {
            font-size: 24px;
            font-weight: bold;
            color: #00c6ff;
            margin-bottom: 10px;
        }

        .timestamp {
            font-size: 12px;
            color: #aaa;
            margin-bottom: 15px;
        }

        .controls {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }

        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s, color 0.3s;
        }

        .btn-on {
            background: #00c6ff;
            color: #000;
        }

        .btn-on:hover {
            background: #33daff;
        }

        .btn-off {
            background: #333;
            color: #ccc;
        }

        .btn-off:hover {
            background: #555;
        }
    </style>
</head>
<body>

<h1>🎛️ Панель управления IoT</h1>

<?php if (empty($topics)): ?>
    <p>Нет управляемых датчиков.</p>
<?php else: ?>

    <?php
    $groups = [];
    foreach ($topics as $data) {
        $groups[$data['group']][] = $data;
    }
    ?>

    <?php foreach ($groups as $groupName => $groupItems): ?>
        <div class="group-section">
            <h2><?= htmlspecialchars($groupName) ?></h2>

            <div class="grid">
                <?php foreach ($groupItems as $data): ?>
                    <div class="card">
                        <div class="title">
                            <span class="icon"><?= $data['icon'] ?></span>
                            <?= htmlspecialchars($data['name']) ?> 
                            <small style="color:#888">(<?= htmlspecialchars($data['room']) ?>)</small>
                        </div>
                        <div class="value"><?= htmlspecialchars((string)$data['value']) ?> <?= htmlspecialchars((string)$data['unit']) ?></div>
                        <div class="timestamp">🕒 <?= htmlspecialchars((string)$data['timestamp']) ?></div>

                        <!-- Управление -->
                        <?php if ($data['type'] === 'valve'): ?>
                            <div class="controls">
                                <button class="btn btn-on" onclick="sendCommand('<?= rawurlencode((string)$data['topic']) ?>', 'ON')">ВКЛ</button>
                                <button class="btn btn-off" onclick="sendCommand('<?= rawurlencode((string)$data['topic']) ?>', 'OFF')">ВЫКЛ</button>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>


<script>
function sendCommand(topic, state) {
    fetch(`/api/control.php?topic=${encodeURIComponent(topic)}&state=${encodeURIComponent(state)}`)
        .then(res => res.json())
        .then(data => {
            console.log(`Команда ${state} отправлена для ${topic}`);
        })
        .catch(err => {
            console.error('Ошибка отправки команды:', err);
        });
}
</script>

</body>
</html>
