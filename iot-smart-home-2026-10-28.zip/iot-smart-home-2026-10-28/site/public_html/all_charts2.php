<?php
require_once '/var/www/html/iot/config/iot_config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Получаем все топики из sensor_data (все датчики)
    $stmt = $pdo->query("
        SELECT s.topic, MAX(s.value) AS value, MAX(s.timestamp) AS last_time
        FROM sensor_data s
        GROUP BY s.topic
    ");
    $rows = $stmt->fetchAll();

    $topics = [];

    foreach ($rows as $row) {
        $type = basename($row['topic']);
        $unit = match($type) {
            'temperature' => '°C',
            'humidity' => '%',
            'light' => 'лк',
            'pm25' => 'мкг/м³',
            'co2' => 'ppm',
            'water_pressure' => 'бар',
            default => ''
        };

        $topics[] = [
            'topic' => $row['topic'],
            'value' => $row['value'] ?? 'Нет данных',
            'timestamp' => $row['last_time'] ?? '—',
            'type' => $type,
            'unit' => $unit
        ];
    }

} catch (PDOException $e) {
    die("Ошибка базы данных: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>📡 Все датчики</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js "></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #121212;
            color: #fff;
            padding: 20px;
        }

        h1 {
            color: #ffffff;
        }

        .card {
            background-color: #1e1e1e;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
        }

        .title {
            font-weight: bold;
            font-size: 18px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .icon {
            font-size: 20px;
        }

        .value {
            font-size: 24px;
            font-weight: bold;
            color: #00c6ff;
            margin-bottom: 10px;
        }

        .timestamp {
            font-size: 12px;
            color: #aaa;
            margin-bottom: 10px;
        }

        canvas {
            width: 100% !important;
            height: auto !important;
        }

        .no-chart {
            color: #888;
            font-style: italic;
        }

        .chart-wrapper {
            margin-top: 10px;
        }

        p {
            margin: 5px 0;
        }
    </style>
</head>
<body>

<h1>📉 Все датчики с графиками</h1>

<?php if (empty($topics)): ?>
    <p>Нет данных.</p>
<?php else: ?>
    <?php foreach ($topics as $data): ?>
        <?php
            $showChart = in_array($data['type'], ['temperature', 'humidity', 'light', 'pm25', 'co2']);
        ?>

        <div class="card">
            <div class="title">
                <span class="icon">📡</span>
                <?= htmlspecialchars($data['type']) ?> <small style="color:#888">(<?= htmlspecialchars($data['topic']) ?>)</small>
            </div>
            <div class="value">
                <?= htmlspecialchars((string)$data['value']) ?> <?= htmlspecialchars((string)$data['unit']) ?>
            </div>
            <div class="timestamp">🕒 <?= htmlspecialchars((string)$data['timestamp']) ?></div>

            <?php if ($showChart): ?>
                <div class="chart-wrapper">
                    <canvas id="chart-<?= rawurlencode((string)$data['topic']) ?>" height="100"></canvas>
                </div>
            <?php else: ?>
                <p class="no-chart">📊 Нет возможности построить график</p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
<?php endif; ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('canvas[id^="chart-"]').forEach(canvas => {
        const topic = decodeURIComponent(canvas.id.replace('chart-', ''));

        fetch('/api/history.php?topic=' + encodeURIComponent(topic))
            .then(res => res.json())
            .then(data => {
                if (!Array.isArray(data) || data.length === 0) {
                    canvas.parentNode.innerHTML += '<p style="color:red;">❌ Нет исторических данных</p>';
                    return;
                }

                const labels = data.map(p => p.timestamp.split(' ')[1]);
                const values = data.map(p => parseFloat(p.value)).filter(v => !isNaN(v));

                if (values.length === 0) {
                    canvas.parentNode.innerHTML += '<p style="color:orange;">⚠️ Все значения некорректны</p>';
                    return;
                }

                new Chart(canvas.getContext('2d'), {
                    type: 'line',
                     {
                        labels: labels,
                        datasets: [{
                            label: '',
                             values,
                            borderColor: '#00c6ff',
                            backgroundColor: 'rgba(0, 198, 255, 0.1)',
                            fill: true,
                            tension: 0.4,
                            pointRadius: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: { legend: false },
                        scales: {
                            x: { display: false },
                            y: { beginAtZero: false }
                        }
                    }
                });
            })
            .catch(err => {
                console.error(`Ошибка графика для ${topic}:`, err);
                canvas.parentNode.innerHTML += `<p style="color:red;">⚠️ Ошибка: ${err.message}</p>`;
            });
    });
});
</script>

</body>
</html>
