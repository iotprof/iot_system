<?php
require 'vendor/autoload.php';

use PhpMqtt\Client\MQTTClient;

echo "MQTTClient класс доступен!\n";
