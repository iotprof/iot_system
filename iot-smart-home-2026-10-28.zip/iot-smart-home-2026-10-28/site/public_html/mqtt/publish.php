<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $topic = $_POST['topic'] ?? '';
    $payload = $_POST['payload'] ?? '';

    if (!empty($topic)) {
        // Если payload == toggle, то просто отправляем команду "toggle"
        if ($payload === 'toggle') {
            exec("mosquitto_pub -h localhost -t '" . escapeshellcmd($topic) . "' -m 'toggle'");
        } else {
            // Иначе отправляем число
            exec("mosquitto_pub -h localhost -t '" . escapeshellcmd($topic) . "' -m '" . escapeshellcmd($payload) . "'");
        }
    }

    header("Location: /sensors_demo.php");
    exit;
}
?>
