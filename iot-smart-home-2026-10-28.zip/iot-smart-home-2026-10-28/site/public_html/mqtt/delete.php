<?php
if (!isset($_GET['topic'])) {
    die("Не указан топик для удаления");
}

$topic = $_GET['topic'];

try {
    $db = new PDO('sqlite:/var/www/html/db/sensors.db');
    $stmt = $db->prepare("DELETE FROM sensor_data WHERE topic = ?");
    $stmt->execute([$topic]);

    header("Location: ../datchiki.php");
} catch (PDOException $e) {
    die("Ошибка базы данных: " . $e->getMessage());
}
