<?php

require __DIR__ . '/vendor/autoload.php';

use PhpMqtt\Client\MqttClient;
use PhpMqtt\Client\ConnectionSettings;

// Подключение к SQLite
try {
    $db = new PDO('sqlite:/var/www/html/db/sensors.db');
} catch (PDOException $e) {
    die("Ошибка подключения к БД: " . $e->getMessage());
}

// Настройки MQTT
$server = 'localhost';
$port = 1883;
$clientId = uniqid('php-subscriber-');

// Создаём клиент
$client = new MqttClient($server, $port, $clientId);

// Настройки подключения
$settings = new ConnectionSettings([
    'clean_session' => true,
    'username' => null,
    'password' => null,
]);

echo "Connecting to MQTT broker...\n";
$client->connect($settings);

echo "Subscribing to topic 'sensors/#'\n";
$client->subscribe('sensors/#', function ($topic, $message) use ($db) {
    echo sprintf("Received message on [%s]: %s\n", $topic, $message);

    // Сохраняем в БД
    $stmt = $db->prepare("INSERT INTO sensor_data (topic, value) VALUES (?, ?)");
    $stmt->execute([$topic, $message]);
}, 0);

echo "Waiting for messages... Press CTRL+C to exit.\n";

$client->loop();
$client->disconnect();
