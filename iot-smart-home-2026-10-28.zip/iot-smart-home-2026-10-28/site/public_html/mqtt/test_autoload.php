<?php
require 'vendor/autoload.php';
echo "Autoload работает!\n";
