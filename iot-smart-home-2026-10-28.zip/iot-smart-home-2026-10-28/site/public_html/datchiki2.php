<?php
require_once '/var/www/html/iot/config/iot_config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Получаем все топики из sensor_data
    $stmt = $pdo->query("
        SELECT s.topic, MAX(s.value) AS value, MAX(s.timestamp) AS last_time
        FROM sensor_data s
        GROUP BY s.topic
    ");
    $rows = $stmt->fetchAll();

    $topics = [];

    foreach ($rows as $row) {
        $type = basename($row['topic']);
        $unit = match($type) {
            'temperature' => '°C',
            'humidity' => '%',
            'light' => 'лк',
            'pm25' => 'мкг/м³',
            'co2' => 'ppm',
            'water_pressure' => 'бар',
            default => ''
        };

        if (empty($unit)) continue;

        $topics[] = [
            'topic' => $row['topic'],
            'value' => $row['value'] ?? 'Нет данных',
            'timestamp' => $row['last_time'] ?? '—',
            'type' => $type,
            'unit' => $unit
        ];
    }

} catch (PDOException $e) {
    die("Ошибка базы данных: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>📡 Все датчики</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js "></script>
<link rel="stylesheet" href="/css/style.css">
</head>
<body>



<h1>📉 Все датчики</h1>







<main>
<?php if (empty($topics)): ?>
    <p>Нет данных.</p>
<?php else: ?>
    <?php foreach ($topics as $data): ?>
        <div class="card" id="card-<?= rawurlencode((string)$data['topic']) ?>">
                    <div class="title">
                        <?= $data['icon'] ?>
                        <?= htmlspecialchars((string)$data['name']) ?>
                        (<?= htmlspecialchars((string)$data['room']) ?>)
                    </div>
   <div class="value">
                        <?= htmlspecialchars((string)$data['value']) ?>
                        <?= htmlspecialchars((string)$data['unit']) ?>
                    </div>

  <div class="timestamp">🕒 <?= date("H:i:s", strtotime((string)$data['timestamp'])) ?></div>


            <h3><?= htmlspecialchars($data['type']) ?> <small style="color:#888">(<?= htmlspecialchars($data['topic']) ?>)</small></h3>
            <p><strong>Последнее значение:</strong> <?= htmlspecialchars((string)$data['value']) ?> <?= htmlspecialchars((string)$data['unit']) ?></p>
            <p><strong>Время:</strong> <?= htmlspecialchars((string)$data['timestamp']) ?></p>

            <?php if (in_array($data['type'], ['temperature', 'humidity', 'light', 'pm25', 'co2'])): ?>
                <canvas id="chart-<?= rawurlencode((string)$data['topic']) ?>" height="100"></canvas>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
</main>



<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('canvas[id^="chart-"]').forEach(canvas => {
        const topic = decodeURIComponent(canvas.id.replace('chart-', ''));

        fetch('/api/history.php?topic=' + encodeURIComponent(topic))
            .then(res => res.json())
            .then(data => {
                if (!Array.isArray(data) || data.length === 0) {
                    canvas.remove(); // Удаляем пустой график
                    return;
                }

                const labels = data.map(p => p.timestamp.split(' ')[1]);
                const values = data.map(p => parseFloat(p.value)).filter(v => !isNaN(v));

                if (values.length === 0) {
                    canvas.remove();
                    return;
                }

                new Chart(canvas.getContext('2d'), {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: '',
                            data: values,
                            borderColor: '#00c6ff',
                            backgroundColor: 'rgba(0, 198, 255, 0.1)',
                            fill: true,
                            tension: 0.4,
                            pointRadius: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: { legend: false },
                        scales: {
                            x: { display: false },
                            y: { beginAtZero: false }
                        }
                    }
                });
            })
            .catch(err => {
                console.error(`Ошибка графика для ${topic}:`, err);
                canvas.remove(); // Убираем график при ошибке
            });
    });
});
</script>
</body>
</html>
