<?php
$dataFile = __DIR__ . '/mqtt/data.txt';
if (!file_exists($dataFile)) {
    die("Нет данных от датчиков.");
}

$lines = file($dataFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$sensors = [];

foreach ($lines as $line) {
    list($topic, $value) = explode('=', $line, 2);
    $sensors[$topic] = $value;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>📡 Данные с датчиков</title>
    <style>
        body { font-family: sans-serif; padding: 2em; background: #f9f9f9 }
        h1 { color: #333 }
        .sensor { margin: 1em 0; padding: 1em; border: 1px solid #ccc; border-radius: 8px; background: white }
        a { color: #0066cc; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <h1>📊 Показания датчиков</h1>

    <?php if (empty($sensors)): ?>
        <p>Нет данных.</p>
    <?php else: ?>
        <?php foreach ($sensors as $topic => $value): ?>
            <div class="sensor">
                <strong><?= htmlspecialchars($topic) ?></strong>: <?= htmlspecialchars($value) ?>
            </div>
        <?php endforeach ?>
    <?php endif ?>

    <p><a href="">🔄 Обновить страницу</a></p>
</body>
</html>
