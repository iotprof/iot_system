<?php
require_once '/var/www/html/iot/config/iot_config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    // Подключение к БД
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Получаем последние значения + info о датчиках
    $stmt = $pdo->query("
        SELECT s.topic, s.value, MAX(s.timestamp) as last_time, i.name, i.room, i.group_name, i.icon
        FROM sensor_data s
        LEFT JOIN sensor_info i ON s.topic = i.topic
        GROUP BY s.topic
    ");
    $rows = $stmt->fetchAll();

    $topics = [];

    foreach ($rows as $row) {
        $type = basename($row['topic']);
        $unit = match($type) {
            'temperature' => '°C',
            'humidity' => '%',
            'light' => 'лк',
            'pm25' => 'мкг/м³',
            'co2' => 'ppm',
            'water_pressure' => 'бар',
            default => ''
        };

        if (empty($unit)) continue;

        $group = $row['group_name'] ?: 'Без группы';
        $icon = $row['icon'] ? "<span class='icon'>{$row['icon']}</span>" : "<span class='icon'>📡</span>";

        $topics[$row['topic']] = [
            'value' => $row['value'],
            'timestamp' => $row['last_time'],
            'name' => $row['name'] ?: ucfirst(basename($row['topic'])),
            'room' => $row['room'] ?: 'Неизвестная комната',
            'group' => $group,
            'type' => $type,
            'unit' => $unit,
            'icon' => $icon
        ];
    }

} catch (PDOException $e) {
    die("Ошибка базы данных: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>📡 IoT Интерфейс</title>
    <link rel="stylesheet" href="/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js "></script>
</head>
<body>

<header>🏡 Универсальный умный дом</header>

<main>
    <?php if (empty($topics)): ?>
        <p>Нет данных от датчиков.</p>
    <?php else: ?>
        <?php
        $groups = [];
        foreach ($topics as $topic => $data) {
            $groups[$data['group']][] = $data;
        }
        ?>

        <?php foreach ($groups as $groupName => $groupItems): ?>
            <h2><?= htmlspecialchars($groupName) ?></h2>

            <?php foreach ($groupItems as $data): ?>
                <div class="card <?= htmlspecialchars((string)$data['type']) ?>">
                    <div class="title">
                        <?= $data['icon'] ?>
                        <?= htmlspecialchars((string)$data['name']) ?>
                        (<?= htmlspecialchars((string)$data['room']) ?>)
                    </div>
                    <div class="value">
                        <?= htmlspecialchars((string)$data['value']) ?>
                        <?= htmlspecialchars((string)$data['unit']) ?>
                    </div>
                    <div class="timestamp">🕒 <?= date("H:i:s", strtotime((string)$data['timestamp'])) ?></div>

                    <!-- График -->
                    <?php if (!empty($data['topic']) && in_array($data['type'], ['temperature', 'humidity', 'light', 'pm25', 'co2'])): ?>
                        <canvas id="chart-<?= rawurlencode((string)$data['topic']) ?>" class="sensor-chart" height="100"></canvas>
                    <?php endif; ?>

                    <!-- Кнопка удаления -->
                    <?php if (!empty($data['topic'])): ?>
                        <div class="card-footer">
                            <a href="/mqtt/delete.php?topic=<?= urlencode((string)$data['topic']) ?>" onclick="return confirm('Удалить этот датчик?')">🗑️ Удалить</a>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>

            <div class="group-divider"></div>
        <?php endforeach; ?>
    <?php endif; ?>
</main>

<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('canvas.sensor-chart').forEach(canvas => {
        const topic = decodeURIComponent(canvas.id.replace('chart-', ''));

        fetch('/api/history.php?topic=' + encodeURIComponent(topic))
            .then(res => res.json())
            .then(data => {
                if (!Array.isArray(data) || data.length === 0) {
                    canvas.parentNode.innerHTML += '<p style="color:red;">❌ Нет исторических данных</p>';
                    return;
                }

                const labels = data.map(p => p.timestamp.split(' ')[1]);
                const values = data.map(p => parseFloat(p.value)).filter(v => !isNaN(v));

                if (values.length === 0) {
                    canvas.parentNode.innerHTML += '<p style="color:red;">⚠️ Все значения некорректны</p>';
                    return;
                }

                new Chart(canvas.getContext('2d'), {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: '',
                            data: values,
                            borderColor: '#00c6ff',
                            backgroundColor: 'rgba(0, 198, 255, 0.1)',
                            fill: true,
                            tension: 0.4,
                            pointRadius: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: { legend: false },
                        scales: {
                            x: { display: false },
                            y: { beginAtZero: false }
                        }
                    }
                });
            })
            .catch(err => {
                console.error(`Ошибка графика для ${topic}:`, err);
                canvas.parentNode.innerHTML += `<p style="color:red;">⚠️ Ошибка: ${err.message}</p>`;
            });
    });
});
</script>

<style>
    .sensor-chart {
        margin-top: 10px;
        margin-bottom: 30px;
    }
    .group-divider {
        clear: both;
        width: 100%;
        height: 20px;
        background: #f9f9f9;
        border-top: 1px solid #eee;
        margin: 30px 0;
    }
</style>

<footer>
    &copy; <?= date('Y') ?> — Универсальный IoT-интерфейс
</footer>

</body>
</html>
