<?php
require_once '/var/www/html/iot/config/iot_config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    // Подключение к БД
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Получаем все топики с последними значениями
    $stmt = $pdo->query("
        SELECT s.topic, s.value, MAX(s.timestamp) as last_time, i.name, i.room, i.icon
        FROM sensor_data s
        LEFT JOIN sensor_info i ON s.topic = i.topic
        GROUP BY s.topic
    ");
    $rows = $stmt->fetchAll();

    // Формируем массив датчиков
    $topics = [];
    foreach ($rows as $row) {
        $type = basename($row['topic']);
        $unit = match($type) {
            'temperature' => '°C',
            'humidity' => '%',
            'light' => 'лк',
            'pm25' => 'мкг/м³',
            'co2' => 'ppm',
            default => ''
        };

        if (!empty($unit)) {
            $topics[] = [
                'topic' => $row['topic'],
                'value' => $row['value'],
                'timestamp' => $row['last_time'],
                'name' => $row['name'] ?: ucfirst($type),
                'room' => $row['room'] ?: 'Неизвестная комната',
                'icon' => $row['icon'] ?? '📡',
                'unit' => $unit
            ];
        }
    }

} catch (PDOException $e) {
    die("Ошибка базы данных: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>📊 Все графики</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js "></script>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f9f9f9; }
        h1 { color: #333; }
        .chart-container {
            background: white;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 30px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }
        canvas { width: 100% !important; height: auto !important; }
    </style>
</head>
<body>

<h1>📉 Графики датчиков</h1>

<?php if (empty($topics)): ?>
    <p>Нет данных для построения графиков.</p>
<?php else: ?>

    <?php foreach ($topics as $data): ?>
        <div class="chart-container">
            <h3><?= htmlspecialchars($data['name']) ?> (<?= htmlspecialchars($data['room']) ?>)</h3>
            <p><strong>Последнее значение:</strong> <?= htmlspecialchars($data['value']) ?> <?= htmlspecialchars($data['unit']) ?> 
                &nbsp;&nbsp;<em><?= htmlspecialchars($data['timestamp']) ?></em></p>
            <canvas id="chart-<?= rawurlencode((string)$data['topic']) ?>" height="100"></canvas>
        </div>
    <?php endforeach; ?>

<?php endif; ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('canvas[id^="chart-"]').forEach(canvas => {
        const topic = decodeURIComponent(canvas.id.replace('chart-', ''));

        fetch(`/api/history.php?topic=${encodeURIComponent(topic)}`)
            .then(res => res.json())
            .then(data => {
                if (!data || !data.length) {
                    canvas.parentNode.innerHTML += '<p style="color:red;">Нет данных</p>';
                    return;
                }

                const labels = data.map(p => p.timestamp.split(' ')[1]);
                const values = data.map(p => parseFloat(p.value));
                const unit = data[0]?.unit || 'Ед.изм';

                new Chart(canvas.getContext('2d'), {
                    type: 'line',
                     {
                        labels: labels,
                        datasets: [{
                            label: unit,
                            data: values,
                            borderColor: '#00c6ff',
                            backgroundColor: 'rgba(0, 198, 255, 0.1)',
                            fill: true,
                            tension: 0.4,
                            pointRadius: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: { legend: false },
                        scales: {
                            x: { display: false },
                            y: { beginAtZero: false }
                        }
                    }
                });
            })
            .catch(err => {
                console.error(`Ошибка загрузки графика для ${topic}:`, err);
                canvas.parentNode.innerHTML += '<p style="color:red;">Ошибка загрузки данных</p>';
            });
    });
});
</script>

</body>
</html>
