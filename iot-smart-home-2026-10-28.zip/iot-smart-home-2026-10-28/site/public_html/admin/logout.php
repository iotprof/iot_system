<?php
session_start();
unset($_SESSION['iot_admin']);
header("Location: sensors.php");
exit;
