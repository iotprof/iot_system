<?php
/**
 * mqtt_listener.php — движок автоматизации умного дома. Ревизия 2 (12.10.2026).
 *
 * ЧТО ИЗМЕНИЛОСЬ И ПОЧЕМУ
 * Раньше движок раз в секунду вычитывал последние значения ВСЕХ датчиков из таблицы
 * sensor_data и сравнивал их с тем, что помнил. Отсюда: реакция «до секунды», тяжёлый
 * запрос к базе каждую секунду и ожидание подтверждений тоже из базы.
 *
 * Теперь движок СЛУШАЕТ БРОКЕР (Mosquitto) напрямую: подписывается на темы и получает
 * каждое сообщение в ту же секунду, как оно пришло от устройства. Правила при этом
 * остаются в базе (таблица automations) — как и просил владелец: «правила через базу,
 * а команды и подтверждения — сразу из брокера».
 *
 * Что осталось как было: правила ищутся в automations, перечитываются раз в 60 секунд,
 * пишутся строки в automation_log, работает выдержка условия, кулдаун, расписание,
 * ежедневный сброс, отложенные действия, удаление одноразовых правил.
 * Что ушло: опрос базы каждую секунду; отправка каждой команды отдельным процессом
 * mosquitto_pub (теперь команда уходит по тому же соединению; запасной путь на случай
 * обрыва сохранён).
 * Что появилось: мгновенная реакция на событие, мгновенная проверка подтверждения по
 * сообщению устройства, живые данные для проверки «устройство уже в нужном состоянии».
 *
 * Почему выдержка условия (condition_duration) всё равно считается по секундам:
 * условие может держаться без новых сообщений, поэтому такие правила дополнительно
 * перепроверяются раз в секунду тем же кодом, что и раньше.
 *
 * Письма о срабатываниях отправляет отдельное задание cron_automation_emails.php —
 * здесь почта не отправляется, как и в прежней версии.
 */

require_once '/var/www/html/iot/config/iot_config.php';
require_once __DIR__ . '/mqtt_client.php';

// Подключение к БД (правила, журнал срабатываний)
try {
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("❌ Ошибка подключения к БД: " . $e->getMessage() . "\n");
}

date_default_timezone_set('Europe/Moscow');

echo "🧠 IoT Automation Engine запущен (ревизия 2: слушаю брокер, правила — из базы).\n";
echo "🌍 Установлен часовой пояс: " . date_default_timezone_get() . "\n";

/* ==================================================================== состояние */

$rules = [];                  // активные правила
$ruleById = [];               // id => правило
$lastRuleReload = 0;
$lastScheduleCheck = 0;
$lastDailyReset = 0;
$lastScheduleAttempt = [];
$conditionStartTime = [];     // отсчёт выдержки условия
$conditionLastLog = [];       // когда в последний раз напоминали про отсчёт (чтобы не спамить журнал)
$pendingIds = [];             // ключ ожидания => номер строки в таблице pending_actions
$confirmDeadline = [];        // топик/правило => до какого времени ждём подтверждение
$sensorData = [];             // последнее значение по каждому топику (из брокера)
$lastTriggerState = [];       // правило+топик => значение, на которое уже сработали
$lastActionTime = [];         // правило => время последнего действия (кулдаун)
$pendingConfirmations = [];   // топик => [id правила => ожидаемое значение]
$scheduled = [];              // отложенные действия (delay_seconds)
$emailConditionStartTime = []; // оставлено с прежней версии

$topicIndex = ['trigger' => [], 'confirm' => [], 'depend' => []];  // быстрый поиск правил по топику

/** Топики, которые пишет zigbee2mqtt, но которые к датчикам не относятся. */
const IOT_SKIP_FIELDS = ['linkquality', 'countdown_l1', 'countdown_l2', 'countdown_l3',
                         'power_on_behavior_l1', 'power_on_behavior_l2', 'power_on_behavior_l3',
                         'last_seen', 'update', 'update_available'];

/* ==================================================================== правила */

/** Перечитывает правила из базы и строит указатель «топик → правила». */
function reloadRules($pdo) {
    global $rules, $lastRuleReload, $ruleById, $topicIndex, $client, $subscribed;

    $stmt = $pdo->prepare("SELECT * FROM automations WHERE enabled = 1");
    $stmt->execute();
    $rules = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $ruleById = [];
    $topicIndex = ['trigger' => [], 'confirm' => [], 'depend' => []];
    $want = ['zigbee2mqtt/#'];

    foreach ($rules as $rule) {
        $ruleById[$rule['id']] = $rule;
        foreach (['trigger_topic' => 'trigger', 'confirmation_topic' => 'confirm',
                  'dependency_topic' => 'depend'] as $field => $kind) {
            $t = trim((string)($rule[$field] ?? ''));
            if ($t === '') { continue; }
            $topicIndex[$kind][$t][] = $rule['id'];
            if (strpos($t, 'zigbee2mqtt/') !== 0) { $want[] = $t; }
        }

        // Состояние самого устройства: команда уходит в .../set, а состояние приходит в тему без /set.
        // Без этой подписки движок не знает, включено ли уже реле, и шлёт команду зря.
        $actState = trim((string)($rule['action_topic'] ?? ''));
        if ($actState !== '' && substr($actState, -4) === '/set') {
            $actState = substr($actState, 0, -4);
            if ($actState !== '' && strpos($actState, 'zigbee2mqtt/') !== 0) { $want[] = $actState; }
        }
    }

    $count = count($rules);
    echo "✅ Загружено $count активных правил.\n";
    if ($count === 0) {
        echo "⚠️ Нет активных правил. Добавьте в logic.php.\n";
    }

    // Подписываемся на темы, которых ещё не слушаем (например, добавлено новое правило в другой ветке).
    if ($client && $client->isConnected()) {
        $new = array_values(array_diff(array_unique($want), $subscribed));
        if ($new) {
            if ($client->subscribe($new)) {
                $subscribed = array_values(array_unique(array_merge($subscribed, $new)));
                echo "📡 Подписка добавлена: " . implode(', ', $new) . "\n";
            } else {
                echo "⚠️ Не удалось подписаться на: " . implode(', ', $new) . "\n";
            }
        }
    }

    $lastRuleReload = time();
}

/** Разовая загрузка последних значений из базы: чтобы триггеры и «уже включено» работали с первой секунды. */
function seedStateFromDb($pdo) {
    global $sensorData;

    try {
        $stmt = $pdo->prepare("
            SELECT topic, value
            FROM (
                SELECT topic, value, ROW_NUMBER() OVER (PARTITION BY topic ORDER BY timestamp DESC) as rn
                FROM sensor_data
            ) t
            WHERE rn = 1
        ");
        $stmt->execute();
    } catch (PDOException $e) {
        $stmt = $pdo->query("
            SELECT s1.topic, s1.value
            FROM sensor_data s1
            LEFT JOIN sensor_data s2
              ON s1.topic = s2.topic AND s1.timestamp < s2.timestamp
            WHERE s2.topic IS NULL
        ");
    }

    $sensorData = [];
    $n = 0;
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $decoded = json_decode($row['value'], true);
        $sensorData[$row['topic']] = (json_last_error() === JSON_ERROR_NONE && is_array($decoded))
            ? $decoded : $row['value'];
        $n++;
    }
    echo "🗂 Состояние загружено из базы: топиков $n (дальше обновляется сообщениями брокера).\n";
}

/* ==================================================================== брокер */

$client = null;
$subscribed = [];

/** Подключение к брокеру с повторами; после обрыва состояние берём заново из базы. */
function connectBroker($pdo, $firstTime = false) {
    global $client, $subscribed;

    $try = 0;
    while (true) {
        $try++;
        if ($client === null) {
            $client = new IotMqttClient(IOT_MQTT_HOST, IOT_MQTT_PORT, IOT_MQTT_USER, IOT_MQTT_PASS,
                                        'iot-automation-engine');
        }
        if ($client->connect()) {
            $subscribed = [];
            echo "📡 Брокер: соединение установлено (" . IOT_MQTT_HOST . ":" . IOT_MQTT_PORT . ").\n";
            reloadRules($pdo);          // заодно подпишет на нужные темы
            if (!$firstTime) {
                seedStateFromDb($pdo);
                pend_load($pdo);        // и незавершённые дела вернём из базы
            }
            return;
        }
        echo "⚠️ Брокер недоступен (" . $client->lastError() . "), жду 5 секунд, попытка $try.\n";
        sleep(5);
        $client = null;                 // пересоздать перед следующей попыткой
        if ($try >= 60) { $try = 0; }    // не копим счётчик бесконечно
    }
}

/** Проверяет правила, у которых ЭТОТ топик — триггер. */
function runTriggerRulesFor($topic) {
    global $topicIndex;

    if (empty($topicIndex['trigger'][$topic])) { return; }
    foreach ($topicIndex['trigger'][$topic] as $ruleId) {
        $rule = $GLOBALS['ruleById'][$ruleId] ?? null;
        if ($rule) { evaluateTriggerRule($rule); }
    }
}

/** Сообщение из брокера: обновляет состояние и сразу проверяет правила и подтверждения. */
function onBrokerMessage($topic, $payload) {
    global $sensorData, $topicIndex, $pendingConfirmations;

    if (strpos($topic, 'zigbee2mqtt/bridge/') === 0) { return; }   // служебные — мимо

    // Полное значение топика (для правил вида zigbee2mqtt/fish_power и проверки «уже включено»)
    $decoded = json_decode($payload, true);
    $isArray = (json_last_error() === JSON_ERROR_NONE && is_array($decoded));
    $sensorData[$topic] = $isArray ? $decoded : $payload;

    // Отдельные поля, ровно как их пишет логгер в базу (bool → '1'/'0')
    $fields = [];
    if ($isArray) {
        foreach ($decoded as $key => $value) {
            if (in_array($key, IOT_SKIP_FIELDS, true)) { continue; }
            if (is_bool($value)) { $value = $value ? '1' : '0'; }
            elseif (is_array($value)) { $value = json_encode($value, JSON_UNESCAPED_UNICODE); }
            $sensorData[$topic . '/' . $key] = (string)$value;
            $fields[] = $topic . '/' . $key;
        }
    }

    // Правила, чей триггер — сама тема устройства (например zigbee2mqtt/fish_power)
    runTriggerRulesFor($topic);

    // ...и правила, чей триггер — ПОЛЕ этой темы (например zigbee2mqtt/motion_sensor/presence).
    // Брокер присылает только JSON темы устройства, отдельных сообщений по полям нет, поэтому
    // без этой ветки такие правила не срабатывали вообще (найдено и исправлено 13.10.2026).
    foreach ($fields as $fieldTopic) {
        runTriggerRulesFor($fieldTopic);
    }

    // Подтверждения: если чего-то ждём — проверяем (ждёт обычно одно-два правила)
    if (!empty($pendingConfirmations)) {
        checkPendingConfirmations();
    }
}

/* ================================================== незавершённые дела (переживают перезапуск) */

/** Сколько ждать подтверждения от устройства, если оно так и не ответит (в секундах). */
const IOT_CONFIRM_TTL = 3600;
/** Насколько опоздавшее дело ещё имеет смысл выполнять после перезапуска (в секундах). */
const IOT_LATE_GRACE = 3600;

/** Отложенная команда: записываем в базу, возвращаем номер строки (или null — тогда работаем только в памяти). */
function pend_add_delay($pdo, $rule, $topic, $payload, $runAt) {
    try {
        $stmt = $pdo->prepare("INSERT INTO pending_actions (kind, rule_id, rule_name, topic, payload, run_at)
                               VALUES ('delay', ?, ?, ?, ?, ?)");
        $stmt->execute([$rule['id'], $rule['name'], $topic, $payload, date('Y-m-d H:i:s', $runAt)]);
        return (int)$pdo->lastInsertId();
    } catch (Exception $e) {
        echo "⚠️ Отложенная команда не сохранена в базу (перезапуск её потеряет): " . $e->getMessage() . "\n";
        return null;
    }
}

/** Ожидание подтверждения: записываем в базу и запоминаем срок ожидания. */
function pend_add_confirm($pdo, $rule, $topic, $expected, $deadline) {
    global $pendingIds, $confirmDeadline;

    $expectedText = is_array($expected) ? json_encode($expected, JSON_UNESCAPED_UNICODE) : (string)$expected;
    $id = null;
    try {
        $stmt = $pdo->prepare("INSERT INTO pending_actions (kind, rule_id, rule_name, topic, expected, run_at)
                               VALUES ('confirm', ?, ?, ?, ?, ?)");
        $stmt->execute([$rule['id'], $rule['name'], $topic, $expectedText, date('Y-m-d H:i:s', $deadline)]);
        $id = (int)$pdo->lastInsertId();
    } catch (Exception $e) {
        echo "⚠️ Ожидание подтверждения не сохранено в базу (перезапуск его потеряет): " . $e->getMessage() . "\n";
    }
    $pendingIds['confirm'][$topic][$rule['id']] = $id;
    $confirmDeadline[$topic][$rule['id']] = $deadline;
}

/** Дело закончилось: убираем строку из базы. */
function pend_done($pdo, $id) {
    if (!$id) { return; }
    try {
        $pdo->prepare("DELETE FROM pending_actions WHERE id = ?")->execute([$id]);
    } catch (Exception $e) {
        echo "⚠️ Не удалось убрать запись о деле из базы: " . $e->getMessage() . "\n";
    }
}

/**
 * Чтение незавершённых дел из базы — вызывается при запуске и после переподключения.
 * Опоздавшие отложенные команды (в пределах часа) выполняются сразу: если движок лежал,
 * кран или реле лучше довести до нужного состояния, чем забыть про них совсем.
 */
function pend_load($pdo) {
    global $scheduled, $pendingConfirmations, $pendingIds, $confirmDeadline, $ruleById;

    try {
        $rows = $pdo->query("SELECT * FROM pending_actions ORDER BY run_at")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        echo "⚠️ Таблица pending_actions недоступна — отложенные дела после перезапуска не подхватятся.\n";
        echo "   Создать: mysql iot_db < /var/www/html/iot/db/pending_actions.sql\n";
        return;
    }

    if (!$rows) { return; }
    $now = time();
    $restored = ['delay' => 0, 'confirm' => 0]; $dropped = 0;

    foreach ($rows as $r) {
        $runAt = strtotime((string)$r['run_at']);

        if ($r['kind'] === 'delay') {
            if ($runAt < $now - IOT_LATE_GRACE) {
                echo "🗑 Дело опоздало больше чем на час, не выполняю: " . $r['rule_name'] . " (ждём с " . $r['run_at'] . ")\n";
                pend_done($pdo, (int)$r['id']);
                $dropped++;
                continue;
            }
            // После переподключения списки могут уже содержать это дело — второй раз не берём.
            $already = false;
            foreach ($scheduled as $t) { if (($t['pid'] ?? null) == $r['id']) { $already = true; break; } }
            if ($already) { continue; }
            $scheduled[] = [
                'pid'        => (int)$r['id'],
                'execute_at' => $runAt,
                'topic'      => $r['topic'],
                'payload'    => (string)$r['payload'],
                'rule_name'  => (string)$r['rule_name'],
            ];
            $restored['delay']++;
            continue;
        }

        // confirm: ждём ответа устройства
        if ($runAt < $now || empty($ruleById[(int)$r['rule_id']])) {
            echo "🗑 Ожидание подтверждения больше не нужно: " . $r['rule_name'] . " (срок истёк или правило удалено)\n";
            pend_done($pdo, (int)$r['id']);
            $dropped++;
            continue;
        }
        $expected = $r['expected'];
        $decoded = json_decode((string)$expected, true);
        $pendingConfirmations[$r['topic']][(int)$r['rule_id']] = (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) ? $decoded : $expected;
        $pendingIds['confirm'][$r['topic']][(int)$r['rule_id']] = (int)$r['id'];
        $confirmDeadline[$r['topic']][(int)$r['rule_id']] = $runAt;
        $restored['confirm']++;
    }

    echo "♻️ Подхвачено незавершённых дел: отложенных команд " . $restored['delay']
       . ", ожиданий подтверждения " . $restored['confirm']
       . ($dropped ? ", выброшено устаревших $dropped" : "") . "\n";
    foreach ($scheduled as $t) {
        echo "   ⏱ ждёт выполнения: " . $t['rule_name'] . " в " . date('H:i:s', $t['execute_at']) . "\n";
    }
}

/** Проверка сроков ожидания подтверждений: если устройство так и не ответило — перестаём ждать. */
function pend_expire($pdo) {
    global $pendingConfirmations, $pendingIds, $confirmDeadline, $ruleById;

    if (empty($pendingConfirmations)) { return; }
    $now = time();

    foreach ($pendingConfirmations as $topic => $ruleList) {
        foreach ($ruleList as $ruleId => $expected) {
            if (!isset($confirmDeadline[$topic][$ruleId]) || $confirmDeadline[$topic][$ruleId] > $now) { continue; }

            $name = $ruleById[$ruleId]['name'] ?? ('правило ' . $ruleId);
            echo "⌛ Подтверждение от устройства не пришло за отведённое время: " . $name . " (топик " . $topic . ")\n";
            if (!empty($pendingIds['confirm'][$topic][$ruleId])) { pend_done($pdo, $pendingIds['confirm'][$topic][$ruleId]); }
            unset($pendingConfirmations[$topic][$ruleId], $pendingIds['confirm'][$topic][$ruleId], $confirmDeadline[$topic][$ruleId]);
        }
        if (empty($pendingConfirmations[$topic])) { unset($pendingConfirmations[$topic]); }
    }
}

/* ==================================================================== проверки */

/** Проверяет простое или скриптовое условие с учётом выдержки (condition_duration). */
function evaluateRuleCondition($rule) {
    global $conditionStartTime, $conditionLastLog, $sensorData;

    $ruleId = $rule['id'];
    $duration = (int)($rule['condition_duration'] ?? 0);

    $isSimple = !empty($rule['condition_operator']) && !empty($rule['condition_value']);
    $isScript = !empty($rule['condition_script']);

    if (!$isSimple && !$isScript) {
        unset($conditionStartTime[$ruleId]);
        return true;
    }

    $currentMet = false;

    if ($isSimple) {
        $currentMet = compareSensorValue($rule['trigger_topic'], $rule['condition_operator'], $rule['condition_value']);
    } else {
        try {
            $script = $rule['condition_script'];

            // Датчики: sensor["полный/топик"] — любые буквы (включая кириллицу), цифры, _ слэш дефис.
            // Сокращённая форма sensor.имя — для имён без слэшей.
            $script = preg_replace('/\bsensor\.([\p{L}\p{N}_\/\-]+)/u', '$sensorData[\'$1\']', $script);
            $script = preg_replace('/\bsensor\[([\'"])([\p{L}\p{N}_\/\-]+)\1\]/u', '$sensorData[\'$2\']', $script);
            $script = preg_replace('/\bdata\s*\[/', '$sensorData[', $script);

            if (!preg_match('/^[\p{L}\p{N}_\[\]\.\(\)\+\-\*\/\!\&\|\s\=\>\<\,\{\}\'"$]+$/u', $script)) {
                $bad = [];
                if (preg_match_all('/[^\p{L}\p{N}_\[\]\.\(\)\+\-\*\/\!\&\|\s\=\>\<\,\{\}\'"$]/u', $script, $mm)) {
                    $bad = array_unique($mm[0]);
                }
                throw new Exception('Недопустимые символы' . ($bad ? ': ' . implode(' ', $bad) : ''));
            }

            $forbidden = ['eval', 'exec', 'system', 'shell_exec', 'passthru', 'assert', 'include', 'require',
                          'unlink', 'file_put_contents', 'fopen', 'fwrite', 'mail', 'header', 'proc_open',
                          'popen', 'chmod', 'chown', 'rename', 'copy', 'mkdir', 'rmdir', 'symlink', 'touch',
                          'call_user_func', 'preg_replace', 'create_function', 'extract', 'putenv', 'ini_set'];
            foreach ($forbidden as $word) {
                if (stripos($script, $word) !== false) {
                    throw new Exception('Запрещённая функция: ' . $word);
                }
            }
            if (preg_match('/[\p{L}_][\p{L}\p{N}_]*\s*\(/u', $script)) {
                throw new Exception('В скриптовом условии запрещены вызовы функций (для времени используйте расписание)');
            }

            $probe = preg_replace('/\$sensorData\[[^\]]*\]/', '0', $script);
            $probe = preg_replace('/"[^"]*"|\'[^\']*\'/', '0', $probe);
            $probe = preg_replace('/\b(true|false|null)\b/i', '0', $probe);
            if (preg_match('/[\p{L}_][\p{L}\p{N}_]*/u', $probe, $m)) {
                throw new Exception('В условии непонятное имя «' . $m[0] . '». Датчик указывать так: sensor["полный/топик"]');
            }

            $result = @eval('return (' . $script . ');');
            if ($result === false) {
                $le = error_get_last();
                if ($le && in_array($le['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
                    throw new Exception('выражение не вычислилось: ' . substr($le['message'], 0, 140));
                }
            }
            $currentMet = (bool)$result;
        } catch (Exception $e) {
            $errKey = 'script_err_' . $rule['id'];
            if (!isset($GLOBALS['scriptErrorLast'][$errKey]) || time() - $GLOBALS['scriptErrorLast'][$errKey] > 60) {
                $GLOBALS['scriptErrorLast'][$errKey] = time();
                echo "❌ Ошибка в скриптовом условии '" . $rule['name'] . "': " . $e->getMessage() . "\n";
            }
            $currentMet = false;
        }
    }

    if ($duration <= 0) {
        unset($conditionStartTime[$ruleId]);
        return $currentMet;
    }

    if ($currentMet) {
        if (!isset($conditionStartTime[$ruleId])) {
            $conditionStartTime[$ruleId] = time();
            $conditionLastLog[$ruleId] = time();
            echo "⏳ Условие для правила '" . $rule['name'] . "' стало истинным. Начинаем отсчет $duration сек.\n";
            return false;
        }
        $elapsed = time() - $conditionStartTime[$ruleId];
        if ($elapsed >= $duration) {
            unset($conditionStartTime[$ruleId], $conditionLastLog[$ruleId]);
            echo "✅ Условие для правила '" . $rule['name'] . "' выполнялось $duration сек — можно срабатывать!\n";
            return true;
        }
        // Отсчёт идёт без новых событий, поэтому напоминаем о нём не чаще раза в 10 секунд:
        // раньше строка печаталась каждую секунду и журнал рос на 15 тысяч строк в сутки.
        if (!isset($conditionLastLog[$ruleId]) || time() - $conditionLastLog[$ruleId] >= 10) {
            $conditionLastLog[$ruleId] = time();
            echo "⏳ Условие выполняется уже $elapsed сек из $duration для правила '" . $rule['name'] . "'.\n";
        }
        return false;
    }

    if (isset($conditionStartTime[$ruleId])) {
        echo "⚠️ Условие для правила '" . $rule['name'] . "' перестало выполняться — отсчет сброшен.\n";
        unset($conditionStartTime[$ruleId], $conditionLastLog[$ruleId]);
    }
    return false;
}

/** Сравнение значения датчика с порогом (числа — числами, строки — строками). */
function compareSensorValue($topic, $operator, $value) {
    global $sensorData;

    if ($topic === '' || !isset($sensorData[$topic])) { return false; }
    $actual = $sensorData[$topic];
    if (is_array($actual) && isset($actual['state'])) { $actual = $actual['state']; }

    $numActual = is_numeric($actual) ? (float)$actual : null;
    $numValue = is_numeric($value) ? (float)$value : null;

    switch ($operator) {
        case '>':  return $numActual !== null && $numValue !== null ? $numActual > $numValue : $actual > $value;
        case '<':  return $numActual !== null && $numValue !== null ? $numActual < $numValue : $actual < $value;
        case '==': return $actual == $value;
        case '!=': return $actual != $value;
        case '>=': return $numActual !== null && $numValue !== null ? $numActual >= $numValue : $actual >= $value;
        case '<=': return $numActual !== null && $numValue !== null ? $numActual <= $numValue : $actual <= $value;
        default:   return false;
    }
}

/** Устройство уже в нужном состоянии? Тогда команду не отправляем. */
function shouldSkipAction($rule) {
    global $sensorData;

    $actionPayload = json_decode($rule['action_payload'], true);
    if (!is_array($actionPayload)) return false;

    $stateTopic = preg_replace('/\/set$/', '', $rule['action_topic']);
    if ($stateTopic === $rule['action_topic']) return false;
    if (!isset($sensorData[$stateTopic])) return false;

    $currentState = $sensorData[$stateTopic];
    if (!is_array($currentState)) {
        $decoded = json_decode($currentState, true);
        if (is_array($decoded)) { $currentState = $decoded; } else { return false; }
    }

    foreach ($actionPayload as $key => $desiredValue) {
        if (!isset($currentState[$key]) || (string)$currentState[$key] !== (string)$desiredValue) {
            return false;
        }
    }
    return true;
}

/* ==================================================================== действия */

/** Отправка команды: по тому же соединению с брокером; если оно упало — запасным способом. */
function sendMqttCommand($topic, $payload, $ruleName = '') {
    global $client;

    if ($client && $client->isConnected() && $client->publish($topic, $payload)) {
        echo "✅ Успешно отправлено ($ruleName): $topic = $payload\n";
        return;
    }

    echo "⚠️ Соединение с брокером потеряно, отправляю запасным способом ($ruleName).\n";
    $cmd = "/usr/bin/mosquitto_pub -h 127.0.0.1 -p 1883 -u " . IOT_MQTT_USER . " -P " . IOT_MQTT_PASS
         . " -t " . escapeshellarg($topic) . " -m " . escapeshellarg($payload) . " 2>&1";
    $output = shell_exec($cmd);
    if ($output) {
        echo "⚠️ Ошибка отправки для правила '$ruleName': $output\n";
    } else {
        echo "✅ Успешно отправлено запасным способом ($ruleName): $topic = $payload\n";
    }
}

/** Запись в журнал срабатываний. */
function logAutomationEvent($rule, $skipped = false, $reason = null) {
    global $pdo;

    // Подтверждения ждёт только правило с топиком подтверждения и только когда команда реально ушла:
    // 0 = «ждём ответа устройства» (в панели это красное «не дождались»), NULL = «подтверждение не нужно».
    // Раньше колонке доставалось значение по умолчанию 0, и красным становилось ВСЁ, включая
    // расписания, которые подтверждения не ждут вовсе (исправлено 13.10.2026).
    $confirmed = (!$skipped && !empty($rule['confirmation_topic'])) ? 0 : null;

    try {
        if ($reason !== null) {
            $stmt = $pdo->prepare("INSERT INTO automation_log
                (rule_id, rule_name, action_topic, action_payload, skipped, reason, confirmed)
                VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$rule['id'], $rule['name'], $rule['action_topic'], $rule['action_payload'],
                            $skipped ? 1 : 0, $reason, $confirmed]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO automation_log
                (rule_id, rule_name, action_topic, action_payload, skipped, confirmed)
                VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$rule['id'], $rule['name'], $rule['action_topic'], $rule['action_payload'],
                            $skipped ? 1 : 0, $confirmed]);
        }
        echo "📝 Лог записан: " . $rule['name'] . "\n";
    } catch (Exception $e) {
        error_log("⚠️ Не удалось записать в automation_log: " . $e->getMessage());
    }
}

/** Выполнение действия правила. */
function handleAction($rule) {
    global $scheduled, $pendingConfirmations, $ruleById, $pdo, $lastActionTime;

    try {
        $pdo->prepare("UPDATE automations SET last_triggered = NOW() WHERE id = ?")->execute([$rule['id']]);
        echo "📝 Записано время срабатывания для правила ID " . $rule['id'] . "\n";
    } catch (Exception $e) {
        echo "⚠️ Не удалось обновить last_triggered: " . $e->getMessage() . "\n";
    }

    $delay = (int)$rule['delay_seconds'];
    if ($delay > 0) {
        $runAt = time() + $delay;
        // Пишем в базу, чтобы перезапуск службы не потерял отложенную команду.
        $pid = pend_add_delay($pdo, $rule, $rule['action_topic'], (string)$rule['action_payload'], $runAt);
        $scheduled[] = [
            'pid'        => $pid,
            'execute_at' => $runAt,
            'topic'      => $rule['action_topic'],
            'payload'    => $rule['action_payload'],
            'rule_name'  => $rule['name'],
        ];
        echo "⏱ Запланировано на " . date('H:i', $runAt) . ($pid ? " (сохранено в базе, номер $pid)" : " (только в памяти)") . "\n";
        return;
    }

    if (shouldSkipAction($rule)) {
        echo "⏭️ Пропускаем действие (устройство уже в нужном состоянии): " . $rule['name'] . "\n";
        logAutomationEvent($rule, true, "Устройство уже в нужном состоянии");
        return;
    }

    if (!empty($rule['action_topic']) && !empty($rule['action_payload'])) {
        sendMqttCommand($rule['action_topic'], $rule['action_payload'], $rule['name']);
    } else {
        echo "ℹ️ Нет MQTT действия для правила: " . $rule['name'] . "\n";
    }

    $lastActionTime[$rule['id']] = time();

    // Ожидаем подтверждение от устройства (в топике confirmation_topic)
    if (!empty($rule['confirmation_topic'])) {
        $expectedState = null;
        if (!empty($rule['action_payload'])) {
            $decoded = json_decode($rule['action_payload'], true);
            if (is_array($decoded)) {
                $expectedState = isset($decoded['state']) ? $decoded['state'] : $decoded;
            } else {
                $expectedState = $rule['action_payload'];
            }
        }

        if ($expectedState === null || (is_string($expectedState) && trim($expectedState) === '')) {
            echo "⚠️ Нет данных для подтверждения, выполняем без ожидания\n";
            finishRule($rule);
            return;
        }

        if (!isset($pendingConfirmations[$rule['confirmation_topic']])) {
            $pendingConfirmations[$rule['confirmation_topic']] = [];
        }
        $pendingConfirmations[$rule['confirmation_topic']][$rule['id']] = $expectedState;
        // Сохраняем ожидание в базу: если службу перезапустят, подтверждение не потеряется.
        pend_add_confirm($pdo, $rule, $rule['confirmation_topic'], $expectedState, time() + IOT_CONFIRM_TTL);
        $display = is_array($expectedState) ? json_encode($expectedState) : $expectedState;
        echo "⏳ Ожидаю подтверждения в топике: " . $rule['confirmation_topic'] . " (ожидается: " . $display . ")\n";
        return;
    }

    finishRule($rule);
}

/** Правило выполнено: одноразовое — удаляем, «повторяющееся» — оставляем. */
function finishRule($rule) {
    global $pdo, $ruleById;

    echo "✅ Правило '" . $rule['name'] . "' выполнено (без подтверждения).\n";
    if (empty($rule['persistent'])) {
        $pdo->prepare("DELETE FROM automations WHERE id = ?")->execute([$rule['id']]);
        echo "🗑️ Правило '" . $rule['name'] . "' удалено после выполнения.\n";
        unset($ruleById[$rule['id']]);
    } else {
        echo "🔁 Правило не удалено (галка «Повторять» активна).\n";
    }
}

/**
 * Проверка подтверждений: вызывается и по сообщению устройства (мгновенно),
 * и раз в секунду (на случай, если нужное состояние пришло до того, как мы стали ждать).
 */
function checkPendingConfirmations() {
    global $pendingConfirmations, $ruleById, $sensorData, $pdo, $pendingIds, $confirmDeadline;

    if (empty($pendingConfirmations)) return;

    foreach ($pendingConfirmations as $topic => $ruleList) {
        if (!isset($sensorData[$topic])) continue;

        $actualValue = $sensorData[$topic];
        $displayActual = is_array($actualValue) ? json_encode($actualValue) : $actualValue;

        foreach ($ruleList as $ruleId => $expectedState) {
            $rule = $ruleById[$ruleId] ?? null;
            if (!$rule) continue;

            $displayExpected = is_array($expectedState) ? json_encode($expectedState) : $expectedState;
            $isConfirmed = false;

            if (is_array($expectedState)) {
                if (is_array($actualValue)) {
                    $allMatch = true;
                    foreach ($expectedState as $key => $desiredValue) {
                        if (!isset($actualValue[$key]) || (string)$actualValue[$key] !== (string)$desiredValue) {
                            $allMatch = false;
                            break;
                        }
                    }
                    $isConfirmed = $allMatch;
                } elseif (isset($expectedState['state_l3']) && is_string($actualValue)) {
                    $isConfirmed = ((string)$actualValue === (string)$expectedState['state_l3']);
                }
            } else {
                if (is_array($actualValue)) {
                    if (isset($actualValue['state'])) {
                        $isConfirmed = ((string)$actualValue['state'] === (string)$expectedState);
                    }
                } else {
                    $isConfirmed = ((string)$actualValue === (string)$expectedState);
                }
            }

            if (!$isConfirmed) { continue; }

            echo "✅✅ Подтверждение получено для правила: " . $rule['name'] . "\n";
            try {
                $stmt = $pdo->prepare("SELECT id FROM automation_log
                    WHERE rule_id = ? AND confirmed = 0 AND skipped = 0
                    ORDER BY triggered_at DESC LIMIT 1");
                $stmt->execute([$ruleId]);
                $logEntry = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($logEntry) {
                    $pdo->prepare("UPDATE automation_log SET confirmed = 1, confirmed_at = NOW(),
                                   expected_state = ?, actual_state = ? WHERE id = ?")
                        ->execute([$displayExpected, $displayActual, $logEntry['id']]);
                    echo "📝 Обновлена запись в логе ID: " . $logEntry['id'] . " (Ожидает → Подтверждено)\n";
                } else {
                    $pdo->prepare("INSERT INTO automation_log
                        (rule_id, rule_name, action_topic, action_payload, confirmed, confirmed_at, expected_state, actual_state)
                        VALUES (?, ?, ?, ?, 1, NOW(), ?, ?)")
                        ->execute([$ruleId, $rule['name'], $rule['action_topic'], $rule['action_payload'],
                                   $displayExpected, $displayActual]);
                    echo "📝 Создана новая запись в логе (страховка)\n";
                }
            } catch (Exception $e) {
                error_log("⚠️ Ошибка обновления лога: " . $e->getMessage());
            }

            if (empty($rule['persistent'])) {
                $pdo->prepare("DELETE FROM automations WHERE id = ?")->execute([$ruleId]);
                echo "🗑️ Правило '" . $rule['name'] . "' удалено после подтверждения.\n";
                unset($ruleById[$ruleId]);
            } else {
                echo "🔁 Правило не удалено после подтверждения.\n";
            }
            // Дело закрыто: убираем его из базы и из памяти
            if (!empty($pendingIds['confirm'][$topic][$ruleId])) { pend_done($pdo, $pendingIds['confirm'][$topic][$ruleId]); }
            unset($pendingIds['confirm'][$topic][$ruleId], $confirmDeadline[$topic][$ruleId]);
            unset($pendingConfirmations[$topic][$ruleId]);
        }

        if (empty($pendingConfirmations[$topic])) { unset($pendingConfirmations[$topic]); }
    }
}

/** Правило-триггер: проверяем условие и, если оно только что выполнилось, действуем.
 *  $precomputed — уже посчитанное условие (из такта), чтобы не считать дважды:
 *  у выдержки повторный расчёт начинал бы отсчёт заново и правило не сработало бы. */
function evaluateTriggerRule($rule, $precomputed = null) {
    global $sensorData, $lastTriggerState, $lastActionTime;

    if ($rule['schedule_type'] !== 'none') { return; }

    // Зависимость: правило работает, только если другой датчик в нужном состоянии
    if (!empty($rule['dependency_topic']) && isset($sensorData[$rule['dependency_topic']])) {
        $depValue = $sensorData[$rule['dependency_topic']];
        if (is_array($depValue) && isset($depValue['state'])) { $depValue = $depValue['state']; }
        if ((string)$depValue !== (string)$rule['dependency_value']) { return; }
    }

    if (!isset($sensorData[$rule['trigger_topic']])) { return; }
    $actual = $sensorData[$rule['trigger_topic']];
    if (is_array($actual) && isset($actual['state'])) { $actual = $actual['state']; }

    if ($precomputed !== null) {
        $condMet = (bool)$precomputed;
    } elseif ($rule['condition_type'] === 'script' && !empty($rule['condition_script'])) {
        $condMet = evaluateRuleCondition($rule);
    } elseif ((int)($rule['condition_duration'] ?? 0) > 0) {
        // Выдержка считается по секундам — такое правило перепроверяется ещё и в такте
        $condMet = evaluateRuleCondition($rule);
    } else {
        $condMet = compareSensorValue($rule['trigger_topic'], $rule['condition_operator'], $rule['condition_value']);
    }

    $ruleKey = $rule['id'] . '_' . $rule['trigger_topic'];

    if (!$condMet) {
        if (isset($lastTriggerState[$ruleKey])) { unset($lastTriggerState[$ruleKey]); }
        return;
    }

    $lastTime = $lastActionTime[$rule['id']] ?? 0;
    $cooldown = (int)($rule['cooldown_seconds'] ?? 60);
    if ($cooldown > 0 && (time() - $lastTime) < $cooldown) {
        echo "⏸️ COOLDOWN: " . $rule['name'] . " - пропуск (осталось " . ($cooldown - (time() - $lastTime)) . "с из {$cooldown}с)\n";
        return;
    }

    $previousState = $lastTriggerState[$ruleKey] ?? null;
    if ($previousState === null || $previousState !== $actual) {
        $lastTriggerState[$ruleKey] = $actual;

        if (shouldSkipAction($rule)) {
            echo "⏭️ Устройство уже в нужном состоянии — пропускаем правило: " . $rule['name'] . "\n";
            logAutomationEvent($rule, true, "Устройство уже в нужном состоянии");
        } else {
            echo "🎉 Сработало правило: " . $rule['name'] . "\n";
            logAutomationEvent($rule, false);
            handleAction($rule);
        }
    }
}

/** Сброс ежедневных правил. */
function resetDailyRules($pdo) {
    try {
        $pdo->exec("UPDATE automations SET last_triggered = NULL WHERE schedule_type IN ('daily', 'weekly')");
        echo "🌅 Выполнен ежедневный сброс last_triggered для расписаний.\n";
    } catch (Exception $e) {
        echo "⚠️ Ошибка сброса: " . $e->getMessage() . "\n";
    }
}

/* ==================================================================== такт (раз в секунду) */

/** Расписания, выдержки, подтверждения, отложенные действия — всё, что не привязано к сообщению. */
function tick($pdo) {
    global $rules, $sensorData, $conditionStartTime, $conditionLastLog, $lastScheduleCheck,
           $lastScheduleAttempt, $scheduled, $pendingConfirmations;

    // Расписания
    if (time() - $lastScheduleCheck >= 1) {
        $lastScheduleCheck = time();
        $currentTime = date('H:i:s');
        $currentDay = strtolower(date('D'));

        foreach ($rules as $rule) {
            if ($rule['schedule_type'] === 'none') continue;

            if (!empty($rule['dependency_topic']) && isset($sensorData[$rule['dependency_topic']])) {
                $depValue = $sensorData[$rule['dependency_topic']];
                if (is_array($depValue) && isset($depValue['state'])) { $depValue = $depValue['state']; }
                if ((string)$depValue !== (string)$rule['dependency_value']) { continue; }
            }

            if ($currentTime < $rule['schedule_time']) { continue; }

            $lastTriggered = $rule['last_triggered'];
            $lastDate = $lastTriggered ? date('Y-m-d', strtotime($lastTriggered)) : null;
            if ($lastDate === date('Y-m-d')) { continue; }

            if ($rule['schedule_type'] === 'weekly') {
                $allowedDays = explode(',', (string)$rule['schedule_days']);
                if (!in_array($currentDay, $allowedDays)) { continue; }
            }

            $scheduleKey = 'sched_' . $rule['id'];
            if (isset($lastScheduleAttempt[$scheduleKey]) && time() - $lastScheduleAttempt[$scheduleKey] < 30) { continue; }
            $lastScheduleAttempt[$scheduleKey] = time();

            echo "⏰ Сработало расписание: " . $rule['name'] . "\n";
            if (evaluateRuleCondition($rule)) {
                if (shouldSkipAction($rule)) {
                    // Действие больше не нужно (устройство уже в нужном состоянии) —
                    // фиксируем как выполненное, иначе правило будет проверяться каждую секунду до полуночи
                    echo "⏭️ Устройство уже в нужном состоянии — расписание закрыто на сегодня: " . $rule['name'] . "\n";
                    logAutomationEvent($rule, true, "Устройство уже в нужном состоянии");
                    $pdo->prepare("UPDATE automations SET last_triggered = NOW() WHERE id = ?")->execute([$rule['id']]);
                } else {
                    echo "✅ Условие выполнено — выполняем действие.\n";
                    logAutomationEvent($rule, false);
                    handleAction($rule);
                }
            } else {
                echo "❌ Условие НЕ выполнено — пропускаем правило.\n";
            }
        }
    }

    // Правила, у которых идёт отсчёт выдержки: без новых сообщений условие всё равно нужно досчитать
    if (!empty($conditionStartTime)) {
        foreach (array_keys($conditionStartTime) as $ruleId) {
            $rule = $GLOBALS['ruleById'][$ruleId] ?? null;
            if (!$rule) { unset($conditionStartTime[$ruleId], $conditionLastLog[$ruleId]); continue; }
            if (evaluateRuleCondition($rule)) {
                evaluateTriggerRule($rule, true);   // условие уже посчитано — второй раз не считаем
            }
        }
    }

    // Подтверждения (страховочная проверка — основная идёт по сообщению устройства)
    if (!empty($pendingConfirmations)) { checkPendingConfirmations(); }

    // Отложенные действия
    foreach ($scheduled as $i => $task) {
        if (time() >= $task['execute_at']) {
            echo "⏰ Выполняю отложенное действие: " . $task['rule_name'] . "\n";
            sendMqttCommand($task['topic'], $task['payload'], $task['rule_name']);
            pend_done($pdo, $task['pid'] ?? null);      // дело сделано — убираем из базы
            unset($scheduled[$i]);
        }
    }
    $scheduled = array_values($scheduled);

    // Ожидания подтверждений, у которых вышел срок
    pend_expire($pdo);
}

/* ==================================================================== старт */

seedStateFromDb($pdo);
connectBroker($pdo, true);
pend_load($pdo);            // отложенные команды и ожидания подтверждений, оставшиеся с прошлого раза
echo "✅ Готов! Слушаю брокер, правила беру из базы.\n";

$lastRuleReload = time();

while (true) {
    // 🌅 Ежедневный сброс
    if ((int)date('H') === 0 && (int)date('i') === 0 && (int)date('s') >= 5 && time() - $lastDailyReset > 60) {
        resetDailyRules($pdo);
        $lastDailyReset = time();
    }

    // 🔁 Перечитываем правила раз в 60 секунд
    if (time() - $lastRuleReload >= 60) { reloadRules($pdo); }

    // 📡 Слушаем брокер: до секунды ожидания за такт
    if (!$client->isConnected()) {
        echo "⚠️ Разрыв соединения с брокером, переподключаюсь.\n";
        connectBroker($pdo, false);        // внутри заново подпишется и обновит состояние из базы
        continue;
    }

    foreach ($client->poll(1.0) as $msg) {
        onBrokerMessage($msg['topic'], $msg['payload']);
    }

    $client->keepAlive();

    // 🕔 Расписания, выдержки, подтверждения, отложенные действия
    tick($pdo);
}
