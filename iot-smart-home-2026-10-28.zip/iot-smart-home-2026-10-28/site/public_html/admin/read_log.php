<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
error_reporting(0); // Отключаем вывод ошибок в HTML

$file = isset($_GET['file']) ? $_GET['file'] : '';

// Очищаем путь от возможных XSS
$file = str_replace(['..', '//'], '', $file);

// Проверяем, что файл в /var/log/
if (!preg_match('/^\/var\/log\/[a-zA-Z0-9_\-\.]+\.log$/', $file)) {
    echo json_encode(['success' => false, 'error' => 'Некорректный путь к файлу']);
    exit;
}

if (!file_exists($file)) {
    echo json_encode(['success' => true, 'content' => '']);
    exit;
}

// Проверяем права на чтение
if (!is_readable($file)) {
    echo json_encode(['success' => false, 'error' => 'Нет прав на чтение файла. Выполните: sudo chmod 644 ' . $file]);
    exit;
}

$content = @file_get_contents($file);
if ($content === false) {
    echo json_encode(['success' => false, 'error' => 'Не удалось прочитать файл']);
    exit;
}

// Последние 500 строк
$lines = explode("\n", $content);
$lines = array_slice($lines, -500);
$content = implode("\n", $lines);

echo json_encode(['success' => true, 'content' => $content]);
?>
