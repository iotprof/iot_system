<?php
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Метод не разрешён']);
    exit;
}

$file = $_GET['file'] ?? '';
$file = str_replace(['..', '//'], '', $file);

$allowedFiles = [
    '/var/log/cron_gorshok.log',
    '/var/log/cron_soil.log',
    '/var/log/cron_heater.log',
    '/var/log/cron_feeder.log',
    '/var/log/cron_motion.log',
    '/var/log/cron_polivayka.log',
    '/var/log/fish-light.log',
    '/var/log/fish-filter.log',
    '/var/log/cron_automation_emails.log'
];

if (!in_array($file, $allowedFiles)) {
    echo json_encode(['success' => false, 'error' => 'Доступ запрещён']);
    exit;
}

if (!file_exists($file)) {
    echo json_encode(['success' => false, 'error' => 'Файл не найден']);
    exit;
}

// Очищаем файл
file_put_contents($file, '');
echo json_encode(['success' => true]);
?>
