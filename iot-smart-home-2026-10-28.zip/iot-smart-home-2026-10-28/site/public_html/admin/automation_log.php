<?php
require_once '/var/www/html/iot/config/iot_config.php';

session_start();
if (!isset($_SESSION['iot_admin'])) {
    header('Location: /admin/sensors.php');
    exit;
}

$pdo = iot_pdo();

// ============================================
// 🗑️ ОБРАБОТКА ОЧИСТКИ ЛОГОВ
// ============================================
if (isset($_POST['clear_logs'])) {
    $days = isset($_POST['clear_days']) ? (int)$_POST['clear_days'] : 7;
    
    if ($days === 0) {
        // Очистить все логи
        // ИСПРАВЛЕНО 29.09.2026: TRUNCATE требует привилегии DROP, которая учётке сайта не нужна.
        // Результат для пользователя тот же — журнал очищен, но доступ урезан по минимуму.
        $stmt = $pdo->prepare("DELETE FROM automation_log");
        $stmt->execute();
        $message = "✅ Все логи удалены!";
    } else {
        // Очистить логи старше N дней
        $stmt = $pdo->prepare("DELETE FROM automation_log WHERE triggered_at < DATE_SUB(NOW(), INTERVAL ? DAY)");
        $stmt->execute([$days]);
        $count = $stmt->rowCount();
        $message = "✅ Удалено $count записей, старше $days дней";
    }
    
    // Редирект чтобы избежать повторной отправки формы
    header("Location: " . $_SERVER['REQUEST_URI'] . "&cleared=1");
    exit;
}

// ============================================
// 📋 ФИЛЬТРЫ
// ============================================
$filter = '';
$filterLabel = 'Подтвержденные';
$filterType = 'confirmed';

if (isset($_GET['filter'])) {
    $filterType = $_GET['filter'];
}

switch ($filterType) {
    case 'all':
        $filter = "";
        $filterLabel = 'Все записи';
        break;
    case 'unconfirmed':
        // Только те, кто ДЕЙСТВИТЕЛЬНО ждал подтверждения: NULL значит «подтверждение не требуется»
        $filter = "WHERE confirmed = 0 AND skipped = 0";
        $filterLabel = 'Не дождались подтверждения ❌';
        break;
    case 'confirmed':
        $filter = "WHERE confirmed = 1";
        $filterLabel = 'Подтвержденные ✅';
        break;
    case 'skipped':
        $filter = "WHERE skipped = 1";
        $filterLabel = 'Пропущенные ⏭️';
        break;
    default:
        $filter = "WHERE confirmed = 1";
        $filterLabel = 'Подтвержденные ✅';
        $filterType = 'confirmed';
}

$stmt = $pdo->query("
    SELECT * FROM automation_log 
    $filter
    ORDER BY triggered_at DESC 
    LIMIT 200
");
$logs = $stmt->fetchAll();

// Статистика
$countAll = $pdo->query("SELECT COUNT(*) FROM automation_log")->fetchColumn();
$countConfirmed = $pdo->query("SELECT COUNT(*) FROM automation_log WHERE confirmed = 1")->fetchColumn();
$countUnconfirmed = $pdo->query("SELECT COUNT(*) FROM automation_log WHERE confirmed = 0 AND skipped = 0")->fetchColumn();
$countSkipped = $pdo->query("SELECT COUNT(*) FROM automation_log WHERE skipped = 1")->fetchColumn();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <meta name="theme-color" content="#0a0e12">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <link rel="manifest" href="/manifest.json">
    <title>📋 Журнал автоматизаций</title>
    <link rel="stylesheet" href="/css/style.css">
    <style>
        .filter-bar {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            align-items: center;
            padding: 12px 16px;
            background: var(--bg-card);
            border-radius: 12px;
            margin-bottom: 20px;
        }
        .filter-bar .label {
            color: var(--text-muted);
            font-size: 0.9em;
            margin-right: 10px;
        }
        .filter-btn {
            padding: 6px 14px;
            border-radius: 20px;
            background: var(--bg-input);
            color: var(--text-muted);
            text-decoration: none;
            font-size: 0.85em;
            transition: all 0.2s;
            border: 1px solid transparent;
        }
        .filter-btn:hover {
            background: var(--bg-hover);
            color: var(--text-primary);
        }
        .filter-btn.active {
            background: var(--accent);
            color: #fff;
            border-color: var(--accent);
        }
        .filter-btn .badge {
            display: inline-block;
            background: rgba(255,255,255,0.2);
            border-radius: 10px;
            padding: 0 8px;
            font-size: 0.7em;
            margin-left: 4px;
        }
        
        .stats-bar {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-bottom: 20px;
            padding: 10px 16px;
            background: var(--bg-card);
            border-radius: 12px;
            font-size: 0.85em;
        }
        .stats-bar .stat-item {
            display: flex;
            align-items: center;
            gap: 6px;
            color: var(--text-muted);
        }
        .stats-bar .stat-item .num {
            font-weight: bold;
            color: var(--text-primary);
        }
        .stats-bar .stat-item .num.green { color: #4caf50; }
        .stats-bar .stat-item .num.yellow { color: #ffa726; }
        .stats-bar .stat-item .num.gray { color: var(--text-muted); }
        
        .badge-warning { background: #ffa726; color: #1a1a2e; }
        .badge-confirmed { background: #4caf50; color: #fff; }
        .badge-skipped { background: #78909c; color: #fff; }
        .badge-timeout { background: #ef5350; color: #fff; }
        .badge-done { background: #26a69a; color: #fff; }
        
        .btn-clear {
            background: #ef5350;
            color: #fff;
            border: none;
            padding: 6px 16px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.85em;
            margin-left: auto;
            transition: opacity 0.2s;
        }
        .btn-clear:hover { opacity: 0.8; }
        
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.7);
            z-index: 9999;
            justify-content: center;
            align-items: center;
        }
        .modal-overlay.show { display: flex; }
        .modal-content {
            background: var(--bg-card);
            padding: 30px;
            border-radius: 16px;
            max-width: 500px;
            width: 90%;
        }
        .modal-content h2 { margin-top: 0; }
        .modal-content label {
            display: block;
            padding: 10px;
            background: var(--bg-input);
            border-radius: 8px;
            margin-bottom: 8px;
            cursor: pointer;
        }
        .modal-content label:hover { background: var(--bg-hover); }
        .modal-content label.danger { border: 2px solid #ef5350; }
        .modal-content .btn-group {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 20px;
        }
        .modal-content .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.95em;
        }
        .btn-cancel { background: var(--bg-input); color: var(--text-primary); }
        .btn-danger { background: #ef5350; color: #fff; }
        .message.success {
            padding: 12px 16px;
            background: rgba(76, 175, 80, 0.2);
            border: 1px solid #4caf50;
            color: #4caf50;
            border-radius: 8px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
<div class="container">
<?php include '/var/www/html/iot/public_html/include/links_panel.php';?>

<?php if (isset($_GET['cleared'])): ?>
    <div class="message success">✅ Логи успешно очищены!</div>
<?php endif; ?>

<!-- ===== СТАТИСТИКА ===== -->
<div class="stats-bar">
    <span class="stat-item">📊 Всего: <span class="num"><?= $countAll ?></span></span>
    <span class="stat-item">✅ Подтверждено: <span class="num green"><?= $countConfirmed ?></span></span>
    <span class="stat-item">⏳ Ожидают: <span class="num yellow"><?= $countUnconfirmed ?></span></span>
    <span class="stat-item">⏭️ Пропущено: <span class="num gray"><?= $countSkipped ?></span></span>
</div>

<!-- ===== ФИЛЬТРЫ ===== -->
<div class="filter-bar">
    <span class="label">📋 Фильтр:</span>
    
    <a href="?filter=confirmed" class="filter-btn <?= $filterType === 'confirmed' ? 'active' : '' ?>">
        ✅ Подтвержденные <span class="badge"><?= $countConfirmed ?></span>
    </a>
    
    <a href="?filter=unconfirmed" class="filter-btn <?= $filterType === 'unconfirmed' ? 'active' : '' ?>">
        ⏳ Ожидают <span class="badge"><?= $countUnconfirmed ?></span>
    </a>
    
    <a href="?filter=skipped" class="filter-btn <?= $filterType === 'skipped' ? 'active' : '' ?>">
        ⏭️ Пропущенные <span class="badge"><?= $countSkipped ?></span>
    </a>
    
    <a href="?filter=all" class="filter-btn <?= $filterType === 'all' ? 'active' : '' ?>">
        📊 Все <span class="badge"><?= $countAll ?></span>
    </a>
    
    <!-- 🗑️ КНОПКА ОЧИСТКИ -->
    <button class="btn-clear" onclick="document.getElementById('clearModal').classList.add('show')">
        🗑️ Очистить логи
    </button>
</div>

<h1>📋 Журнал автоматизаций 
    <span style="font-size: 0.7em; color: var(--text-muted);">(<?= htmlspecialchars($filterLabel) ?>)</span>
</h1>

<!-- ===== МОДАЛЬНОЕ ОКНО ===== -->
<div id="clearModal" class="modal-overlay" onclick="if(event.target===this)this.classList.remove('show')">
    <div class="modal-content">
        <h2>🗑️ Очистка логов</h2>
        <p style="color: var(--text-muted);">Выберите, какие логи удалить:</p>
        
        <form method="post" onsubmit="return confirm('⚠️ Вы уверены? Это действие нельзя отменить!');">
            <label>
                <input type="radio" name="clear_days" value="7" checked> 
                📅 Старше 7 дней
            </label>
            
            <label>
                <input type="radio" name="clear_days" value="30"> 
                📅 Старше 30 дней
            </label>
            
            <label>
                <input type="radio" name="clear_days" value="90"> 
                📅 Старше 90 дней
            </label>
            
            <label class="danger">
                <input type="radio" name="clear_days" value="0"> 
                ⚠️ <strong style="color: #ef5350;">Удалить ВСЕ логи (безвозвратно)</strong>
            </label>
            
            <div class="btn-group">
                <button type="button" class="btn btn-cancel" onclick="document.getElementById('clearModal').classList.remove('show')">
                    Отмена
                </button>
                <button type="submit" name="clear_logs" class="btn btn-danger">
                    🗑️ Удалить
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ===== СПИСОК ЛОГОВ ===== -->
<div class="sensors-grid">
    <?php if (empty($logs)): ?>
        <div class="empty-state">
            🕯️ Нет записей в журнале<br>
            <small>Правила будут отображаться здесь после их срабатывания</small>
        </div>
    <?php else: ?>
        <?php foreach ($logs as $log): 
            // NULL = правило подтверждения не ждёт (расписание или команда без топика подтверждения):
            // это НЕ таймаут. «0» = ждали ответа устройства и не дождались — красным только это.
            $conf = $log['confirmed'];
            if ($log['skipped']) {
                $statusClass = 'badge-skipped';
                $statusText = '⏭️ Пропущено';
            } elseif ($conf === null) {
                $statusClass = 'badge-done';
                $statusText = '✅ Выполнено (подтверждение не требуется)';
            } elseif ((int)$conf === 1) {
                $statusClass = 'badge-confirmed';
                $statusText = '✅ Подтверждено';
            } elseif ((int)$conf === 0) {
                $statusClass = 'badge-timeout';
                $statusText = '❌ Не дождались подтверждения';
            } else {
                $statusClass = 'badge-warning';
                $statusText = '⏳ Ожидает';
            }
        ?>
            <div class="sensor-card">
                <div class="card-header">
                    <span class="sensor-icon">📋</span>
                    <span class="sensor-topic"><?= htmlspecialchars($log['rule_name']) ?></span>
                    <span class="history-badge <?= $statusClass ?>"><?= $statusText ?></span>
                </div>
                
                <div class="card-body">
                    <div class="sensor-property">
                        <span class="property-label">🕐 Время</span>
                        <span class="property-value"><?= htmlspecialchars($log['triggered_at']) ?></span>
                    </div>
                    
                    <div class="sensor-property">
                        <span class="property-label">🎯 Топик</span>
                        <span class="property-value"><code><?= htmlspecialchars($log['action_topic']) ?></code></span>
                    </div>
                    
                    <div class="sensor-property">
                        <span class="property-label">📦 Payload</span>
                        <span class="property-value"><code><?= htmlspecialchars($log['action_payload']) ?></code></span>
                    </div>
                    
                    <?php if ($log['skipped'] && $log['reason']): ?>
                        <div class="sensor-property">
                            <span class="property-label">💬 Причина</span>
                            <span class="property-value" style="color: var(--error);"><?= htmlspecialchars($log['reason']) ?></span>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!$log['skipped'] && $log['confirmed'] == 1): ?>
                        <div class="sensor-property">
                            <span class="property-label">✅ Подтверждено</span>
                            <span class="property-value">
                                <?= date('H:i:s', strtotime($log['confirmed_at'])) ?>
                                <?php if ($log['expected_state']): ?>
                                    <br><small>Ожидалось: <code><?= htmlspecialchars($log['expected_state']) ?></code></small>
                                <?php endif; ?>
                                <?php if ($log['actual_state']): ?>
                                    <br><small>Получено: <code><?= htmlspecialchars($log['actual_state']) ?></code></small>
                                <?php endif; ?>
                            </span>
                        </div>
                    <?php elseif (!$log['skipped'] && $log['confirmed'] !== null && (int)$log['confirmed'] === 0): ?>
                        <div class="sensor-property">
                            <span class="property-label">❌ Таймаут</span>
                            <span class="property-value" style="color: var(--error);">
                                Не дождались подтверждения
                                <?php if ($log['expected_state']): ?>
                                    <br><small>Ожидалось: <code><?= htmlspecialchars($log['expected_state']) ?></code></small>
                                <?php endif; ?>
                            </span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- ===== ВЫХОД ===== -->
<div style="margin-top: 30px; text-align: center;">
    <form method="post" action="/admin/logout.php" style="display: inline-block;">
        <button type="submit">🚪 Выйти</button>
    </form>
</div>

</div>

<script>
// Закрытие по Escape
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.getElementById('clearModal')?.classList.remove('show');
    }
});
</script>

</body>
</html>
