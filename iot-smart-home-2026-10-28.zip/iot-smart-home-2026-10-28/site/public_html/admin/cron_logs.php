<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <meta name="theme-color" content="#0a0e12">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>IoT Система — Логи Cron</title>
    <link rel="stylesheet" href="/css/style.css">
<!-- PWA Support -->
<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#0a0e12">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="IoT Home">
</head>
<body>
<div class="container">
<?php include  '/var/www/html/iot/public_html/include/links_panel.php';?>

    <h1>🌱 IoT Система — Логи Cron</h1>
    <div class="subtitle">📋 Автоматический полив, аквариум, датчики движения</div>
    
<div class="sensors-grid" id="logsGrid"></div>

    
<div class="status-bar" id="statusBar" style="position: fixed; bottom: 10px; right: 10px; background: var(--bg-panel); padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.7rem; border: 1px solid var(--border); z-index: 100;">
    🟢 Автообновление: 300 сек
</div>


</div>

<script>
    // Список лог-файлов
    const logFiles = [
        { name: "🌲 Можжевельник (влажность)", file: "/var/log/cron_soil.log" },
        { name: "🔥 Нагреватель аквариума", file: "/var/log/cron_heater.log" },
        { name: "🍕 Кормушка (9:00, 12:00, 18:00)", file: "/var/log/cron_feeder.log" },
        { name: "🚶 Движение (email каждый час)", file: "/var/log/cron_motion.log" },
	{ name: "🚶 Поливайка (email каждый час)", file: "/var/log/cron_polivayka.log" },
        { name: "💡 Свет аквариума (8:00/20:00)", file: "/var/log/fish-light.log" },
        { name: "🧹 Фильтр аквариума (7:00/23:00)", file: "/var/log/fish-filter.log" },
        { name: "📧 рассылка емаил по триггерам", file: "/var/log/cron_automation_emails.log" },
{ name: "🔋 Батарейки Zigbee", file: "/var/log/battery_check.log" }
    ];

    async function loadLog(filePath) {
        try {
            const response = await fetch(`read_log.php?file=${encodeURIComponent(filePath)}&t=${Date.now()}`);
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const text = await response.text();
            try {
                const data = JSON.parse(text);
                return data.success ? data.content : `❌ Ошибка: ${data.error}`;
            } catch (e) {
                return text;
            }
        } catch (error) {
            return `❌ Не удалось загрузить лог: ${error.message}`;
        }
    }

    function formatLogContent(content) {
        if (!content || content.trim() === '') {
            return '<div class="empty-state" style="padding: 2rem; text-align: center;">📭 Лог пуст</div>';
        }
        if (content.startsWith('❌')) {
            return `<div class="empty-state" style="color: var(--error);">${escapeHtml(content)}</div>`;
        }
        const lines = content.split('\n');
        let html = '<div class="log-content">';
        for (let line of lines) {
            if (line.trim() !== '') {
                let lineClass = '';
                if (line.includes('ERROR') || line.includes('error') || line.includes('Error')) {
                    lineClass = 'error';
                } else if (line.includes('WARNING') || line.includes('warning')) {
                    lineClass = 'warning';
                }
                html += `<div class="log-line ${lineClass}">${escapeHtml(line)}</div>`;
            }
        }
        html += '</div>';
        return html;
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

async function renderLogs() {
    const grid = document.getElementById('logsGrid');
    if (!grid) return;
    
    // Очищаем сетку и убираем сообщение о загрузке
    grid.innerHTML = '';
        
        for (const log of logFiles) {
            const content = await loadLog(log.file);
            const card = document.createElement('div');
            card.className = 'sensor-card';
            card.innerHTML = `
                <div class="card-header">
                    <span class="sensor-icon">📋</span>
                    <span class="sensor-topic">${escapeHtml(log.name)}</span>
                    <span class="history-badge history-yes" style="cursor: pointer;" onclick="refreshLog(this, '${escapeHtml(log.file)}')">🔄 Обновить</span>
                </div>
                <div class="card-body" style="padding: 0;">
                    ${formatLogContent(content)}
                </div>
                <div class="card-footer">
                    <button class="btn btn-sm" onclick="refreshLog(this, '${escapeHtml(log.file)}')">🔄 Обновить</button>
                    <button class="btn btn-sm btn-danger" onclick="clearLog('${escapeHtml(log.file)}', this)">🗑️ Очистить</button>
                </div>
            `;
            grid.appendChild(card);
        }
    }

    async function refreshLog(btn, file) {
        const card = btn.closest('.sensor-card');
        const body = card.querySelector('.card-body');
        body.innerHTML = '<div class="loading" style="padding: 2rem; text-align: center;">⏳ Обновление...</div>';
        
        const content = await loadLog(file);
        body.innerHTML = formatLogContent(content);
        
        const statusBar = document.getElementById('statusBar');
        if (statusBar) {
            statusBar.innerHTML = '✅ Обновлено: ' + new Date().toLocaleTimeString();
            setTimeout(() => {
                statusBar.innerHTML = '🟢 Автообновление: 300 сек';
            }, 3000);
        }
    }

    async function clearLog(file, btn) {
        if (!confirm('Очистить этот лог?')) return;
        try {
            const response = await fetch(`clear_log.php?file=${encodeURIComponent(file)}`, { method: 'POST' });
            const text = await response.text();
            let result;
            try {
                result = JSON.parse(text);
            } catch (e) {
                result = { success: false, error: 'Ошибка' };
            }
            if (result.success) {
                const card = btn.closest('.sensor-card');
                const body = card.querySelector('.card-body');
                body.innerHTML = '<div class="empty-state" style="padding: 2rem; text-align: center;">✅ Лог очищен</div>';
            } else {
                alert('Ошибка очистки: ' + (result.error || 'Неизвестная ошибка'));
            }
        } catch (error) {
            alert('Ошибка: ' + error.message);
        }
    }

    // Автообновление каждые 5 минут
    let autoRefreshInterval;
    function startAutoRefresh() {
        if (autoRefreshInterval) clearInterval(autoRefreshInterval);
        autoRefreshInterval = setInterval(() => {
            renderLogs();
        }, 300000);
    }

    // Запуск
    renderLogs();
    startAutoRefresh();
</script>

</body>
</html>
