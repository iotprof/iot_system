<?php
require_once '/var/www/html/iot/config/iot_config.php';

session_start();

// Защита по IP — раскомментируй, если нужна
// $allowed_ips = ['192.168.0.1', '127.0.0.1'];
// if (!in_array($_SERVER['REMOTE_ADDR'], $allowed_ips)) {
//     header('HTTP/1.1 403 Forbidden');
//     die("Доступ запрещён");
// }

// Авторизация
$valid_username = IOT_PANEL_USER;
$valid_password_hash = IOT_PANEL_HASH;

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['username'])) {
        // Вход
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        if ($username === $valid_username && password_verify($password, $valid_password_hash)) {
            $_SESSION['iot_admin'] = true;
        } else {
            $error = "Неверный логин или пароль";
        }
    } elseif (isset($_POST['save'])) {
        // Сохранение датчика
        $topic = trim($_POST['topic'] ?? '');
        $name = $_POST['name'] ?? '';
        $room = $_POST['room'] ?? '';
        $group = $_POST['group_name'] ?? '';
        $icon = $_POST['icon'] ?? '';
        $save_history = !empty($_POST['save_history']) ? 1 : 0;

        if (!empty($topic)) {
            try {
                $pdo = iot_pdo();
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $stmt = $pdo->prepare("
                    INSERT INTO sensor_info (topic, name, room, group_name, icon, save_history)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                        name = VALUES(name),
                        room = VALUES(room),
                        group_name = VALUES(group_name),
                        icon = VALUES(icon),
                        save_history = VALUES(save_history)
                ");
                $stmt->execute([$topic, $name, $room, $group, $icon, $save_history]);
            } catch (Exception $e) {
                die("Ошибка сохранения: " . $e->getMessage());
            }
        }
    }
}

if (!isset($_SESSION['iot_admin'])) {
    ?>
<!DOCTYPE html>
<html lang="ru">
 <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="UTF-8">
        <title>🔐 Вход</title>
<link rel="stylesheet" href="/css/style.css">
    </head>
    <body>
<div class="container">

        <div class="login-box">
            <h2>🔐 Авторизация</h2>
            <?php if ($error): ?><div class="error"><?= $error ?></div><?php endif; ?>
            <form method="post">
                <label>Логин</label>
                <input type="text" name="username" required>
                <label>Пароль</label>
                <input type="password" name="password" required>
                <button type="submit">Войти</button>
            </form>
        </div>
</div>
    </body>
    </html>
    <?php
    exit;
}
?>

<?php
// Подключение к БД
try {
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Получаем список всех топиков из sensor_data
    $stmt = $pdo->query("SELECT DISTINCT topic FROM sensor_data ORDER BY topic");
    $topics = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);

    // Получаем текущие данные из sensor_info
    $stmt = $pdo->query("SELECT * FROM sensor_info");
    $info = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $infoMap = [];
    foreach ($info as $row) {
        $infoMap[$row['topic']] = $row;
    }

} catch (PDOException $e) {
    die("Ошибка подключения: " . $e->getMessage());
}

// Удаление
if (isset($_GET['delete'])) {
    $topic_to_delete = $_GET['delete'];

    $pdo->prepare("DELETE FROM sensor_info WHERE topic = ?")->execute([$topic_to_delete]);
    $pdo->prepare("DELETE FROM sensor_data WHERE topic = ?")->execute([$topic_to_delete]);
    $pdo->prepare("DELETE FROM sensor_history WHERE topic = ?")->execute([$topic_to_delete]);

    header("Location: sensors.php");
    exit;
}

// ===== ГРУППИРОВКА ПО ГРУППАМ (28.10.2026) =====
// Группа берётся из поля «Группа» (sensor_info.group_name).
// Если оно пустое: служебные battery/voltage идут в «Питание», остальные — по комнате.
// Нет ни группы, ни комнаты — «Без группы» (эта секция всегда внизу).
// Технические топики: полный JSON устройства, команды /set и служебные поля
// (linkquality, калибровки, режимы). Они не «датчики», поэтому лежат в отдельной
// секции «Служебные», скрытой по умолчанию.
function iot_is_service($topic) {
    if (substr_count($topic, '/') < 2) return true;             // zigbee2mqtt/<устройство> — весь JSON
    if (strpos($topic, '/set') !== false) return true;           // исходящие команды
    $last = substr($topic, strrpos($topic, '/') + 1);
    static $svc = [
        'linkquality', 'indicator_mode', 'power_on_behavior',
        'power_outage_memory', 'power_outage_memory_l1', 'countdown', 'energy',
        'current', 'child_lock', 'sensitivity', 'temperature_sensitivity',
        'humidity_sensitivity', 'temperature_calibration', 'humidity_calibration',
        'soil_calibration', 'soil_sampling', 'temperature_sampling', 'temperature_unit',
        'manual_mode', 'fading_time', 'illuminance_interval',
        'motion_detection_sensitivity', 'max_moisture', 'dry', 'soil_warning',
        'auto_close_when_water_shortage', 'current_device_status',
        'device_temperature', 'update', 'update_available',
    ];
    return in_array($last, $svc, true);
}

// Группа датчика: поле «Группа» → иначе группа любого другого поля того же
// устройства (поставил группу батарейке — вся устройство переехало) → иначе комната.
function iot_group_of($topic, $entry, $devGroup = []) {
    if (iot_is_service($topic)) return 'Служебные';
    $g = trim((string)($entry['group_name'] ?? ''));
    if ($g !== '') return $g;
    $parts = explode('/', $topic);
    if (count($parts) >= 2) {
        $dev = $parts[0] . '/' . $parts[1];
        if (!empty($devGroup[$dev])) return $devGroup[$dev];
    }
    if (strpos($parts[0] . '/' . $parts[1], 'zigbee2mqtt/0x') === 0) return 'Розетки'; // розетки/реле без справочника
    $room = trim((string)($entry['room'] ?? ''));
    if ($room !== '') return mb_convert_case($room, MB_CASE_TITLE, 'UTF-8');
    return 'Без группы';
}

function iot_ago($ts) {
    if (empty($ts)) return 'нет данных';
    $d = time() - strtotime($ts);
    if ($d < 0) $d = 0;
    if ($d < 60) return 'только что';
    if ($d < 3600) return intdiv($d, 60) . ' мин назад';
    if ($d < 86400) return intdiv($d, 3600) . ' ч назад';
    return intdiv($d, 86400) . ' дн назад';
}

// последнее значение и время по каждому топику
$lastMap = [];
try {
    foreach ($pdo->query("SELECT topic, value, timestamp FROM sensor_data") as $r) {
        $lastMap[$r['topic']] = $r;
    }
} catch (Exception $e) {}

// карта «устройство → группа» из уже заполненных строк sensor_info
$devGroup = [];
foreach ($infoMap as $t => $row) {
    $g = trim((string)($row['group_name'] ?? ''));
    if ($g === '') continue;
    $parts = explode('/', $t);
    if (count($parts) >= 2) $devGroup[$parts[0] . '/' . $parts[1]] = $g;
}

// устройства, у которых НЕТ ни одной строки в sensor_info: группу задаём здесь,
// иначе их топики падали бы в «Без группы»
$devFallback = [
    'zigbee2mqtt/fish_power' => 'Аквариум',
];
foreach ($devFallback as $d => $g) {
    if (empty($devGroup[$d])) $devGroup[$d] = $g;
}

$groups = [];
foreach ($topics as $topic) {
    $groups[iot_group_of($topic, $infoMap[$topic] ?? [], $devGroup)][] = $topic;
}
// порядок: обычные группы по алфавиту, потом «Служебные», в самом низу «Без группы»
$rank = ['Служебные' => 998, 'Без группы' => 999];
uksort($groups, function ($a, $b) use ($rank) {
    $ra = isset($rank[$a]) ? $rank[$a] : 0;
    $rb = isset($rank[$b]) ? $rank[$b] : 0;
    if ($ra !== $rb) return $ra - $rb;
    return strcasecmp($a, $b);
});
$serviceCount = isset($groups['Служебные']) ? count($groups['Служебные']) : 0;
$sensorCount = count($topics) - $serviceCount;

// карточка одного датчика
function iot_sensor_card($topic, $entry, $last) {
    $name = $entry['name'] ?? '';
    $room = $entry['room'] ?? '';
    $group = $entry['group_name'] ?? '';
    $icon = $entry['icon'] ?? '📟';
    $save_history = (($entry['save_history'] ?? 0) == 1);
    $value = $last['value'] ?? '';
    $ts = $last['timestamp'] ?? '';
    ?>
<div class="sensor-card">
    <div class="card-header">
        <span class="sensor-icon"><?= htmlspecialchars($icon) ?></span>
        <span class="sensor-topic" title="<?= htmlspecialchars($topic) ?>">
            <?= htmlspecialchars(strlen($topic) > 40 ? substr($topic, 0, 37) . '...' : $topic) ?>
        </span>
        <span class="history-badge <?= $save_history ? 'history-yes' : 'history-no' ?>">
            <?= $save_history ? '📊 История' : '⏺️ Без истории' ?>
        </span>
    </div>

    <div class="card-body">
        <div class="sensor-property">
            <span class="property-label">🏷️ Имя</span>
            <span class="property-value <?= empty($name) ? 'empty' : '' ?>">
                <?= empty($name) ? '— не задано —' : htmlspecialchars($name) ?>
            </span>
        </div>
        <div class="sensor-property">
            <span class="property-label">🚪 Комната</span>
            <span class="property-value <?= empty($room) ? 'empty' : '' ?>">
                <?= empty($room) ? '— не указана —' : htmlspecialchars($room) ?>
            </span>
        </div>
        <div class="sensor-property">
            <span class="property-label">📁 Группа</span>
            <span class="property-value <?= empty($group) ? 'empty' : '' ?>">
                <?= empty($group) ? '— не указана —' : htmlspecialchars($group) ?>
            </span>
        </div>
        <div class="sensor-property">
            <span class="property-label">📈 Значение</span>
            <span class="property-value <?= ($value === '' || $value === null) ? 'empty' : '' ?>">
                <?= ($value === '' || $value === null) ? '—' : htmlspecialchars($value) ?>
                <br><small><?= htmlspecialchars(iot_ago($ts)) ?></small>
            </span>
        </div>
    </div>

    <div class="card-actions">
<a href="#" onclick="editSensor(<?= htmlspecialchars(json_encode([
    'topic' => $topic,
    'name' => $name,
    'room' => $room,
    'group' => $group,
    'icon' => $icon,
    'save_history' => $save_history
]), ENT_QUOTES, 'UTF-8') ?>)">✏️ Редактировать</a>
        <a href="?delete=<?= urlencode($topic) ?>" onclick="return confirm('Удалить?')">🗑️ Удалить</a>
    </div>
</div>
<?php
}
?>

<!DOCTYPE html>
<html lang="ru">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>
    <meta charset="UTF-8">
    <title>🛠️ Админка IoT</title>
    <link rel="stylesheet" href="/css/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="container">
<?php include  '/var/www/html/iot/public_html/include/links_panel.php';?>

    <h1>🛠️ Админка: Редактирование датчиков</h1>

    <!-- Форма добавления/редактирования -->
    <div class="form-box">
        <h2>📝 Редактировать датчик</h2>
        <form method="post">
            <div class="form-row">
                <label>🔗 Топик (MQTT):</label>
                <input type="text" name="topic" required list="topics" placeholder="sensors/temperature/outside">
                <small>Уникальный идентификатор датчика в системе</small>
            </div>

            <div class="form-row">
                <label>🏷️ Имя датчика:</label>
                <input type="text" name="name" placeholder="Например: Уличная температура">
            </div>

            <div class="form-row">
                <label>🚪 Комната:</label>
                <input type="text" name="room" placeholder="Например: Гостиная, Кухня, Улица">
            </div>

            <div class="form-row">
                <label>📁 Группа:</label>
                <input type="text" name="group_name" list="groups" placeholder="Например: Аквариум, Спальня, Питание">
                <small>Датчики с одинаковой группой стоят на странице вместе. Пусто = по комнате, служебные battery/voltage = «Питание»</small>
            </div>

            <div class="form-row">
                <label>🎨 Иконка (эмодзи или текст):</label>
                <input type="text" name="icon" placeholder="🌡️, 🚪, 💡, 🌿">
                <small>Будет отображаться рядом с названием</small>
            </div>

            <div class="form-row">
                <label>
                    <input type="checkbox" name="save_history" value="1">
                    📊 Сохранять историю (для графиков)
                </label>
                <small>Если включено, будут сохраняться все значения для построения графиков</small>
            </div>

            <div class="form-row">
                <input type="submit" name="save" value="💾 Сохранить датчик">
            </div>
        </form>

        <datalist id="groups">
            <?php foreach (array_keys($groups) as $gname): ?>
                <option value="<?= htmlspecialchars($gname) ?>">
            <?php endforeach; ?>
        </datalist>

        <datalist id="topics">
            <?php foreach ($topics as $t): ?>
                <option value="<?= htmlspecialchars($t) ?>">
            <?php endforeach; ?>
        </datalist>
    </div>

    <h2>📊 Все датчики <span style="font-size:0.6em; opacity:.6;"><?= $sensorCount ?> датчиков в <?= count($groups) - ($serviceCount ? 1 : 0) ?> группах<?= $serviceCount ? ' + ' . $serviceCount . ' служебных' : '' ?></span></h2>

    <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center; margin-bottom:14px;">
        <input type="text" id="groupFilter" placeholder="🔍 Поиск по имени, комнате или топику"
               oninput="filterSensors(this.value)" style="flex:1 1 260px; min-width:200px;">
        <button type="button" onclick="toggleAllGroups(true)">📂 Раскрыть все</button>
        <button type="button" onclick="toggleAllGroups(false)">📁 Свернуть все</button>
        <label style="display:flex; gap:6px; align-items:center; opacity:.85; font-size:0.9em;">
            <input type="checkbox" id="showService" onchange="toggleService(this.checked)">
            показывать служебные (<?= $serviceCount ?>)
        </label>
    </div>

    <?php if (empty($topics)): ?>
        <div class="empty-state">
            🕯️ Нет датчиков в системе.<br>
            Добавьте первый, отправив данные через MQTT или заполните форму выше.
        </div>
    <?php else: ?>
        <?php foreach ($groups as $gname => $gtopics): ?>
        <?php
            $isServiceGroup = ($gname === 'Служебные');
            $isDefaultClosed = $isServiceGroup || ($gname === 'Без группы');
        ?>
        <details class="sensor-group" data-group="<?= htmlspecialchars($gname, ENT_QUOTES) ?>"
                 data-service="<?= $isServiceGroup ? '1' : '0' ?>"
                 <?= $isDefaultClosed ? '' : 'open' ?>
                 style="margin-bottom:14px; background: var(--bg-card); border-radius:16px; border-left:4px solid var(--accent);<?= $isServiceGroup ? ' display:none;' : '' ?>">
            <summary style="cursor:pointer; padding:14px 18px; font-weight:600;">
                📁 <?= htmlspecialchars($gname) ?>
                <span style="font-size:0.8em; opacity:.65; background: var(--bg-input); border-radius:10px; padding:2px 10px; margin-left:6px;"><?= count($gtopics) ?></span>
                <span style="float:right; font-size:0.75em; opacity:.5;">скрыть / показать</span>
            </summary>
            <div class="sensors-grid" style="padding:0 14px 14px;">
                <?php foreach ($gtopics as $topic) iot_sensor_card($topic, $infoMap[$topic] ?? [], $lastMap[$topic] ?? null); ?>
            </div>
        </details>
        <?php endforeach; ?>
    <?php endif; ?>

    <form method="post" action="/admin/logout.php" style="margin-top: 30px;">
        <button type="submit">🚪 Выйти</button>
    </form>
</div>
    <script>
    // ===== Группы датчиков: помним, что свёрнуто (28.10.2026) =====
    const GROUP_KEY = 'iot_sensor_groups_closed';
    let closedGroups = new Set();
    try { closedGroups = new Set(JSON.parse(localStorage.getItem(GROUP_KEY) || '[]')); } catch (e) {}

    function applyGroupState() {
        document.querySelectorAll('details.sensor-group').forEach(function (d) {
            if (closedGroups.has(d.dataset.group)) d.removeAttribute('open');
            else d.setAttribute('open', 'open');
        });
    }
    function saveGroupState() {
        try { localStorage.setItem(GROUP_KEY, JSON.stringify(Array.from(closedGroups))); } catch (e) {}
    }
    document.querySelectorAll('details.sensor-group').forEach(function (d) {
        d.addEventListener('toggle', function () {
            if (d.open) closedGroups.delete(d.dataset.group);
            else closedGroups.add(d.dataset.group);
            saveGroupState();
        });
    });
    if (localStorage.getItem(GROUP_KEY) !== null) applyGroupState();

    // «Служебные» (технические топики) показываем только по галочке
    const SERVICE_KEY = 'iot_sensor_show_service';
    function toggleService(show) {
        document.querySelectorAll('details.sensor-group[data-service="1"]').forEach(function (d) {
            d.style.display = show ? '' : 'none';
        });
        try { localStorage.setItem(SERVICE_KEY, show ? '1' : '0'); } catch (e) {}
    }
    (function () {
        var box = document.getElementById('showService');
        if (!box) return;
        var saved = null;
        try { saved = localStorage.getItem(SERVICE_KEY); } catch (e) {}
        if (saved === '1') { box.checked = true; toggleService(true); }
    })();

    function toggleAllGroups(open) {
        document.querySelectorAll('details.sensor-group:not([data-service="1"])').forEach(function (d) {
            if (open) { d.setAttribute('open', 'open'); closedGroups.delete(d.dataset.group); }
            else { d.removeAttribute('open'); closedGroups.add(d.dataset.group); }
        });
        saveGroupState();
    }

    function filterSensors(q) {
        q = (q || '').trim().toLowerCase();
        document.querySelectorAll('details.sensor-group').forEach(function (d) {
            let visible = 0;
            d.querySelectorAll('.sensor-card').forEach(function (card) {
                const hit = !q || card.textContent.toLowerCase().indexOf(q) !== -1;
                card.style.display = hit ? '' : 'none';
                if (hit) visible++;
            });
            d.style.display = (visible === 0) ? 'none' : '';
            if (q && visible > 0) d.setAttribute('open', 'open');
        });
    }

    function fillForm(topic, name, room, group, icon, saveHistory) {
        document.querySelector("[name='topic']").value = topic;
        document.querySelector("[name='name']").value = name;
        document.querySelector("[name='room']").value = room;
        document.querySelector("[name='group_name']").value = group;
        document.querySelector("[name='icon']").value = icon;
        document.querySelector("[name='save_history']").checked = saveHistory === true || saveHistory === 'true';
        
        // Плавный скролл к форме
        window.scrollTo({ top: 0, behavior: 'smooth' });
        
        // Подсветка поля топика
        const topicInput = document.querySelector("[name='topic']");
        topicInput.style.backgroundColor = '#3a3a5a';
        setTimeout(() => {
            topicInput.style.backgroundColor = '';
        }, 1000);
    }


function editSensor(sensor) {
    document.querySelector("[name='topic']").value = sensor.topic || '';
    document.querySelector("[name='name']").value = sensor.name || '';
    document.querySelector("[name='room']").value = sensor.room || '';
    document.querySelector("[name='group_name']").value = sensor.group || '';
    document.querySelector("[name='icon']").value = sensor.icon || '';
    document.querySelector("[name='save_history']").checked = sensor.save_history === true || sensor.save_history === 'true';
    
    // Плавный скролл к форме
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    // Подсветка поля топика
    const topicInput = document.querySelector("[name='topic']");
    topicInput.style.backgroundColor = '#3a3a5a';
    setTimeout(() => {
        topicInput.style.backgroundColor = '';
    }, 1000);
}
    </script>

</body>
</html>
