<?php
require_once '/var/www/html/iot/config/iot_config.php';

// /var/www/html/iot/public_html/admin/set_channel.php
$topic = $_GET['topic'] ?? '';
$channel = $_GET['channel'] ?? '';
$value = $_GET['value'] ?? '';

if (!$topic || !$channel || !$value) {
    http_response_code(400);
    die('Нужны topic, channel, value');
}

try {
    $pdo = iot_pdo();
    $stmt = $pdo->prepare("SELECT value FROM sensor_data WHERE topic = ?");
    $stmt->execute([$topic]);
    $row = $stmt->fetch();

    if (!$row) {
        die("Устройство не найдено в БД");
    }

    $data = json_decode($row['value'], true);
    if (!is_array($data)) {
        die("Некорректные данные в БД");
    }

    // Меняем только указанный канал
    $data[$channel] = $value;

    // Формируем payload
    $payload = json_encode($data, JSON_UNESCAPED_SLASHES);

    // Отправляем в MQTT
    $cmd = sprintf(
        'mosquitto_pub -h localhost -u %s -P %s -t %s -m %s',
        escapeshellarg(IOT_MQTT_USER),
        escapeshellarg(IOT_MQTT_PASS),
        escapeshellarg($topic),
        escapeshellarg($payload)
    );

    exec($cmd, $output, $return_code);

    if ($return_code === 0) {
        echo "✅ $channel = $value";
        error_log("✅ Полная команда отправлена: $topic = $payload");
    } else {
        http_response_code(500);
        echo "❌ Ошибка MQTT";
        error_log("❌ MQTT error: $cmd");
    }

} catch (Exception $e) {
    http_response_code(500);
    echo "❌ Ошибка БД: " . $e->getMessage();
}
