<?php
/**
 * /admin/batteries.php — полная таблица состояния элементов питания.
 *
 * Логика расчёта — в include/battery_lib.php (общая с карточкой на главной).
 * Пороги — в таблице battery_spec. Здесь только показ.
 */
require_once '/var/www/html/iot/config/iot_config.php';

date_default_timezone_set('Europe/Moscow');

session_start();
if (!isset($_SESSION['iot_admin'])) {
    header('Location: /admin/sensors.php');
    exit;
}

$rows    = [];
$counts  = ['dead' => 0, 'replace' => 0, 'stale' => 0, 'unknown' => 0, 'ok' => 0, 'total' => 0];
$dbError = '';

try {
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    require_once '/var/www/html/iot/public_html/include/battery_lib.php';
    $rows   = iot_battery_status($pdo);
    $counts = iot_battery_counts($rows);

    // Когда включилось накопление истории по батарейкам — чтобы человек
    // понимал, почему тренд пока пустой.
    $histSince = null;
    try {
        $histSince = $pdo->query(
            "SELECT MIN(timestamp) FROM sensor_history
             WHERE topic LIKE 'zigbee2mqtt/%/voltage' OR topic LIKE 'zigbee2mqtt/%/battery'"
        )->fetchColumn();
    } catch (Throwable $e) {
    }
} catch (Throwable $e) {
    $dbError = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0a0e12">
    <title>🔋 Батарейки — IoT Система</title>
    <link rel="stylesheet" href="/css/style.css">
    <style>
        /* Таблица широкая — на телефоне разъезжается, поэтому прокрутка. */
        .bat-wrap { overflow-x: auto; }
        table.bat { width: 100%; border-collapse: collapse; font-size: 0.86rem; }
        table.bat th, table.bat td {
            border-bottom: 1px solid var(--border, #3a3a4a);
            padding: 0.55rem 0.6rem; text-align: left; vertical-align: top;
        }
        table.bat th { color: var(--text-secondary, #a0a0b0); font-weight: 600; white-space: nowrap; }
        table.bat tr:hover td { background: var(--bg-hover, #2a2a3a); }
        table.bat tr.row-dead td { background: rgba(248, 81, 73, 0.12); }
        table.bat tr.row-replace td { background: rgba(210, 153, 34, 0.10); }
        table.bat .num { white-space: nowrap; }
        table.bat .mut { color: var(--text-secondary, #a0a0b0); font-size: 0.8rem; }
        .bat-legend { font-size: 0.88rem; line-height: 1.6; }
        .bat-legend code { background: var(--bg-input, #2d2d3a); padding: 1px 5px; border-radius: 5px; }
    </style>
</head>
<body>
<div class="container">
    <?php include '/var/www/html/iot/public_html/include/links_panel.php'; ?>

    <h1>🔋 Батарейки</h1>

    <?php if ($dbError !== ''): ?>
        <div class="card"><div class="card-body">
            <div class="empty-state">Ошибка базы: <?= htmlspecialchars($dbError) ?></div>
            <div class="mut" style="font-size:.85rem;margin-top:.5rem">
                Если написано «таблица battery_spec недоступна» — залей её: <code>mysql iot_db &lt; battery.sql</code>
            </div>
        </div></div>
    <?php elseif (empty($rows)): ?>
        <div class="card"><div class="card-body">
            <div class="empty-state">Справочник <code>battery_spec</code> пуст — нечего показывать</div>
        </div></div>
    <?php else: ?>

    <!-- Итог: сколько устройств в каком состоянии -->
    <div class="sensors-grid" style="margin-bottom:1.5rem">
        <div class="sensor-card">
            <div class="card-header">
                <span class="sensor-icon">⛔</span>
                <span class="sensor-topic">Вышли из строя</span>
                <span class="history-badge <?= $counts['dead'] ? 'badge-error' : 'badge-success' ?>"><?= $counts['dead'] ?></span>
            </div>
            <div class="card-body">
                <div class="sensor-property"><span class="property-label">Что делать</span>
                    <span class="property-value">менять сразу — устройство уже не работает или вот-вот откажет</span></div>
            </div>
        </div>
        <div class="sensor-card">
            <div class="card-header">
                <span class="sensor-icon">🟠</span>
                <span class="sensor-topic">Пора менять</span>
                <span class="history-badge <?= $counts['replace'] ? 'badge-warning' : 'badge-success' ?>"><?= $counts['replace'] ?></span>
            </div>
            <div class="card-body">
                <div class="sensor-property"><span class="property-label">Что делать</span>
                    <span class="property-value">заряда хватит ненадолго; купить элемент и поменять в ближайшие недели</span></div>
            </div>
        </div>
        <div class="sensor-card">
            <div class="card-header">
                <span class="sensor-icon">🕓</span>
                <span class="sensor-topic">Нет связи</span>
                <span class="history-badge <?= $counts['stale'] ? 'badge-warning' : 'badge-success' ?>"><?= $counts['stale'] ?></span>
            </div>
            <div class="card-body">
                <div class="sensor-property"><span class="property-label">Что делать</span>
                    <span class="property-value">молчит больше 3 суток. Первое подозрение — севший элемент, но может быть и потеря связи
                    (у датчиков, которые пишут только по событию, тишина бывает нормальной)</span></div>
            </div>
        </div>
        <div class="sensor-card">
            <div class="card-header">
                <span class="sensor-icon">🟢</span>
                <span class="sensor-topic">В норме</span>
                <span class="history-badge badge-success"><?= $counts['ok'] ?></span>
            </div>
            <div class="card-body">
                <div class="sensor-property"><span class="property-label">Всего устройств с батарейками</span>
                    <span class="property-value"><?= $counts['total'] ?></span></div>
            </div>
        </div>
    </div>

    <!-- Полная таблица -->
    <div class="card" style="margin-bottom:1.5rem">
        <div class="card-header">
            <span class="card-title">Все устройства с элементами питания</span>
            <span class="history-badge">худшие — сверху</span>
        </div>
        <div class="card-body">
            <div class="bat-wrap">
            <table class="bat">
                <tr>
                    <th>Состояние</th>
                    <th>Устройство</th>
                    <th>Комната</th>
                    <th>Элемент</th>
                    <th>Заряд</th>
                    <th>Напряжение</th>
                    <th>Пороги</th>
                    <th>Обновлено</th>
                    <th>Тренд 7 суток</th>
                </tr>
                <?php foreach ($rows as $r): ?>
                <tr class="row-<?= htmlspecialchars($r['state']) ?>">
                    <td class="num">
                        <?= $r['icon'] ?>
                        <span class="badge <?= htmlspecialchars($r['badge_class']) ?>"><?= htmlspecialchars($r['badge_label']) ?></span>
                        <?php if ($r['reason'] !== ''): ?>
                            <div class="mut"><?= htmlspecialchars($r['reason']) ?></div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?= htmlspecialchars($r['title']) ?>
                        <div class="mut"><code><?= htmlspecialchars($r['device']) ?></code></div>
                    </td>
                    <td><?= $r['room'] !== '' && $r['room'] !== null ? htmlspecialchars($r['room']) : '—' ?></td>
                    <td><?= htmlspecialchars($r['element']) ?>
                        <?php if (!empty($r['note'])): ?><div class="mut"><?= htmlspecialchars($r['note']) ?></div><?php endif; ?>
                    </td>
                    <td class="num">
                        <?= $r['pct'] !== null ? rtrim(rtrim(number_format($r['pct'], 1, ',', ' '), '0'), ',') . ' %' : '—' ?>
                    </td>
                    <td class="num">
                        <?php if ($r['mv'] !== null): ?>
                            <?= number_format($r['mv'], 0, ',', ' ') ?> мВ
                            <div class="mut"><?= number_format($r['mv'] / 1000, 2, ',', '') ?> В</div>
                        <?php else: ?>
                            <span class="mut">не отдаёт</span>
                        <?php endif; ?>
                    </td>
                    <td class="mut"><?= htmlspecialchars($r['thresholds']) ?></td>
                    <td class="num">
                        <?= iot_battery_ago($r['batt_ts']) ?>
                        <?php if ($r['stale_days'] !== null): ?>
                            <div class="mut">устройство: <?= $r['stale_days'] < 1 ? 'меньше суток' : htmlspecialchars(rtrim(rtrim(number_format($r['stale_days'], 1, ',', ' '), '0'), ',')) . ' дн назад' ?></div>
                        <?php endif; ?>
                    </td>
                    <td class="mut">
                        <?php if ($r['trend_v'] !== '' || $r['trend_p'] !== ''): ?>
                            <?php if ($r['trend_v'] !== ''): ?><div>напряжение: <?= htmlspecialchars($r['trend_v']) ?></div><?php endif; ?>
                            <?php if ($r['trend_p'] !== ''): ?><div>заряд: <?= htmlspecialchars($r['trend_p']) ?></div><?php endif; ?>
                        <?php else: ?>
                            копится
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
            </div>
        </div>
    </div>

    <!-- Как это считается: чтобы через полгода не гадать, откуда цифры -->
    <div class="card" style="margin-bottom:1.5rem">
        <div class="card-header"><span class="card-title">ℹ️ Как это считается</span></div>
        <div class="card-body bat-legend">
            <div class="sensor-property">
                <span class="property-label">📏 Пороги</span>
                <span class="property-value">
                    Берутся из таблицы <code>battery_spec</code> — по каждому устройству отдельно, потому что
                    элементы разные: <b>CR2032</b> (1 шт., 3,0 В), <b>2×AAA</b> (3,0 В), <b>4×AA</b> (6,0 В).
                    Один общий порог для всех дал бы ерунду: 6,0 В у крана и 3,0 В у таблетки — разные шкалы.
                </span>
            </div>
            <div class="sensor-property">
                <span class="property-label">⚡ Почему вольтаж важнее процента</span>
                <span class="property-value">
                    Процент Zigbee2MQTT считает по приблизительной кривой разряда, поэтому он «ступенчатый» и врёт
                    на краях диапазона. Напряжение — сырой факт с устройства. Поэтому состояние берётся по <b>худшему</b>
                    из двух сигналов: если вольтаж уже ниже порога, а процент ещё бодрый — всё равно «пора менять».
                </span>
            </div>
            <div class="sensor-property">
                <span class="property-label">🔢 Милливольты против вольт</span>
                <span class="property-value">
                    Тонкость дома: у устройств с батарейкой поле <code>voltage</code> — это <b>милливольты</b>
                    (2500…3000), а у розетки с измерением мощности то же поле — это <b>вольты сети</b> (207…253).
                    Розетка в эту таблицу не попадает вообще: список устройств задан справочником, а не поиском
                    по имени топика. Иначе розетка с 218 В выглядела бы как «батарейка заряжена на 7000 %».
                </span>
            </div>
            <div class="sensor-property">
                <span class="property-label">🕓 «Нет связи» — не то же самое, что «села батарейка»</span>
                <span class="property-value">
                    Если устройство молчит дольше 3 суток, его последние цифры — замороженный снимок, а не текущее
                    состояние. Такое показывается отдельно, с числом дней молчания. Первое подозрение — элемент,
                    но датчик, который пишет только по событию (вибрация, протечка), может молчать и просто так.
                </span>
            </div>
            <div class="sensor-property">
                <span class="property-label">📈 Тренд</span>
                <span class="property-value">
                    Накопление истории по батарейкам и напряжениям включено —
                    <code>sensor_history</code>, последние 7 суток.
                    <?php if ($histSince): ?>
                        Первая точка: <?= htmlspecialchars($histSince) ?>.
                    <?php else: ?>
                        Точек пока нет — появятся по мере поступления сообщений.
                    <?php endif; ?>
                    Свежие сообщения по батарейкам приходят раз в часы-сутки, так что первые сутки график будет редким.
                </span>
            </div>
            <div class="sensor-property">
                <span class="property-label">✉️ Письмо</span>
                <span class="property-value">
                    Раз в сутки (09:00) то же самое проверяет <code>/home/mazzick/check_battery.py</code> —
                    пороги берёт из этой же таблицы. Письмо уходит только когда состояние изменилось,
                    чтобы не спамить одинаковым «всё в норме» каждый день.
                </span>
            </div>
            <div class="sensor-property">
                <span class="property-label">🛠 Добавить устройство</span>
                <span class="property-value">
                    Одна строка в <code>battery_spec</code>: устройство, тип элемента, число штук, пороги.
                    Код править не нужно — страница, карточка на главной и письмо подхватят автоматически.
                </span>
            </div>
            <div class="sensor-timestamp">🕒 Страница собрана: <?= date('Y-m-d H:i:s') ?></div>
        </div>
    </div>

    <?php endif; ?>
</div>
</body>
</html>
