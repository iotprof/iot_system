<?php
/**
 * anomalies.php — карточки анализа аномалий (модуль «профессионального» уровня).
 *
 * Логика: выбираешь топик → сервис iot-anomaly собирает по нему точки и сам ищет аномалии
 * (жёсткие пределы, выбросы относительно нормы по медиане/MAD, пропажу данных).
 * Когда статистика накоплена — нажимаешь «Проанализировать нейросетью»: страница кладёт
 * запрос в anomaly_requests, сервис подставляет в твой промпт статистику и найденные
 * аномалии, отправляет в нейросеть и сохраняет ответ в отчёте карточки.
 *
 * Весь интерфейс — на общем /css/style.css и общей навигации include/links_panel.php,
 * как остальные страницы панели (тёмная/светлая тема, адаптивное меню).
 */
require_once '/var/www/html/iot/config/iot_config.php';
session_start();
if (!isset($_SESSION['iot_admin'])) {
    header('Location: /admin/sensors.php');
    exit;
}
date_default_timezone_set('Europe/Moscow');

$KINDS = [
    'limit_low'  => 'ниже предела',
    'limit_high' => 'выше предела',
    'dip'        => 'просадка',
    'spike'      => 'выброс вверх',
    'no_data'    => 'нет данных',
];
$KIND_ICON = [
    'limit_low' => '🔴', 'limit_high' => '🔴', 'dip' => '🟠', 'spike' => '🟠', 'no_data' => '⚪',
];

$pdo = iot_pdo();
$message = '';
$error = '';

function post($k, $d = '') { return isset($_POST[$k]) ? trim((string)$_POST[$k]) : $d; }
function checked($v) { return !empty($v) ? 'checked' : ''; }

// ------------------------------------------------------------------ действия
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = post('action');
    try {
        switch ($action) {
            case 'save_watcher':
                $id = (int)post('id', '0');
                $f = [
                    'name'             => post('name'),
                    'topic'            => post('topic'),
                    'unit'             => post('unit'),
                    'collect_interval' => max(10, (int)post('collect_interval', '60')),
                    'window_hours'     => max(1, (int)post('window_hours', '24')),
                    'min_samples'      => max(5, (int)post('min_samples', '20')),
                    'limit_min'        => post('limit_min') === '' ? null : (float)post('limit_min'),
                    'limit_max'        => post('limit_max') === '' ? null : (float)post('limit_max'),
                    'spike_factor'     => (float)post('spike_factor', '6'),
                    'cooldown_events'  => max(60, (int)post('cooldown_events', '900')),
                    'gap_intervals'    => max(2, (int)post('gap_intervals', '3')),
                    'prompt'           => post('prompt'),
                    'ai_provider'      => post('ai_provider'),
                    'ai_model'         => post('ai_model'),
                    'ai_enabled'       => post('ai_enabled') === '1' ? 1 : 0,
                    'notify_email'     => (function () {
                        $e = post('notify_email');
                        if ($e === '') { return null; }
                        return filter_var($e, FILTER_VALIDATE_EMAIL) ? $e : null;
                    })(),
                    'notify_min_severity' => in_array(post('notify_min_severity'), ['info', 'warning', 'critical'], true) ? post('notify_min_severity') : 'critical',
                    'notes'            => mb_substr(post('notes'), 0, 250),
                ];
                if ($f['name'] === '' || $f['topic'] === '') {
                    throw new RuntimeException('Нужны название и топик');
                }
                if ($id > 0) {
                    $set = implode(', ', array_map(fn($k) => "$k = :$k", array_keys($f)));
                    $pdo->prepare("UPDATE anomaly_watchers SET $set WHERE id = :id")
                        ->execute($f + ['id' => $id]);
                    $message = '✅ Карточка «' . htmlspecialchars($f['name']) . '» сохранена';
                } else {
                    $cols = implode(', ', array_keys($f));
                    $ph = implode(', ', array_map(fn($k) => ":$k", array_keys($f)));
                    $pdo->prepare("INSERT INTO anomaly_watchers ($cols) VALUES ($ph)")->execute($f);
                    $message = '✅ Карточка добавлена — сбор данных пошёл';
                }
                break;

            case 'delete_watcher':
                $pdo->prepare("DELETE FROM anomaly_watchers WHERE id = ?")->execute([(int)post('id')]);
                $message = '✅ Карточка удалена вместе с точками, аномалиями и отчётами';
                break;

            case 'reset_samples':
                $id = (int)post('id');
                $pdo->prepare("DELETE FROM anomaly_samples WHERE watcher_id = ?")->execute([$id]);
                $pdo->prepare("DELETE FROM anomaly_events WHERE watcher_id = ?")->execute([$id]);
                $pdo->prepare("UPDATE anomaly_watchers SET samples_count = 0, status = 'collecting',
                               started_at = NOW(), last_sample_at = NULL WHERE id = ?")->execute([$id]);
                $message = '✅ Сбор начат заново: точки и найденные аномалии очищены';
                break;

            case 'toggle':
                $pdo->prepare("UPDATE anomaly_watchers SET enabled = 1 - enabled WHERE id = ?")->execute([(int)post('id')]);
                $message = '✅ Режим сбора переключён';
                break;

            case 'request_ai':
                $id = (int)post('id');
                $st = $pdo->prepare("SELECT prompt FROM anomaly_watchers WHERE id = ?");
                $st->execute([$id]);
                $pdo->prepare("INSERT INTO anomaly_requests (watcher_id, prompt) VALUES (?, ?)")
                    ->execute([$id, (string)$st->fetchColumn()]);
                $pdo->prepare("UPDATE anomaly_watchers SET status = 'analyzing' WHERE id = ?")->execute([$id]);
                $message = '🤖 Запрос поставлен в очередь — через несколько секунд появится отчёт ниже';
                break;

            case 'ack':
                $pdo->prepare("UPDATE anomaly_events SET acknowledged = 1 WHERE id = ?")->execute([(int)post('id')]);
                $message = '✅ Отмечено просмотренным';
                break;

            case 'ack_all':
                $pdo->prepare("UPDATE anomaly_events SET acknowledged = 1 WHERE watcher_id = ?")->execute([(int)post('id')]);
                $message = '✅ Все аномалии карточки отмечены просмотренными';
                break;

            case 'clear_events':
                $pdo->prepare("DELETE FROM anomaly_events WHERE watcher_id = ?")->execute([(int)post('id')]);
                $message = '✅ Журнал аномалий очищен';
                break;

            case 'delete_report':
                $pdo->prepare("DELETE FROM anomaly_reports WHERE id = ?")->execute([(int)post('id')]);
                $message = '✅ Отчёт удалён';
                break;
        }
    } catch (Throwable $e) {
        $error = '❌ Ошибка: ' . $e->getMessage();
    }
}

// ------------------------------------------------------------------ данные
$watchers = $pdo->query("SELECT * FROM anomaly_watchers ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
$allTopics = $pdo->query("SELECT topic FROM sensor_data ORDER BY topic")->fetchAll(PDO::FETCH_COLUMN);

$cfg = @parse_ini_file(IOT_CONF_FILE, true);
$aiProvider = (string)($cfg['ai']['provider'] ?? 'disabled');
$aiEnabled = ((int)($cfg['ai']['enabled'] ?? 0) === 1) && $aiProvider !== '' && $aiProvider !== 'disabled';

$stat = [];
foreach ($watchers as $w) {
    $since = date('Y-m-d H:i:s', time() - (int)$w['window_hours'] * 3600);
    $q = $pdo->prepare("SELECT COUNT(*) n, MIN(value) mn, MAX(value) mx, AVG(value) av, MAX(taken_at) last
                        FROM anomaly_samples WHERE watcher_id = ? AND taken_at >= ?");
    $q->execute([$w['id'], $since]);
    $stat[$w['id']] = $q->fetch(PDO::FETCH_ASSOC);

    $q = $pdo->prepare("SELECT COUNT(*) FROM anomaly_samples WHERE watcher_id = ?");
    $q->execute([$w['id']]);
    $stat[$w['id']]['total'] = (int)$q->fetchColumn();

    $q = $pdo->prepare("SELECT COUNT(*) FROM anomaly_events WHERE watcher_id = ? AND acknowledged = 0");
    $q->execute([$w['id']]);
    $stat[$w['id']]['unread'] = (int)$q->fetchColumn();

    $q = $pdo->prepare("SELECT COUNT(*) FROM anomaly_requests WHERE watcher_id = ? AND status IN ('pending','running')");
    $q->execute([$w['id']]);
    $stat[$w['id']]['queued'] = (int)$q->fetchColumn();
}

$totalWatchers = count($watchers);
$totalPoints = (int)$pdo->query("SELECT COUNT(*) FROM anomaly_samples")->fetchColumn();
$totalUnread = (int)$pdo->query("SELECT COUNT(*) FROM anomaly_events WHERE acknowledged = 0")->fetchColumn();
$totalReports = (int)$pdo->query("SELECT COUNT(*) FROM anomaly_reports")->fetchColumn();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <meta name="theme-color" content="#0a0e12">
    <link rel="manifest" href="/manifest.json">
    <title>🔍 Аномалии</title>
    <link rel="stylesheet" href="/css/style.css">
    <style>
        /* только то, чего нет в style.css — всё остальное берём из общей темы */
        .an-stats { display:flex; flex-wrap:wrap; gap:12px; margin-bottom:20px; }
        .an-stat {
            flex:1; min-width:150px; background:var(--bg-card); border:1px solid var(--border);
            border-radius:12px; padding:12px 16px;
        }
        .an-stat .num { font-size:1.6em; font-weight:bold; color:var(--text-primary); display:block; }
        .an-stat .lbl { color:var(--text-secondary); font-size:.85em; }

        .an-card {
            background:var(--bg-card); border:1px solid var(--border); border-radius:16px;
            padding:20px; margin-bottom:20px;
        }
        .an-card.off { opacity:.55; }
        .an-card h3 { margin:0 0 4px; font-size:1.15em; color:var(--text-primary); }
        .an-sub { color:var(--text-secondary); font-size:.85em; line-height:1.6; }
        .an-sub code { background:var(--bg-input); padding:2px 6px; border-radius:6px; color:var(--accent); }

        .an-metrics { display:grid; grid-template-columns:repeat(auto-fit,minmax(120px,1fr)); gap:10px; margin:16px 0; }
        .an-metric { background:var(--bg-card-secondary); border-radius:10px; padding:10px 12px; }
        .an-metric .v { font-size:1.15em; font-weight:600; color:var(--text-primary); display:block; }
        .an-metric .k { color:var(--text-secondary); font-size:.8em; }

        .an-actions { display:flex; flex-wrap:wrap; gap:8px; align-items:center; margin:14px 0 4px; }
        .an-actions form { display:inline; }
        .an-btn {
            background:var(--bg-input); color:var(--text-primary); border:1px solid var(--border);
            padding:8px 14px; border-radius:10px; cursor:pointer; font-size:.88em; transition:all .2s;
        }
        .an-btn:hover { background:var(--bg-hover); border-color:var(--accent); }
        .an-btn.primary { background:var(--accent); border-color:var(--accent); color:#fff; }
        .an-btn.primary:hover { background:var(--accent-hover); }
        .an-btn.primary:disabled { opacity:.5; cursor:not-allowed; }
        .an-btn.danger { color:var(--error); border-color:var(--error); }
        .an-btn.danger:hover { background:var(--error-bg); }

        .an-details { margin-top:14px; border-top:1px solid var(--border); padding-top:12px; }
        .an-details > summary {
            cursor:pointer; color:var(--accent); font-size:.92em; padding:4px 0; list-style:none;
        }
        .an-details > summary::-webkit-details-marker { display:none; }
        .an-details > summary::before { content:"▸ "; }
        .an-details[open] > summary::before { content:"▾ "; }

        .an-table { width:100%; border-collapse:collapse; font-size:.85em; margin-top:10px; }
        .an-table th, .an-table td {
            border-bottom:1px solid var(--border-light); padding:8px 10px; text-align:left; vertical-align:top;
        }
        .an-table th { color:var(--text-primary); font-weight:600; background:var(--bg-card-secondary); }
        .an-table td { color:var(--text-secondary); }
        .an-table code { color:var(--accent); }

        .an-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(210px,1fr)); gap:12px; }
        .an-field label { display:block; color:var(--text-secondary); font-size:.82em; margin-bottom:4px; }
        .an-field input, .an-field select, .an-field textarea {
            width:100%; background:var(--bg-input); color:var(--text-primary);
            border:1px solid var(--border); border-radius:10px; padding:8px 10px; font:inherit; font-size:.9em;
        }
        .an-field textarea { min-height:130px; resize:vertical; }
        .an-wide { grid-column:1 / -1; }

        .an-report { background:var(--bg-card-secondary); border:1px solid var(--border); border-radius:12px; padding:14px; margin-top:12px; }
        .an-report pre {
            white-space:pre-wrap; word-wrap:break-word; background:var(--bg-input); color:var(--text-primary);
            border:1px solid var(--border); border-radius:10px; padding:12px; font-size:.85em; margin:10px 0 0;
        }
        .an-hint {
            background:var(--info-bg); border-left:4px solid var(--info); border-radius:10px;
            padding:14px 16px; margin-bottom:20px; color:var(--text-primary); font-size:.9em; line-height:1.6;
        }
        .an-hint code { background:var(--bg-input); padding:2px 6px; border-radius:6px; color:var(--accent); }
        .an-live { display:inline-block; width:8px; height:8px; border-radius:50%; background:var(--success); margin-right:6px; }
        .an-live.pulse { animation:anp 1.4s infinite; }
        @keyframes anp { 0%,100%{opacity:1} 50%{opacity:.25} }
    </style>
</head>
<body>
<div class="container">
<?php include '/var/www/html/iot/public_html/include/links_panel.php'; ?>

<h2 style="margin-bottom:6px">🔍 Анализ аномалий</h2>
<div class="an-sub" style="margin-bottom:18px">
    Карточка = один топик + правила поиска аномалий + промпт для нейросети.
    Сбор идёт круглосуточно, разбор нейросетью — по кнопке.
</div>

<?php if ($message): ?><div class="message success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error): ?><div class="message error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="an-stats">
    <div class="an-stat"><span class="num"><?= $totalWatchers ?></span><span class="lbl">карточек наблюдения</span></div>
    <div class="an-stat"><span class="num"><?= number_format($totalPoints, 0, '', ' ') ?></span><span class="lbl">собранных точек</span></div>
    <div class="an-stat">
        <span class="num" style="color:<?= $totalUnread ? 'var(--error)' : 'var(--success)' ?>"><?= $totalUnread ?></span>
        <span class="lbl">аномалий без просмотра</span>
    </div>
    <div class="an-stat"><span class="num"><?= $totalReports ?></span><span class="lbl">отчётов нейросети</span></div>
    <div class="an-stat">
        <span class="num"><span class="an-live pulse"></span><?= $aiEnabled ? 'подключена' : 'не настроена' ?></span>
        <span class="lbl">нейросеть <?= htmlspecialchars($aiProvider) ?></span>
    </div>
</div>

<div class="an-hint">
    <b>Как это работает.</b> Сервис <code>iot-anomaly</code> каждые 15 секунд снимает значение топика и кладёт точку в
    <code>anomaly_samples</code>. Он же ищет четыре вида аномалий: выход за жёсткие пределы, выброс вверх и просадку
    относительно нормы (медиана ± <i>spike_factor</i> устойчивых сигм, а при нулевом разбросе — порог 2 % от нормы)
    и пропажу данных. Норму держим за окно в <i>window_hours</i> часов, поэтому она подстраивается под сезон и режим.
    Когда статистики достаточно, жмите «Проанализировать нейросетью» — в промпт автоматически подставится разбор по суткам
    и список найденных аномалий.
    <?php if (!$aiEnabled): ?><br><b>Нейросеть пока не подключена:</b> провайдер, адрес, модель и ключ задаются в
    <code>/etc/iot/credentials.ini</code>, секция <code>[ai]</code> — после этого кнопка вернёт настоящий разбор,
    а до тех пор она сохраняет статистику и подсказывает, что дописать.<?php endif; ?>
</div>

<?php if (!$watchers): ?>
    <div class="card"><div class="empty-state">Карточек пока нет — создайте первую в форме ниже.</div></div>
<?php endif; ?>

<?php foreach ($watchers as $w): $s = $stat[$w['id']]; $has = (int)$s['n'] > 0; ?>
<div class="an-card <?= $w['enabled'] ? '' : 'off' ?>" id="w<?= (int)$w['id'] ?>">
    <h3>
        <?= htmlspecialchars($w['name']) ?>
        <?php if ($w['enabled']): ?>
            <span class="badge badge-success">сбор идёт</span>
        <?php else: ?>
            <span class="badge">выключена</span>
        <?php endif; ?>
        <?php if ($s['unread'] > 0): ?><span class="badge badge-error">новых аномалий: <?= (int)$s['unread'] ?></span><?php endif; ?>
        <?php if (!empty($w['notify_email'])): ?><span class="badge badge-info">📧 <?= htmlspecialchars($w['notify_email']) ?></span><?php endif; ?>
        <?php if ($s['queued'] > 0): ?><span class="badge badge-warning">нейросеть думает…</span><?php endif; ?>
    </h3>
    <div class="an-sub">
        Топик: <code><?= htmlspecialchars($w['topic']) ?></code> ·
        съём раз в <?= (int)$w['collect_interval'] ?> с ·
        норма за <?= (int)$w['window_hours'] ?> ч ·
        пределы <?= $w['limit_min'] !== null ? htmlspecialchars((string)$w['limit_min']) : '—' ?> … <?= $w['limit_max'] !== null ? htmlspecialchars((string)$w['limit_max']) : '—' ?>
        <?= $w['unit'] ? ' ' . htmlspecialchars($w['unit']) : '' ?> ·
        последняя точка <?= htmlspecialchars((string)($w['last_sample_at'] ?? '—')) ?>
        <?= $w['notes'] ? '<br>' . htmlspecialchars($w['notes']) : '' ?>
    </div>

    <div class="an-metrics">
        <div class="an-metric"><span class="v"><?= (int)$s['total'] ?></span><span class="k">точек всего</span></div>
        <div class="an-metric"><span class="v"><?= (int)$s['n'] ?></span><span class="k">в окне нормы</span></div>
        <div class="an-metric"><span class="v"><?= $has ? number_format((float)$s['mn'], 2) : '—' ?></span><span class="k">минимум</span></div>
        <div class="an-metric"><span class="v"><?= $has ? number_format((float)$s['av'], 2) : '—' ?></span><span class="k">среднее</span></div>
        <div class="an-metric"><span class="v"><?= $has ? number_format((float)$s['mx'], 2) : '—' ?></span><span class="k">максимум</span></div>
        <div class="an-metric"><span class="v"><?= (int)$w['min_samples'] ?></span><span class="k">точек до анализа</span></div>
    </div>

    <div class="an-actions">
        <form method="post">
            <input type="hidden" name="action" value="request_ai"><input type="hidden" name="id" value="<?= (int)$w['id'] ?>">
            <button class="an-btn primary" <?= $has ? '' : 'disabled' ?>>🤖 Проанализировать нейросетью</button>
        </form>
        <form method="post">
            <input type="hidden" name="action" value="reset_samples"><input type="hidden" name="id" value="<?= (int)$w['id'] ?>">
            <button class="an-btn" onclick="return confirm('Очистить собранные точки и найденные аномалии этой карточки?')">↻ Начать сбор заново</button>
        </form>
        <form method="post">
            <input type="hidden" name="action" value="ack_all"><input type="hidden" name="id" value="<?= (int)$w['id'] ?>">
            <button class="an-btn">✓ Отметить просмотренными</button>
        </form>
        <form method="post">
            <input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$w['id'] ?>">
            <button class="an-btn"><?= $w['enabled'] ? '⏸ Приостановить сбор' : '▶ Возобновить сбор' ?></button>
        </form>
    </div>

    <details class="an-details">
        <summary>Настройки карточки и промпт для нейросети</summary>
        <form method="post" style="margin-top:14px">
            <input type="hidden" name="action" value="save_watcher">
            <input type="hidden" name="id" value="<?= (int)$w['id'] ?>">
            <div class="an-grid">
                <div class="an-field"><label>Название карточки</label><input name="name" value="<?= htmlspecialchars($w['name']) ?>" required></div>
                <div class="an-field"><label>Топик-источник</label>
                    <select name="topic">
                        <?php $found = false; foreach ($allTopics as $t): if ($t === $w['topic']) $found = true; ?>
                            <option value="<?= htmlspecialchars($t) ?>" <?= $t === $w['topic'] ? 'selected' : '' ?>><?= htmlspecialchars($t) ?></option>
                        <?php endforeach; ?>
                        <?php if (!$found): ?>
                            <option value="<?= htmlspecialchars($w['topic']) ?>" selected><?= htmlspecialchars($w['topic']) ?> (не в базе — нет данных)</option>
                        <?php endif; ?>
                    </select></div>
                <div class="an-field"><label>Единица измерения</label><input name="unit" value="<?= htmlspecialchars((string)$w['unit']) ?>" placeholder="V, W, °C, %"></div>
                <div class="an-field"><label>Съём раз в, сек</label><input name="collect_interval" type="number" min="10" value="<?= (int)$w['collect_interval'] ?>"></div>
                <div class="an-field"><label>Окно нормы, часов</label><input name="window_hours" type="number" min="1" value="<?= (int)$w['window_hours'] ?>"></div>
                <div class="an-field"><label>Точек до начала анализа</label><input name="min_samples" type="number" min="5" value="<?= (int)$w['min_samples'] ?>"></div>
                <div class="an-field"><label>Предел снизу (пусто = нет)</label><input name="limit_min" value="<?= $w['limit_min'] !== null ? htmlspecialchars((string)$w['limit_min']) : '' ?>"></div>
                <div class="an-field"><label>Предел сверху (пусто = нет)</label><input name="limit_max" value="<?= $w['limit_max'] !== null ? htmlspecialchars((string)$w['limit_max']) : '' ?>"></div>
                <div class="an-field"><label>Выброс = сколько сигм</label><input name="spike_factor" value="<?= htmlspecialchars((string)$w['spike_factor']) ?>"></div>
                <div class="an-field"><label>Пауза между однотипными аномалиями, сек</label><input name="cooldown_events" type="number" value="<?= (int)$w['cooldown_events'] ?>"></div>
                <div class="an-field"><label>Пропажа данных = сколько интервалов</label><input name="gap_intervals" type="number" value="<?= (int)$w['gap_intervals'] ?>"></div>
                <div class="an-field"><label>Провайдер ИИ (пусто = из настроек)</label><input name="ai_provider" value="<?= htmlspecialchars((string)$w['ai_provider']) ?>" placeholder="openai / mistral / ollama"></div>
                <div class="an-field"><label>Модель ИИ (пусто = из настроек)</label><input name="ai_model" value="<?= htmlspecialchars((string)$w['ai_model']) ?>" placeholder="gpt-4o-mini"></div>
                <div class="an-field"><label>Заметка</label><input name="notes" value="<?= htmlspecialchars((string)$w['notes']) ?>"></div>
                <div class="an-field"><label>Почта для уведомлений (пусто = не писать)</label>
                    <input name="notify_email" value="<?= htmlspecialchars((string)$w['notify_email']) ?>" placeholder="you@example.com"></div>
                <div class="an-field"><label>Писать начиная с важности</label>
                    <select name="notify_min_severity">
                        <?php foreach (['warning' => 'предупреждение и выше', 'critical' => 'только критичное', 'info' => 'всё подряд'] as $k => $lbl): ?>
                            <option value="<?= $k ?>" <?= ($w['notify_min_severity'] ?? 'critical') === $k ? 'selected' : '' ?>><?= $lbl ?></option>
                        <?php endforeach; ?>
                    </select></div>
                <div class="an-field an-wide">
                    <label>Промпт для нейросети — к нему автоматически добавится статистика по периоду и список аномалий</label>
                    <textarea name="prompt"><?= htmlspecialchars((string)$w['prompt']) ?></textarea>
                </div>
            </div>
            <div class="an-actions">
                <button class="an-btn primary" type="submit">Сохранить</button>
                <label class="an-sub" style="display:inline;margin:0">
                    <input type="checkbox" name="ai_enabled" value="1" style="width:auto" <?= checked($w['ai_enabled']) ?>>
                    включить разбор нейросетью для этой карточки
                </label>
            </div>
        </form>
        <form method="post" style="margin-top:10px">
            <input type="hidden" name="action" value="delete_watcher"><input type="hidden" name="id" value="<?= (int)$w['id'] ?>">
            <button class="an-btn danger" onclick="return confirm('Удалить карточку вместе с точками, аномалиями и отчётами?')">Удалить карточку</button>
        </form>
    </details>

    <?php
    $q = $pdo->prepare("SELECT * FROM anomaly_events WHERE watcher_id = ? ORDER BY detected_at DESC LIMIT 20");
    $q->execute([$w['id']]);
    $events = $q->fetchAll(PDO::FETCH_ASSOC);
    ?>
    <details class="an-details" <?= $s['unread'] > 0 ? 'open' : '' ?>>
        <summary>Журнал аномалий (последние <?= count($events) ?>)</summary>
        <?php if (!$events): ?>
            <div class="an-sub" style="margin-top:10px">Пока ничего не найдено — данные в пределах нормы.</div>
        <?php else: ?>
            <table class="an-table">
                <tr><th>Когда</th><th>Что</th><th>Значение</th><th>Норма</th><th>Отклонение</th><th>Пояснение</th><th></th></tr>
                <?php foreach ($events as $e): ?>
                <tr>
                    <td><?= htmlspecialchars($e['detected_at']) ?></td>
                    <td>
                        <?= $KIND_ICON[$e['kind']] ?? '•' ?>
                        <?= htmlspecialchars($KINDS[$e['kind']] ?? $e['kind']) ?>
                        <span class="badge <?= $e['severity'] === 'critical' ? 'badge-error' : 'badge-warning' ?>"><?= htmlspecialchars($e['severity']) ?></span>
                        <?= $e['acknowledged'] ? ' <span class="badge">просмотрено</span>' : '' ?>
                    </td>
                    <td><?= htmlspecialchars((string)$e['value']) ?></td>
                    <td><?= htmlspecialchars((string)$e['baseline']) ?></td>
                    <td><?= htmlspecialchars((string)$e['deviation']) ?></td>
                    <td><?= htmlspecialchars((string)$e['note']) ?></td>
                    <td>
                        <?php if (!$e['acknowledged']): ?>
                        <form method="post"><input type="hidden" name="action" value="ack"><input type="hidden" name="id" value="<?= (int)$e['id'] ?>">
                        <button class="an-btn">✓</button></form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
        <form method="post" style="margin-top:10px">
            <input type="hidden" name="action" value="clear_events"><input type="hidden" name="id" value="<?= (int)$w['id'] ?>">
            <button class="an-btn danger" onclick="return confirm('Очистить журнал аномалий этой карточки?')">Очистить журнал аномалий</button>
        </form>
    </details>

    <?php
    $q = $pdo->prepare("SELECT * FROM anomaly_reports WHERE watcher_id = ? ORDER BY created_at DESC LIMIT 5");
    $q->execute([$w['id']]);
    $reports = $q->fetchAll(PDO::FETCH_ASSOC);
    ?>
    <details class="an-details" <?= $reports ? 'open' : '' ?>>
        <summary>Отчёты нейросети (<?= count($reports) ?>)</summary>
        <?php if (!$reports): ?>
            <div class="an-sub" style="margin-top:10px">Отчётов ещё нет — нажмите «Проанализировать нейросетью».</div>
        <?php endif; ?>
        <?php foreach ($reports as $r): ?>
            <div class="an-report">
                <div style="display:flex;flex-wrap:wrap;gap:10px;justify-content:space-between;align-items:center">
                    <div class="an-sub">
                        <?= htmlspecialchars($r['created_at']) ?> ·
                        период <?= htmlspecialchars((string)$r['period_from']) ?> — <?= htmlspecialchars((string)$r['period_to']) ?> ·
                        точек <?= (int)$r['samples_used'] ?>, аномалий <?= (int)$r['events_used'] ?> ·
                        <?= htmlspecialchars($r['provider'] ?: '—') ?><?= $r['model'] ? ' / ' . htmlspecialchars($r['model']) : '' ?>
                        <span class="badge <?= $r['status'] === 'failed' ? 'badge-error' : ($r['status'] === 'ok_disabled' ? 'badge-warning' : 'badge-success') ?>"><?= htmlspecialchars($r['status']) ?></span>
                    </div>
                    <form method="post"><input type="hidden" name="action" value="delete_report"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <button class="an-btn danger">Удалить</button></form>
                </div>
                <?php if ($r['error']): ?><div class="message error" style="margin:10px 0"><?= htmlspecialchars($r['error']) ?></div><?php endif; ?>
                <?php if ($r['response']): ?><pre><?= htmlspecialchars($r['response']) ?></pre><?php endif; ?>
                <details class="an-details"><summary>показать статистику, отправленную в запрос</summary>
                    <pre><?= htmlspecialchars((string)$r['summary']) ?></pre></details>
            </div>
        <?php endforeach; ?>
    </details>
</div>
<?php endforeach; ?>

<h2 style="margin-top:30px">➕ Добавить карточку наблюдения</h2>
<div class="card">
    <form method="post">
        <input type="hidden" name="action" value="save_watcher">
        <div class="an-grid">
            <div class="an-field"><label>Название</label><input name="name" placeholder="Например: Температура серверной" required></div>
            <div class="an-field"><label>Топик-источник (из текущих данных)</label>
                <select name="topic">
                    <?php foreach ($allTopics as $t): ?><option value="<?= htmlspecialchars($t) ?>"><?= htmlspecialchars($t) ?></option><?php endforeach; ?>
                </select></div>
            <div class="an-field"><label>Единица измерения</label><input name="unit" placeholder="V, W, °C, %"></div>
            <div class="an-field"><label>Съём раз в, сек</label><input name="collect_interval" type="number" value="60"></div>
            <div class="an-field"><label>Окно нормы, часов</label><input name="window_hours" type="number" value="24"></div>
            <div class="an-field"><label>Предел снизу</label><input name="limit_min" placeholder="пусто = без предела"></div>
            <div class="an-field"><label>Предел сверху</label><input name="limit_max" placeholder="пусто = без предела"></div>
            <div class="an-field"><label>Выброс = сколько сигм</label><input name="spike_factor" value="6"></div>
            <div class="an-field"><label>Почта для уведомлений (пусто = не писать)</label><input name="notify_email" placeholder="you@example.com"></div>
            <div class="an-field an-wide"><label>Промпт для нейросети</label>
                <textarea name="prompt" placeholder="Опишите, что именно должна проанализировать нейросеть по этим данным: что считать опасным, на что обратить внимание, в каком виде нужен ответ…"></textarea></div>
        </div>
        <div class="an-actions"><button class="an-btn primary" type="submit">Добавить карточку</button></div>
    </form>
</div>

<div class="an-sub" style="margin-top:20px">
    Сервис: <code>systemctl status iot-anomaly</code> · лог <code>/home/mazzick/iot_anomaly.log</code> ·
    запросы к нейросети идут через таблицу <code>anomaly_requests</code> и выполняются в течение 15 секунд ·
    провайдер и ключ — в <code>/etc/iot/credentials.ini</code>, секция <code>[ai]</code>.
</div>

</div>
</body>
</html>
