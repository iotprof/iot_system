<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>IoT Automation Logs Viewer</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: #1e1e2e;
            color: #e0e0ff;
            font-family: 'Courier New', monospace;
            padding: 20px;
        }
        h1 {
            margin-bottom: 10px;
            font-size: 1.5em;
        }
        .controls {
            background: #252536;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }
        button {
            background: #6c63ff;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            font-family: inherit;
        }
        button:hover {
            background: #5a52d5;
        }
        .clear-btn {
            background: #f44336;
        }
        .clear-btn:hover {
            background: #d32f2f;
        }
        .auto {
            background: #4caf50;
        }
        .auto.active {
            background: #ff9800;
        }
        select, input {
            background: #2d2d3d;
            color: #e0e0ff;
            border: 1px solid #3a3a4a;
            padding: 8px;
            border-radius: 6px;
            font-family: inherit;
        }
        .log-container {
            background: #0a0a0f;
            border-radius: 8px;
            padding: 15px;
            height: 70vh;
            overflow-y: auto;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            border: 1px solid #3a3a4a;
        }
        .log-line {
            padding: 4px 8px;
            border-bottom: 1px solid #2a2a3a;
            white-space: pre-wrap;
            word-break: break-all;
        }
        .log-line:hover {
            background: #252536;
        }
        .timestamp {
            color: #6c63ff;
            margin-right: 15px;
        }
        .info {
            color: #4caf50;
        }
        .warning {
            color: #ff9800;
        }
        .error {
            color: #f44336;
        }
        .email {
            color: #ff69b4;
        }
        .status {
            background: #252536;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 12px;
        }
        .status span {
            color: #4caf50;
            font-weight: bold;
        }
        footer {
            margin-top: 20px;
            text-align: center;
            font-size: 11px;
            color: #6c63ff;
        }
    </style>
</head>
<body>
    <h1>📡 IoT Automation Logs Viewer</h1>
    <div class="controls">
        <button id="refreshBtn">🔄 Обновить</button>
        <button id="clearBtn" class="clear-btn">🗑️ Очистить</button>
        <button id="autoBtn" class="auto">▶️ Автообновление (вкл)</button>
        <select id="linesSelect">
            <option value="50">50 строк</option>
            <option value="100" selected>100 строк</option>
            <option value="200">200 строк</option>
            <option value="500">500 строк</option>
        </select>
        <input type="text" id="filterInput" placeholder="Фильтр (например, Email или TEST)" size="20">
    </div>
    <div class="status" id="status">
        🔄 Загрузка логов...
    </div>
    <div class="log-container" id="logContainer">
        <div class="log-line">Загрузка...</div>
    </div>
    <footer>
        Логи сервиса iot-automation | Обновление через AJAX
    </footer>

    <script>
        let autoRefresh = true;
        let refreshInterval = null;
        const logContainer = document.getElementById('logContainer');
        const statusDiv = document.getElementById('status');
        const refreshBtn = document.getElementById('refreshBtn');
        const clearBtn = document.getElementById('clearBtn');
        const autoBtn = document.getElementById('autoBtn');
        const linesSelect = document.getElementById('linesSelect');
        const filterInput = document.getElementById('filterInput');

        function getLogs() {
            const lines = linesSelect.value;
            const filter = filterInput.value;
            
            statusDiv.innerHTML = '⏳ Загрузка логов...';
            
            fetch(`/admin/logs_proxy.php?lines=${lines}&filter=${encodeURIComponent(filter)}&t=${Date.now()}`)
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        statusDiv.innerHTML = `❌ Ошибка: ${data.error}`;
                        return;
                    }
                    
                    statusDiv.innerHTML = `✅ ${data.count} строк | ${data.timestamp}`;
                    
                    if (data.logs.length === 0) {
                        logContainer.innerHTML = '<div class="log-line">📭 Нет записей по фильтру</div>';
                        return;
                    }
                    
                    let html = '';
                    data.logs.forEach(line => {
                        let colorClass = '';
                        if (line.includes('✅') || line.includes('Email отправлен')) colorClass = 'info';
                        else if (line.includes('❌') || line.includes('Ошибка')) colorClass = 'error';
                        else if (line.includes('⏱️') || line.includes('Слишком часто')) colorClass = 'warning';
                        else if (line.includes('📧') || line.includes('email')) colorClass = 'email';
                        
                        html += `<div class="log-line"><span class="timestamp">${line.substring(0, 19)}</span> <span class="${colorClass}">${escapeHtml(line)}</span></div>`;
                    });
                    logContainer.innerHTML = html;
                    logContainer.scrollTop = logContainer.scrollHeight;
                })
                .catch(error => {
                    statusDiv.innerHTML = `❌ Ошибка соединения: ${error.message}`;
                    console.error('Error:', error);
                });
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function startAutoRefresh() {
            if (refreshInterval) clearInterval(refreshInterval);
            refreshInterval = setInterval(() => {
                if (autoRefresh) getLogs();
            }, 3000);
        }

        refreshBtn.onclick = () => {
            getLogs();
        };

        clearBtn.onclick = () => {
            logContainer.innerHTML = '<div class="log-line">🗑️ Логи очищены. Обновите для загрузки новых.</div>';
            statusDiv.innerHTML = '📭 Логи очищены (только в браузере)';
        };

        autoBtn.onclick = () => {
            autoRefresh = !autoRefresh;
            if (autoRefresh) {
                autoBtn.textContent = '⏸️ Автообновление (вкл)';
                autoBtn.classList.add('active');
                getLogs();
            } else {
                autoBtn.textContent = '▶️ Автообновление (выкл)';
                autoBtn.classList.remove('active');
            }
        };

        linesSelect.onchange = () => {
            if (autoRefresh) getLogs();
        };

        filterInput.onkeyup = () => {
            if (autoRefresh) getLogs();
        };

        startAutoRefresh();
        getLogs();
    </script>
</body>
</html>
