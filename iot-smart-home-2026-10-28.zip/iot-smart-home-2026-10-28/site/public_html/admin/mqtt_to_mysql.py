import os
import paho.mqtt.client as mqtt
import pymysql.cursors
import json
import logging

HISTORY_TOPICS_CACHE = set()
LAST_CACHE_UPDATE = 0
CACHE_TTL = 60  # секунд

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("/home/mazzick/mqtt_logger.log"),
        logging.StreamHandler()
    ]
)

# Подключение к MySQL
try:
    connection = pymysql.connect(
        host='localhost',
        user=os.environ.get('IOT_DB_USER', 'iot_app'),
        password=os.environ.get('IOT_DB_PASS'),
        database='iot_db',
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )
    logging.info("✅ Подключено к MySQL")
except Exception as e:
    logging.error(f"❌ Ошибка подключения к MySQL: {e}")
    exit(1)

# Топики для истории
import time

def get_topics_for_history():
    global HISTORY_TOPICS_CACHE, LAST_CACHE_UPDATE
    now = time.time()
    if now - LAST_CACHE_UPDATE > CACHE_TTL:
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT topic FROM sensor_info WHERE save_history = 1")
                rows = cursor.fetchall()
                HISTORY_TOPICS_CACHE = {row['topic'] for row in rows}
                LAST_CACHE_UPDATE = now
                logging.debug(f"Обновлён кэш истории: {len(HISTORY_TOPICS_CACHE)} топиков")
        except Exception as e:
            logging.error(f"❌ Ошибка загрузки топиков для истории: {e}")
    return HISTORY_TOPICS_CACHE

def on_connect(client, userdata, flags, reason_code, properties):
    logging.info("✅ MQTT: Подключено")
    client.subscribe("zigbee2mqtt/#")

def on_message(client, userdata, msg):
    try:
        topic = msg.topic
        payload = msg.payload.decode()
        logging.debug(f"📥 Получено: {topic} = {payload}")

        # Игнорируем служебные топики
        if topic.startswith("zigbee2mqtt/bridge/"):
            return

        # Сохраняем ПОЛНЫЙ JSON как есть (важно для управления!)
        save_to_sensor_data(topic, payload)

        # Пытаемся распарсить
        data = json.loads(payload)
        if isinstance(data, dict):
            for key, value in data.items():
                if key in ['linkquality', 'countdown_l1', 'countdown_l2', 'countdown_l3',
                           'power_on_behavior_l1', 'last_seen', 'update', 'update_available']:
                    continue

                full_topic = f"{topic}/{key}"

                # 🔧 Исправлено: true → '1', false → '0'
                if isinstance(value, bool):
                    value_to_save = "1" if value else "0"
                else:
                    value_to_save = value

                # Сохраняем отдельное поле
                save_to_sensor_data(full_topic, str(value_to_save))

                # История — только для указанных топиков
                if full_topic in get_topics_for_history():
                    try:
                        save_to_history(full_topic, float(value_to_save))
                    except (ValueError, TypeError):
                        pass

    except json.JSONDecodeError:
        # Не JSON — сохраняем как есть (редко)
        save_to_sensor_data(topic, payload)
    except Exception as e:
        logging.error(f"❌ Ошибка обработки сообщения: {e}")

def save_to_sensor_data(topic, value):
    """Запись в sensor_data с заменой по топику (остаётся только последнее значение)"""
    try:
        with connection.cursor() as cursor:
            # Используем INSERT ... ON DUPLICATE KEY UPDATE
            sql = """
                INSERT INTO sensor_data (topic, value, timestamp)
                VALUES (%s, %s, NOW())
                ON DUPLICATE KEY UPDATE
                    value = VALUES(value),
                    timestamp = VALUES(timestamp)
            """
            cursor.execute(sql, (topic, str(value)))
        connection.commit()
        logging.debug(f"💾 Обновлено: {topic} = {value}")
    except Exception as e:
        logging.error(f"❌ Ошибка записи в sensor_data: {e}")

def save_to_history(topic, value):
    try:
        with connection.cursor() as cursor:
            cursor.execute(
                "INSERT INTO sensor_history (topic, value, timestamp) VALUES (%s, %s, NOW())",
                (topic, float(value))
            )
            # Оставить последние 144 (6 часов по 1 значению в 2.5 мин)
            cursor.execute("""
                DELETE h1 FROM sensor_history h1
                LEFT JOIN (
                    SELECT id FROM sensor_history
                    WHERE topic = %s
                    ORDER BY timestamp DESC
                    LIMIT 10000
                ) h2 ON h1.id = h2.id
                WHERE h2.id IS NULL AND h1.topic = %s
            """, (topic, topic))
        connection.commit()
    except Exception as e:
        logging.error(f"❌ История: {e}")

# MQTT клиент
client = mqtt.Client(callback_api_version=mqtt.CallbackAPIVersion.VERSION2)
client.username_pw_set(os.environ.get("IOT_MQTT_USER"), os.environ.get("IOT_MQTT_PASS"))
client.on_connect = on_connect
client.on_message = on_message

try:
    client.connect("localhost", 1883, 60)
    logging.info("📡 Подключено к MQTT. Ожидаю данные...")
    client.loop_forever()
except Exception as e:
    logging.error(f"❌ MQTT ошибка: {e}")
