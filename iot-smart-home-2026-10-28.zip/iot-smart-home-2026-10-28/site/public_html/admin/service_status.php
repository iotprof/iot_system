<?php
header('Content-Type: application/json');

function getServiceStatus() {
    $services_list = ['iot-automation', 'mqtt-to-mysql', 'zigbee2mqtt', 'mosquitto'];
    $statuses = [];
    
    foreach ($services_list as $service) {
        if ($service === 'zigbee2mqtt') {
            $cmd = "systemctl is-active zigbee2mqtt 2>&1";
        } else {
            $cmd = "systemctl is-active {$service}.service 2>&1";
        }
        $status = trim(shell_exec($cmd));
        
        if ($status === 'active') {
            $statuses[$service] = '✅ active';
        } elseif ($status === 'inactive') {
            $statuses[$service] = '❌ inactive';
        } else {
            $statuses[$service] = '⚠️ unknown';
        }
    }
    
    return $statuses;
}

echo json_encode(getServiceStatus());
?>
