<?php
/**
 * mqtt_client.php — небольшой клиент MQTT 3.1.1 на чистом PHP (через сокеты).
 *
 * Зачем свой клиент, а не mosquitto_sub/pub:
 *   — движку нужно СЛУШАТЬ брокер: событие приходит в ту же секунду, а не после
 *     опроса базы (раньше значения брались из таблицы sensor_data раз в секунду);
 *   — команды уходят по тому же открытому соединению, без запуска отдельного
 *     процесса mosquitto_pub на каждую команду;
 *   — подтверждения от устройств тоже приходят сообщением, а не вычитываются из базы.
 *
 * Умеет: подключение с логином и паролем, подписка на список тем, публикация (QoS 0),
 * поддержание соединения (keepalive), чтение входящих сообщений.
 *
 * Написан 12.10.2026 по просьбе владельца: «слушать брокер, а не базу».
 */

// Файл подключается только из движка (служба iot-automation). Из веба он не должен
// работать вообще: клиент умеет отправлять команды устройствам.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

class IotMqttClient
{
    private $host;
    private $port;
    private $user;
    private $pass;
    private $clientId;

    /** @var resource|null */
    private $sock = null;
    private $connected = false;

    private $rxbuf = '';
    private $packetId = 0;
    private $keepalive = 30;
    private $lastTx = 0;
    private $lastError = '';

    public function __construct(string $host, int $port, string $user = '', string $pass = '', string $clientId = '')
    {
        $this->host = $host;
        $this->port = $port;
        $this->user = $user;
        $this->pass = $pass;
        $this->clientId = $clientId !== '' ? $clientId : ('iot-engine-' . substr(md5(uniqid('', true)), 0, 8));
    }

    public function lastError(): string { return $this->lastError; }
    public function isConnected(): bool { return $this->connected; }
    public function clientId(): string { return $this->clientId; }

    /** Подключение и приветствие брокеру. true — можно работать. */
    public function connect(): bool
    {
        $this->closeSocket();
        $errno = 0; $errstr = '';
        $sock = @stream_socket_client('tcp://' . $this->host . ':' . $this->port, $errno, $errstr, 5);
        if (!$sock) {
            $this->lastError = "не соединиться с брокером {$this->host}:{$this->port} ($errstr)";
            $this->connected = false;
            return false;
        }
        stream_set_blocking($sock, false);
        stream_set_timeout($sock, 5);
        $this->sock = $sock;
        $this->rxbuf = '';

        // Переменная часть: имя протокола и его версия
        $payload = $this->str($this->clientId);
        $flags = 0x02;                       // чистая сессия
        if ($this->user !== '') { $flags |= 0x80; $payload .= $this->str($this->user); }
        if ($this->pass !== '') { $flags |= 0x40; $payload .= $this->str($this->pass); }

        $var = $this->str('MQTT') . chr(4) . chr($flags) . pack('n', $this->keepalive);
        $this->send($this->packet(0x10, $var . $payload));
        $this->lastTx = time();

        $reply = $this->readPacket(6);
        if ($reply === null || $reply['type'] !== 2) {
            $this->lastError = 'брокер не ответил на подключение';
            $this->closeSocket();
            return false;
        }
        $code = ord($reply['payload'][1] ?? "\xff");
        if ($code !== 0) {
            $names = [1 => 'версия протокола не та', 2 => 'идентификатор отклонён',
                      3 => 'служба недоступна', 4 => 'неверный логин или пароль', 5 => 'нет прав'];
            $this->lastError = 'брокер отказал: ' . ($names[$code] ?? ('код ' . $code));
            $this->closeSocket();
            return false;
        }
        $this->connected = true;
        $this->lastError = '';
        return true;
    }

    /** Подписка на список тем. */
    public function subscribe(array $topics, int $qos = 0): bool
    {
        if (!$this->connected || !$topics) { return false; }
        $this->packetId = ($this->packetId % 60000) + 1;
        $body = pack('n', $this->packetId);
        foreach ($topics as $t) {
            $t = trim((string)$t);
            if ($t === '') { continue; }
            $body .= $this->str($t) . chr($qos & 0x03);
        }
        if (!$this->send($this->packet(0x82, $body))) { return false; }
        $this->lastTx = time();
        $reply = $this->readPacket(5);
        return $reply !== null && $reply['type'] === 9;   // SUBACK
    }

    /** Отправка команды (QoS 0 — как и раньше у mosquitto_pub). */
    public function publish(string $topic, string $payload, int $retain = 0): bool
    {
        if (!$this->connected) { return false; }
        $body = $this->str($topic) . $payload;
        $head = 0x30 | ($retain ? 0x01 : 0x00);
        if (!$this->send($this->packet($head, $body))) { return false; }
        $this->lastTx = time();
        return true;
    }

    /**
     * Чтение входящих сообщений (ждёт до $timeoutSec секунд).
     * Возвращает список ['topic' => ..., 'payload' => ...]; пустой список — ничего не пришло.
     */
    public function poll(float $timeoutSec = 1.0): array
    {
        $out = [];
        if (!$this->connected) { return $out; }

        $read = [$this->sock]; $write = null; $except = null;
        $sec = (int)floor($timeoutSec);
        $usec = (int)round(($timeoutSec - $sec) * 1000000);
        $ready = @stream_select($read, $write, $except, $sec, $usec);
        if ($ready === false) {
            $this->lastError = 'соединение с брокером потеряно (stream_select)';
            $this->closeSocket();
            return $out;
        }
        if ($ready === 0) { return $out; }

        while (true) {
            $pkt = $this->readPacket(0.05, true);
            if ($pkt === null) { break; }
            if ($pkt['type'] === 3) {                        // PUBLISH
                $tlen = unpack('n', substr($pkt['payload'], 0, 2))[1];
                $topic = substr($pkt['payload'], 2, $tlen);
                $body = substr($pkt['payload'], 2 + $tlen);
                $out[] = ['topic' => $topic, 'payload' => $body];
            } elseif ($pkt['type'] === 0) {                  // разрыв со стороны брокера
                $this->closeSocket();
                break;
            }
        }
        return $out;
    }

    /** Поддержание соединения: раз в keepalive/2 отправляем «я жив». */
    public function keepAlive(): void
    {
        if (!$this->connected) { return; }
        if (time() - $this->lastTx >= (int)($this->keepalive / 2)) {
            $this->send($this->packet(0xC0, ''));
            $this->lastTx = time();
        }
    }

    public function disconnect(): void
    {
        if ($this->connected) {
            @fwrite($this->sock, $this->packet(0xE0, ''));
        }
        $this->closeSocket();
    }

    /* ------------------------------------------------------------ внутреннее */

    private function closeSocket(): void
    {
        if (is_resource($this->sock)) { @fclose($this->sock); }
        $this->sock = null;
        $this->connected = false;
        $this->rxbuf = '';
    }

    /** Строка MQTT: два байта длины + содержимое. */
    private function str(string $s): string { return pack('n', strlen($s)) . $s; }

    /** Собирает пакет: тип + длина (переменная) + содержимое. */
    private function packet(int $header, string $body): string
    {
        $len = strlen($body);
        $out = chr($header);
        do {
            $byte = $len % 128;
            $len = intdiv($len, 128);
            if ($len > 0) { $byte |= 0x80; }
            $out .= chr($byte);
        } while ($len > 0);
        return $out . $body;
    }

    private function send(string $bytes): bool
    {
        if (!is_resource($this->sock)) { return false; }
        $len = strlen($bytes);
        $sent = 0;
        $deadline = microtime(true) + 5;
        while ($sent < $len) {
            $n = @fwrite($this->sock, substr($bytes, $sent));
            if ($n === false || $n === 0) {
                if (microtime(true) > $deadline) {
                    $this->lastError = 'не удалось отправить в брокер';
                    $this->closeSocket();
                    return false;
                }
                usleep(20000);
                continue;
            }
            $sent += $n;
        }
        return true;
    }

    /** Дочитать ровно $need байт (ждёт до конца срока). */
    private function readBytes(int $need, float $timeout): ?string
    {
        $deadline = microtime(true) + $timeout;
        while (strlen($this->rxbuf) < $need) {
            if (!is_resource($this->sock)) { return null; }
            $left = $deadline - microtime(true);
            if ($left <= 0) { return null; }
            $r = [$this->sock]; $w = null; $e = null;
            $s = (int)floor($left); $u = (int)round(($left - $s) * 1000000);
            $ready = @stream_select($r, $w, $e, $s, $u);
            if ($ready === false) { $this->closeSocket(); return null; }
            if ($ready === 0) { continue; }
            $chunk = @fread($this->sock, 65536);
            if ($chunk === false) { $this->closeSocket(); return null; }
            if ($chunk === '') {
                if (feof($this->sock)) { $this->closeSocket(); return null; }
                usleep(10000);
                continue;
            }
            $this->rxbuf .= $chunk;
        }
        $out = substr($this->rxbuf, 0, $need);
        $this->rxbuf = substr($this->rxbuf, $need);
        return $out;
    }

    /** Читает один пакет. $soft = true — просто выходим, если не успели. */
    private function readPacket(float $timeout, bool $soft = false): ?array
    {
        $head = $this->readBytes(1, $timeout);
        if ($head === null) { return null; }
        $type = ord($head) >> 4;

        $mult = 1; $len = 0; $i = 0;
        do {
            $b = $this->readBytes(1, $timeout);
            if ($b === null) { return null; }
            $byte = ord($b);
            $len += ($byte & 0x7F) * $mult;
            $mult *= 128;
            $i++;
        } while (($byte & 0x80) !== 0 && $i < 4);

        $body = $len > 0 ? $this->readBytes($len, max($timeout, 0.2)) : '';
        if ($body === null) { return null; }
        return ['type' => $type, 'payload' => $body];
    }
}
