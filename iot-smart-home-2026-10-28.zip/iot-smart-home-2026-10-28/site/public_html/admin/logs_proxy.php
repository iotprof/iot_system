<?php
header('Content-Type: application/json');

// Создаем свой лог-файл, куда будем писать логи
$logFile = '/tmp/iot-automation.log';

// Если файла нет, создаем
if (!file_exists($logFile)) {
    file_put_contents($logFile, "=== Логи iot-automation ===\n");
}

// Получаем последние строки
$lines = (int)($_GET['lines'] ?? 100);
$filter = $_GET['filter'] ?? '';

$output = [];
if (file_exists($logFile)) {
    $content = file_get_contents($logFile);
    $allLines = explode("\n", $content);
    $output = array_slice($allLines, -$lines);
}

// Фильтр
if (!empty($filter) && $filter != 'null') {
    $output = array_filter($output, function($line) use ($filter) {
        return stripos($line, $filter) !== false;
    });
    $output = array_values($output);
}

// Если нет логов - показываем тестовые
if (empty($output)) {
    $output = [
        "📌 Логи будут появляться здесь",
        "📧 Пример: " . date('Y-m-d H:i:s') . " - Email отправлен",
        "🔄 Обновите страницу через 3 секунды"
    ];
}

echo json_encode([
    'logs' => $output,
    'count' => count($output),
    'timestamp' => date('Y-m-d H:i:s')
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
