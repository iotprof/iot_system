<?php
// Нет зависимостей, работает сразу

$services = [
    'iot-automation' => [
        'name' => 'IoT Automation',
        'service' => 'iot-automation.service'
    ],
    'mqtt-to-mysql' => [
        'name' => 'MQTT to MySQL',
        'service' => 'mqtt-to-mysql.service'
    ],
];

function getLogs($service, $minutes = 60, $lines = 1000) {
    $cmd = "sudo journalctl -u {$service} --since '{$minutes} minutes ago' --no-pager -n {$lines} 2>&1";
    $output = shell_exec($cmd);
    
    if ($output && strpos($output, 'No entries') === false && strpos($output, '-- No entries --') === false) {
        $lines = explode("\n", trim($output));
        return array_reverse($lines);
    }
    return [];
}

// API для AJAX
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json');
    
    $service = $_GET['service'] ?? 'iot-automation.service';
    $minutes = intval($_GET['minutes'] ?? 60);
    
    $logs = getLogs($service, $minutes);
    echo json_encode(['logs' => $logs, 'timestamp' => date('Y-m-d H:i:s')]);
    exit;
}

// Получаем статусы сервисов
function getServiceStatus() {
    $services_list = ['iot-automation.service', 'mqtt-to-mysql.service', 'zigbee2mqtt', 'mosquitto'];
    $statuses = [];
    
    foreach ($services_list as $service) {
        $cmd = "systemctl is-active {$service} 2>&1";
        $status = trim(shell_exec($cmd));
        $statuses[$service] = $status === 'active' ? '✅ active' : '❌ inactive';
    }
    return $statuses;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
 <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <meta name="theme-color" content="#0a0e12">
    <meta name="apple-mobile-web-app-capable" content="yes">
<!-- PWA Support -->
<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#0a0e12">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="IoT Home">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>Просмотр логов IoT Hub</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<div class="container">
<?php include  '/var/www/html/iot/public_html/include/links_panel.php';?>




<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-header">
        <span class="card-title">📋 Просмотр логов в реальном времени</span>
    </div>
    <div class="card-body">
        <div class="status-bar" id="statusBar" style="display: flex; flex-wrap: wrap; gap: 1rem; margin-bottom: 1rem;">
            <?php
            $statuses = getServiceStatus();
            foreach ($statuses as $service => $status):
            ?>
                <div class="badge <?= strpos($status, 'active') !== false ? 'badge-success' : 'badge-error' ?>">
                    <?= str_replace('.service', '', $service) ?>: <?= $status ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
    
<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-header">
        <span class="card-title">🎮 Управление</span>
    </div>
    <div class="card-body">
        <div style="display: flex; flex-wrap: wrap; gap: 0.75rem; align-items: center;">
            <select id="serviceSelect" class="form-control" style="width: auto; min-width: 180px;">
                <option value="iot-automation.service">🤖 IoT Automation</option>
                <option value="mqtt-to-mysql.service">💾 MQTT to MySQL</option>
            </select>
            
            <select id="timeSelect" class="form-control" style="width: auto;">
                <option value="5">5 минут</option>
                <option value="10">10 минут</option>
                <option value="30">30 минут</option>
                <option value="60" selected>1 час</option>
                <option value="120">2 часа</option>
                <option value="360">6 часов</option>
                <option value="720">12 часов</option>
                <option value="1440">24 часа</option>
            </select>
            
            <button id="refreshBtn" class="btn">🔄 Обновить</button>
            
            <label style="display: inline-flex; align-items: center; gap: 0.5rem;">
                <input type="checkbox" id="autoScroll" checked> Автопрокрутка
            </label>
            
            <label style="display: inline-flex; align-items: center; gap: 0.5rem;">
                <input type="checkbox" id="autoRefresh" checked> Автообновление (5 сек)
            </label>
            
            <input type="text" id="searchInput" class="form-control" placeholder="🔍 Поиск..." style="width: 200px;">
            
            <span class="badge badge-info" id="lineCount">📊 Строк: 0</span>
        </div>
    </div>
</div>
    

<div class="card">
    <div class="card-header">
        <span class="card-title">📄 Логи</span>
        <span class="badge badge-info" id="refreshIndicator">--:--:--</span>
    </div>
    <div class="card-body" style="padding: 0;">
        <div class="log-content" id="logContent" style="height: 500px; overflow-y: auto; background: var(--bg-main); padding: 0.75rem; font-family: monospace; font-size: 0.75rem;">
            <div class="log-line">Загрузка...</div>
        </div>
    </div>
</div>


</div>

<script>
    let autoRefresh = true;
    let autoScroll = true;
    let refreshInterval = null;
    let currentService = 'iot-automation.service';
    let currentMinutes = 60;
    let currentLogs = [];
    
    const logContent = document.getElementById('logContent');
    const serviceSelect = document.getElementById('serviceSelect');
    const timeSelect = document.getElementById('timeSelect');
    const refreshBtn = document.getElementById('refreshBtn');
    const autoScrollCheckbox = document.getElementById('autoScroll');
    const autoRefreshCheckbox = document.getElementById('autoRefresh');
    const searchInput = document.getElementById('searchInput');
    const refreshIndicator = document.getElementById('refreshIndicator');
    const lineCountSpan = document.getElementById('lineCount');
    
    function getLogType(line) {
        if (line.includes('ERROR') || line.includes('❌')) return 'error';
        if (line.includes('WARNING') || line.includes('⚠️')) return 'warning';
        if (line.includes('✅')) return 'success';
        return 'info';
    }
    
    function extractTimestamp(line) {
        const match = line.match(/(\d{2}:\d{2}:\d{2})/);
        return match ? match[1] : '';
    }
    
    function displayLogs(logs) {
        const searchTerm = searchInput.value.toLowerCase();
        let filtered = searchTerm ? logs.filter(l => l.toLowerCase().includes(searchTerm)) : logs;
        
        const wasAtBottom = autoScroll && 
            (logContent.scrollHeight - logContent.clientHeight <= logContent.scrollTop + 50);
        
        if (filtered.length === 0) {
            logContent.innerHTML = '<div class="log-line" style="color:#858585;">Нет логов</div>';
            lineCountSpan.textContent = '0';
            return;
        }
        
        logContent.innerHTML = filtered.map(line => {
            const type = getLogType(line);
            const time = extractTimestamp(line);
            const display = time ? line.replace(time, `<span class="timestamp">${time}</span>`) : `<span class="timestamp">--:--:--</span> ${line}`;
            return `<div class="log-line log-${type}">${display}</div>`;
        }).join('');
        
        lineCountSpan.textContent = filtered.length;
        
        if (wasAtBottom && autoScroll) {
            logContent.scrollTop = logContent.scrollHeight;
        }
    }
    
    async function loadLogs() {
        try {
            const url = `?ajax=1&service=${currentService}&minutes=${currentMinutes}&_=${Date.now()}`;
            const response = await fetch(url);
            const data = await response.json();
            
            if (data.logs) {
                currentLogs = data.logs;
                displayLogs(currentLogs);
                refreshIndicator.textContent = data.timestamp;
            }
        } catch (error) {
            logContent.innerHTML = `<div class="log-line log-error">Ошибка: ${error.message}</div>`;
        }
    }
    
    function setupAutoRefresh() {
        if (refreshInterval) clearInterval(refreshInterval);
        if (autoRefresh) refreshInterval = setInterval(loadLogs, 5000);
    }
    
    serviceSelect.onchange = () => {
        currentService = serviceSelect.value;
        loadLogs();
    };
    
    timeSelect.onchange = () => {
        currentMinutes = parseInt(timeSelect.value);
        loadLogs();
    };
    
    refreshBtn.onclick = () => loadLogs();
    autoScrollCheckbox.onchange = (e) => autoScroll = e.target.checked;
    autoRefreshCheckbox.onchange = (e) => {
        autoRefresh = e.target.checked;
        setupAutoRefresh();
        if (autoRefresh) loadLogs();
    };
    searchInput.oninput = () => displayLogs(currentLogs);
    
    setupAutoRefresh();
    loadLogs();
</script>
</body>
</html>
