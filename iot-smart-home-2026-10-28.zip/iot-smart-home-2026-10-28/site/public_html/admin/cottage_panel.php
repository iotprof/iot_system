<?php
// Пафосная панель управления коттеджем
// Версия 1.0 - демо-версия с красивыми карточками

// Здесь потом будет подключение к БД для реальных данных
// $pdo = new PDO(...);

// Демо-данные (потом замените на реальные из БД)
$demo_data = [
    'solar_power' => 8.7,
    'consumption' => 6.8,
    'solar_percent' => 74,
    'heat_pump_percent' => 26,
    'ta_temp' => 79,
    'ta_top' => 83,
    'ta_bottom' => 60,
    'ta_charge' => 89,
    'outside_temp' => -2,
    'wind' => 5,
    'insolation' => 810,
    'people_count' => 3,
    'co2_living' => 480,
];

// Zigbee батарейки (демо)
$zigbee_batteries = [
    ['device' => 'Датчик движения (гостиная)', 'voltage' => 2.95, 'percent' => 85, 'status' => 'ok'],
    ['device' => 'Дверной датчик (вход)', 'voltage' => 2.82, 'percent' => 45, 'status' => 'warning'],
    ['device' => 'Температура (кухня)', 'voltage' => 3.02, 'percent' => 92, 'status' => 'ok'],
    ['device' => 'Датчик протечки (баня)', 'voltage' => 2.65, 'percent' => 18, 'status' => 'critical'],
    ['device' => 'Кнопка (спальня)', 'voltage' => 2.91, 'percent' => 72, 'status' => 'ok'],
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <meta name="theme-color" content="#0a0e12">
<!-- PWA Support -->
<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#0a0e12">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="IoT Home">
    <title>🏡 Гибридный коттедж · Умный дом</title>
    <link rel="stylesheet" href="/css/style.css">
    <style>
        /* Дополнительные стили для коттеджной панели */
        .power-balance {
            display: flex;
            flex-wrap: wrap;
            gap: 1.5rem;
            align-items: center;
            justify-content: space-between;
        }
        .balance-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            background: linear-gradient(135deg, var(--bg-card-secondary), var(--bg-card));
            padding: 1rem 1.5rem;
            border-radius: 2rem;
            flex: 1;
            min-width: 150px;
        }
        .balance-icon {
            font-size: 2rem;
        }
        .balance-info h3 {
            font-size: 0.8rem;
            margin: 0;
            color: var(--text-muted);
        }
        .balance-info .value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--accent);
        }
        .badge-source {
            background: var(--bg-card-secondary);
            padding: 0.5rem 1rem;
            border-radius: 2rem;
            font-size: 0.85rem;
        }
        .room-sensor {
            background: var(--bg-card-secondary);
            border-radius: 1.25rem;
            padding: 1rem;
            margin-bottom: 0.75rem;
        }
        .room-name {
            font-weight: 600;
            margin-bottom: 0.5rem;
            font-size: 1rem;
        }
        .sensor-detail {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            font-size: 0.85rem;
            color: var(--text-secondary);
        }
        .floor-temp {
            color: #ffa726;
        }
        .security-bar {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px solid var(--border);
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        .pump-indicator {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            align-items: center;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        .pump-name {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .pump-led {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
        }
        .pump-led.active {
            background: #2dc96e;
            box-shadow: 0 0 5px #2dc96e;
        }
        .pump-led.off {
            background: #555;
        }
        .progress-bar-bg {
            background: var(--bg-input);
            border-radius: 1rem;
            height: 8px;
            overflow: hidden;
            margin: 0.5rem 0;
        }
        .progress-fill {
            background: linear-gradient(90deg, var(--accent), #2dc96e);
            height: 100%;
            border-radius: 1rem;
            width: 0%;
        }
        .progress-fill.warm {
            background: linear-gradient(90deg, #ffa726, #ff6b35);
        }
        .progress-fill.solar {
            background: linear-gradient(90deg, #ffd93d, #ffb347);
        }
        .metric-row {
            display: flex;
            justify-content: space-between;
            padding: 0.25rem 0;
            font-size: 0.85rem;
        }
        .status-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 0.5rem 0;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        .live-badge {
            background: #ff4444;
            color: white;
            padding: 0.2rem 0.6rem;
            border-radius: 1rem;
            font-size: 0.7rem;
            font-weight: 600;
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.6; }
        }
        .weather-mini {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            font-size: 0.85rem;
        }
        .battery-table {
            width: 100%;
            font-size: 0.85rem;
        }
        .battery-table td {
            padding: 0.5rem 0;
            border-bottom: 1px solid var(--border);
        }
        .battery-bar {
            width: 60px;
            height: 6px;
            background: var(--bg-input);
            border-radius: 3px;
            overflow: hidden;
            display: inline-block;
            margin-left: 0.5rem;
        }
        .battery-fill {
            height: 100%;
            border-radius: 3px;
        }
        .battery-fill.ok { background: #2dc96e; }
        .battery-fill.warning { background: #ffa726; }
        .battery-fill.critical { background: #ff4444; }
        
        /* Аквариумные стили */
        .aqua-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }
        .aqua-item {
            background: var(--bg-card-secondary);
            border-radius: 1.25rem;
            padding: 1rem;
        }
        .aq-title {
            font-weight: 700;
            margin-bottom: 0.75rem;
            font-size: 1rem;
        }
        .aq-row {
            display: flex;
            justify-content: space-between;
            padding: 0.4rem 0;
            border-bottom: 1px solid var(--border-light);
            font-size: 0.8rem;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        .led-indicator {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 0.3rem;
        }
        .led-green { background: #2dc96e; box-shadow: 0 0 3px #2dc96e; }
        .led-yellow { background: #ffa726; }
        .led-blue { background: #3b9eff; }
        .led-off { background: #555; }
        .badge-aq {
            padding: 0.2rem 0.5rem;
            border-radius: 1rem;
            font-size: 0.7rem;
        }
        .badge-aq.ok { background: rgba(45, 201, 110, 0.2); color: #2dc96e; }
        .badge-aq.warn { background: rgba(255, 167, 38, 0.2); color: #ffa726; }
        
        /* Адаптив для grid */
        .grid-cottage {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 1.25rem;
        }
        @media (max-width: 768px) {
            .grid-cottage {
                grid-template-columns: 1fr;
            }
            .balance-item {
                min-width: 100%;
            }
            .power-balance {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <?php include '/var/www/html/iot/public_html/include/links_panel.php';?>

    <!-- Шапка -->
    <div class="header-energy" >
        <div class="title-section">
            <h1 style="margin: 0 0 0.5rem 0;">🏡 Гибридный коттедж · Active</h1>
            <p style="margin: 0 0 0.5rem 0;"><span class="live-badge">⚡ LIVE</span> Солнце + ТА + тепловой насос · <?= date('d.m.Y') ?> · Режим: "Я дома"</p>
            <div class="weather-mini">
                <span>🌡️ <?= $demo_data['outside_temp'] ?>°C на улице</span>
                <span>💨 <?= $demo_data['wind'] ?> м/с</span>
                <span>☀️ инсоляция <?= $demo_data['insolation'] ?> Вт/м²</span>
                <span>🧍‍♂️ людей в доме: <?= $demo_data['people_count'] ?></span>
            </div>
        </div>
        <div class="power-balance" style="margin-top: 1.5rem;">
            <div class="balance-item">
                <span class="balance-icon">🔋</span>
                <div class="balance-info">
                    <h3>Сейчас генерация</h3>
                    <span class="value"><?= $demo_data['solar_power'] ?></span><span class="unit"> кВт</span>
                </div>
            </div>
            <div class="balance-item">
                <span class="balance-icon">⚡</span>
                <div class="balance-info">
                    <h3>Потребление</h3>
                    <span class="value"><?= $demo_data['consumption'] ?></span><span class="unit"> кВт</span>
                </div>
            </div>
            <div class="badge-source">
                ☀️ Солнце <?= $demo_data['solar_percent'] ?>% · 🔥 Котёл 0% · 🌊 ТН <?= $demo_data['heat_pump_percent'] ?>%
            </div>
        </div>
    </div>

    <!-- Сетка блоков -->
    <div class="grid-cottage">

        <!-- Комнаты и климат -->
        <div class="card">
            <div class="card-header">
                <span class="card-icon">🏠</span>
                <span class="card-title">Комнаты · климат + полы</span>
            </div>
            <div class="card-body">
                <div class="room-sensor">
                    <div class="room-name">🛋️ Гостиная (1 этаж)</div>
                    <div class="sensor-detail">
                        <span>🌡️ 23.5°C</span>
                        <span>💧 44%</span>
                        <span class="floor-temp">🔥 пол 26°C</span>
                    </div>
                    <div style="margin-top: 6px;">👣 движение: 2 мин назад</div>
                </div>
                <div class="room-sensor">
                    <div class="room-name">🍳 Кухня</div>
                    <div class="sensor-detail">
                        <span>🌡️ 24.1°C</span>
                        <span>💧 48%</span>
                        <span class="floor-temp">🔥 пол 27°C</span>
                    </div>
                    <div style="display: flex; gap: 15px; margin-top: 5px; flex-wrap: wrap;">
                        <span>🔥 утечка газа: <span style="color:#8cf0b5;">нет</span></span>
                        <span>💨 CO: <span style="color:#8cf0b5;">0 ppm</span></span>
                        <span>👃 движ: сейчас</span>
                    </div>
                </div>
                <div class="room-sensor">
                    <div class="room-name">🛏️ Спальня</div>
                    <div class="sensor-detail">
                        <span>🌡️ 22.0°C</span>
                        <span>💧 41%</span>
                        <span class="floor-temp">🔥 пол 24°C</span>
                    </div>
                    <span>👤 присутствие: нет (с 9:00)</span>
                </div>
                <div class="room-sensor">
                    <div class="room-name">🛁 Санузел (гостевой)</div>
                    <div class="sensor-detail">
                        <span>🌡️ 25.3°C</span>
                        <span>💧 62%</span>
                        <span class="floor-temp">🔥 пол 29°C</span>
                    </div>
                </div>
                <div class="room-sensor">
                    <div class="room-name">🏋️ Спортзал (цоколь)</div>
                    <div class="sensor-detail">
                        <span>🌡️ 21.5°C</span>
                        <span>💧 38%</span>
                        <span class="floor-temp">🔥 пол 22°C</span>
                    </div>
                </div>
                <div style="margin-top: 0.75rem; background: rgba(59,158,255,0.1); border-radius: 1.25rem; padding: 0.5rem 0.75rem;">
                    <span>🔹 средняя T дома: 23.2°C · задано 23°C</span>
                </div>
            </div>
        </div>

        <!-- Банный комплекс -->
        <div class="card">
            <div class="card-header">
                <span class="card-icon">🧖‍♂️💧</span>
                <span class="card-title">Банный комплекс</span>
            </div>
            <div class="card-body">
                <div class="room-sensor" style="background: rgba(255,107,53,0.15);">
                    <div class="room-name">🔥 Парилка (сухая)</div>
                    <div class="sensor-detail">
                        <span>🌡️ 78°C</span>
                        <span>💧 22%</span>
                    </div>
                    <div>каменка: 4.5 кВт (нагрев)</div>
                </div>
                <div class="room-sensor">
                    <div class="room-name">💧 Купель (уличная)</div>
                    <div class="sensor-detail">
                        <span>💧 вода 28°C</span>
                        <span>🌡️ крышка: закрыта</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; flex-wrap: wrap;">
                        <span>автоналив: 💧 уровень 95%</span>
                        <span class="badge" style="background: rgba(255,107,53,0.2); color: #ff6b35;">подогрев 1.2 кВт</span>
                    </div>
                    <div style="margin-top: 6px;">⏱️ фильтрация: включена</div>
                </div>
                <div class="room-sensor">
                    <div class="room-name">🧼 Помывочная/душ</div>
                    <div class="sensor-detail">
                        <span>🌡️ 26°C</span>
                        <span>💧 70%</span>
                    </div>
                    <span>пол с подогревом 31°C</span>
                </div>
                <div style="margin-top: 0.75rem;">🛁 купель: нагрев от ТА + солнце. Ожидание гостей.</div>
            </div>
        </div>

        <!-- Охрана и безопасность -->
        <div class="card">
            <div class="card-header">
                <span class="card-icon">🔒</span>
                <span class="card-title">Охрана и безопасность</span>
            </div>
            <div class="card-body">
                <div class="security-bar">
                    <span>🚶‍♂️ Датчики движения:</span>
                    <span>гостиная 🟢 кухня 🟢 спальня ⚫</span>
                </div>
                <div class="security-bar">
                    <span>🚧 Периметр (барьер лучи):</span>
                    <span class="badge" style="background: rgba(255,68,68,0.2); color: #ff4444;">деактивировано (я дома)</span>
                </div>
                <div class="security-bar">
                    <span>📡 Ворота/калитки:</span>
                    <span>закрыты</span>
                </div>
                <div style="display: flex; gap: 0.5rem; flex-wrap: wrap; margin: 0.5rem 0;">
                    <span class="badge" style="background: var(--bg-card-secondary);">🚪 вход: закрыта</span>
                    <span class="badge" style="background: var(--bg-card-secondary);">🚪 терраса: закрыта</span>
                </div>
                <div class="pump-indicator">
                    <span class="pump-name"><span class="pump-led active"></span> Видеокамеры (4 шт)</span>
                    <span>онлайн</span>
                </div>
                <div class="pump-indicator">
                    <span class="pump-name"><span class="pump-led active"></span> Датчики дыма</span>
                    <span>чисто</span>
                </div>
                <div class="pump-indicator">
                    <span class="pump-name"><span class="pump-led active"></span> Датчик утечки газа (кухня)</span>
                    <span>0% LEL</span>
                </div>
                <div style="margin-top: 1rem;">
                    <span>🧍‍♂️🧍‍♀️ Людей в доме: <strong style="font-size: 1.5rem;"><?= $demo_data['people_count'] ?></strong> (гостиная 2, кухня 1)</span>
                </div>
            </div>
        </div>

        <!-- Вентиляция -->
        <div class="card">
            <div class="card-header">
                <span class="card-icon">🌬️</span>
                <span class="card-title">Вентиляция</span>
            </div>
            <div class="card-body">
                <div class="pump-indicator">
                    <span class="pump-name"><span class="pump-led active"></span> Рекуператор (крыша)</span>
                    <span>210 м³/ч</span>
                </div>
                <div class="metric-row"><span>Эфф. 86%</span><span> incoming +4°C</span></div>
                <div class="pump-indicator">
                    <span class="pump-name"><span class="pump-led active"></span> Грунтовый ТО (земля)</span>
                    <span>320 м³/ч</span>
                </div>
                <div class="metric-row"><span>Темп. после грунта</span><span>+8°C</span></div>
                <div class="pump-indicator">
                    <span class="pump-name"><span class="pump-led off"></span> Вытяжка кухня</span>
                    <span>off</span>
                </div>
                <div class="pump-indicator">
                    <span class="pump-name"><span class="pump-led active"></span> Приток спальни</span>
                    <span>45 м³/ч</span>
                </div>
                <div style="margin-top: 0.75rem; background: rgba(59,158,255,0.1); border-radius: 1.25rem; padding: 0.5rem 0.75rem;">CO₂ в гостиной: <?= $demo_data['co2_living'] ?> ppm</div>
            </div>
        </div>

        <!-- Теплоаккумулятор -->
        <div class="card">
            <div class="card-header">
                <span class="card-icon">🧊🔥</span>
                <span class="card-title">Теплоаккумулятор 2000 л</span>
            </div>
            <div class="card-body">
                <div class="status-row">
                    <span>🌡️ Текущая температура</span>
                    <span class="badge" style="background: #5a4b2c; color: #ffe6a3;">+<?= $demo_data['ta_temp'] ?>°C / <?= $demo_data['ta_top'] ?>°C</span>
                </div>
                <div class="progress-bar-bg"><div class="progress-fill warm" style="width: <?= $demo_data['ta_charge'] ?>%;"></div></div>
                <div class="metric-row"><span>Верх/низ</span><span><?= $demo_data['ta_top'] ?>° / <?= $demo_data['ta_bottom'] ?>°</span></div>
                <div style="display: flex; justify-content: space-between; margin: 1rem 0 0.5rem;">
                    <span>⚡ ТЭНы (электро)</span>
                    <span class="bolder">3 кВт · греют</span>
                </div>
                <div class="pump-indicator"><span class="pump-name"><span class="pump-led active"></span> ТЭН-1 (верх)</span><span>2.0 кВт</span></div>
                <div class="pump-indicator"><span class="pump-name"><span class="pump-led active"></span> ТЭН-2 (низ)</span><span>1.0 кВт</span></div>
                <div class="metric-row" style="margin-top: 0.75rem; background: rgba(45,201,110,0.1); border-radius: 1rem; padding: 0.5rem;">🔄 Зарядка: трубки + ТН + тэны (избыток)</div>
            </div>
        </div>

        <!-- Zigbee батарейки -->
        <div class="card">
            <div class="card-header">
                <span class="card-icon">🔋</span>
                <span class="card-title">Zigbee устройства · батарейки</span>
            </div>
            <div class="card-body">
                <table class="battery-table">
                    <?php foreach ($zigbee_batteries as $zb): ?>
                    <tr>
                        <td><?= $zb['device'] ?></td>
                        <td style="text-align: right;">
                            <?= $zb['voltage'] ?>V
                            <div class="battery-bar">
                                <div class="battery-fill <?= $zb['status'] ?>" style="width: <?= $zb['percent'] ?>%;"></div>
                            </div>
                            <?= $zb['percent'] ?>%
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </table>
                <?php 
                $critical_batteries = array_filter($zigbee_batteries, fn($b) => $b['status'] === 'critical');
                if (!empty($critical_batteries)): ?>
                <div style="margin-top: 0.75rem; background: rgba(255,68,68,0.15); border-radius: 1rem; padding: 0.5rem; color: #ff8888;">
                    ⚠️ Внимание: у <?= count($critical_batteries) ?> устройств критический уровень заряда!
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Аквариумный комплекс -->
        <div class="card">
            <div class="card-header">
                <span class="card-icon">🐟</span>
                <span class="card-title">Аквариумный комплекс</span>
            </div>
            <div class="card-body">
                <div class="aqua-grid" style="grid-template-columns: 1fr;">
                    <div class="aqua-item" style="background: rgba(59,158,255,0.1);">
                        <div class="aq-title">🌿 Аквариум 1 (пресный, 350л)</div>
                        <div class="aq-row"><span>🌡️ Температура</span><span><span class="led-indicator led-green"></span> 25.3°C / 24.8°C</span></div>
                        <div class="aq-row"><span>🧪 pH</span><span>7.2 <span class="badge-aq ok">норма</span></span></div>
                        <div class="aq-row"><span>🌀 Фильтр</span><span><span class="led-indicator led-green"></span> 980 л/ч</span></div>
                        <div class="aq-row"><span>💡 Свет</span><span>🌙 ночной режим</span></div>
                        <div class="aq-row"><span>📦 Уровень корма</span><span>43% <span class="badge-aq warn">скоро кончится</span></span></div>
                    </div>
                    <div class="aqua-item" style="background: rgba(45,201,110,0.05);">
                        <div class="aq-title">🌊 Аквариум 2 (морской, 200л)</div>
                        <div class="aq-row"><span>🌡️ Температура</span><span><span class="led-indicator led-green"></span> 26.1°C</span></div>
                        <div class="aq-row"><span>🧪 pH</span><span>8.3 <span class="badge-aq ok">ok</span></span></div>
                        <div class="aq-row"><span>🌀 Фильтр</span><span><span class="led-indicator led-green"></span> 650 л/ч</span></div>
                        <div class="aq-row"><span>💡 Свет</span><span>🌞 70% интенс.</span></div>
                        <div class="aq-row"><span>🚰 Клапан RO/подпитка</span><span><span class="led-indicator led-blue"></span> открыт (долив)</span></div>
                    </div>
                </div>
                <div style="margin-top: 0.75rem; font-style: italic; color: var(--text-muted); text-align: right;">
                    🐠 рыбы просят не жрать их корм, он и так тает
                </div>


                <!-- Пруд на участке (бонус) -->
                <div style="margin-top: 1rem; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 1rem;">
                    <div class="room-name" style="margin-bottom: 8px;">🏞️ Декоративный пруд (120 м³)</div>
                    <div class="sensor-detail">
                        <span>💧 вода: 19.2°C</span>
                        <span>🧪 pH: 7.8</span>
                        <span>🌡️ воздух у пруда: 21°C</span>
                    </div>
                    <div style="display: flex; gap: 15px; margin-top: 8px; flex-wrap: wrap;">
                        <span>🐟 карпы кои: активны</span>
                        <span>🌀 насос фильтра: 3200 л/ч</span>
                        <span class="badge" style="background: rgba(59,158,255,0.2);">УФ-лампа: вкл</span>
                        <span>❄️ подогрев: выкл (летний режим)</span>
                    </div>
                    <div style="margin-top: 6px;">
                        <span>⚠️ </span>
                        <span style="color: #ffaa44;">уровень воды: -12 см (открыть автодолив)</span>
                    </div>
                </div>


            </div>
        </div>






        <!-- Теплицы и гидропоника -->
        <div class="card">
            <div class="card-header">
                <span class="card-icon">🌱🌞</span>
                <span class="card-title">Тепличный комплекс · гидропоника</span>
            </div>
            <div class="card-body">
                <!-- Основная теплица -->
                <div class="room-sensor" style="margin-bottom: 1rem;">
                    <div class="room-name">🏡 Теплица грунтовая (120 м²)</div>
                    <div class="sensor-detail">
                        <span>🌡️ 19.8°C</span>
                        <span>💧 68%</span>
                        <span>📦 CO₂: 420 ppm</span>
                    </div>
                    <div style="display: flex; gap: 15px; margin-top: 5px; flex-wrap: wrap;">
                        <span>🌱 грунт: +16°C</span>
                        <span>💧 влажн. почвы: 54%</span>
                        <span class="badge" style="background: rgba(59,158,255,0.2);">аккумулятор грунта: 12°C</span>
                    </div>
                    <div style="margin-top: 6px;">
                        <span>🪟 форточки: </span>
                        <span class="badge" style="background: rgba(45,201,110,0.2); color: #8cf0b5;">открыты 34%</span>
                        <span style="margin-left: 12px;">🌀 вентиляция: 280 м³/ч</span>
                        <span style="margin-left: 12px;">🌬️ циркуляция: 3 вентилятора</span>
                    </div>
                </div>

                <!-- Гидропонная система -->
                <div class="room-sensor" style="background: rgba(59,158,255,0.08); margin-bottom: 1rem;">
                    <div class="room-name">💧 Гидропоника (NFT · 48 растений)</div>
                    <div class="sensor-detail">
                        <span>🌡️ раствор: 22.4°C</span>
                        <span>🧪 pH: 6.2</span>
                        <span>⚡ EC: 1.8 mS/cm</span>
                    </div>
                    <div style="display: flex; gap: 15px; margin-top: 5px; flex-wrap: wrap;">
                        <span>💧 уровень в баке: 67%</span>
                        <span>⏱️ полив: 15 мин / 2 часа</span>
                        <span>🧴 дозатор A+B: ✅ активен</span>
                    </div>
                    <div style="margin-top: 6px;">
                        <span>⚠️ </span>
                        <span style="color: #ffaa44;">резерв удобрений: 23% (заказать)</span>
                        <span style="margin-left: 12px;">🔧 pH +0.1 (стабилизация)</span>
                    </div>
                </div>

                <!-- Освещение -->
                <div class="room-sensor" style="margin-bottom: 1rem;">
                    <div class="room-name">💡 Фитопрожекторы (LED 480W)</div>
                    <div class="sensor-detail">
                        <span>☀️ PAR: 620 µmol/m²/s</span>
                        <span>💡 люкс: 28,000 lx</span>
                        <span>⏰ фотопериод: 14 ч</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; flex-wrap: wrap;">
                        <span>спектр: 🌱 вегетация 60% / 🌸 цветение 40%</span>
                        <span class="badge" style="background: rgba(255,107,53,0.3); color: #ffaa66;">высота 45 см от верхушек</span>
                    </div>
                    <?php 
                    // Имитация предупреждения по свету для демо
                    $light_warning = true;
                    if ($light_warning): ?>
                    <div style="margin-top: 8px; background: rgba(255,170,68,0.15); border-radius: 1rem; padding: 0.5rem; color: #ffaa66;">
                        ⚠️ Нижний ярус: 190 µmol/m²/s — недостаточно для плодоношения. Рекомендуется досветка или поднятие растений.
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Датчики и емкости -->
                <div class="pump-indicator">
                    <span class="pump-name"><span class="pump-led active"></span> CO₂ генератор (горелка)</span>
                    <span>нагрев до 450 ppm</span>
                </div>
                <div class="pump-indicator">
                    <span class="pump-name"><span class="pump-led active"></span> Накопительный бак (дождевая)</span>
                    <span>2100 л / 3200 л (66%)</span>
                </div>
                <div class="pump-indicator">
                    <span class="pump-name"><span class="pump-led off"></span> УФ-стерилизатор воды</span>
                    <span>off (по графику)</span>
                </div>

                <div style="margin-top: 0.75rem; background: rgba(45,201,110,0.08); border-radius: 1.25rem; padding: 0.5rem 0.75rem;">
                    <span>🌡️ Прогноз: ночью +2°C → включить тепловую пушку + грунтовый аккумулятор</span>
                </div>

                <!-- Доп. предупреждение по pH -->
                <div style="margin-top: 0.75rem; background: rgba(255,68,68,0.1); border-radius: 1rem; padding: 0.5rem; color: #ff8888;">
                    🧪 Внимание: pH в гидропонике (6.2) смещается вниз — проверьте буферный раствор.
                </div>
            </div>
        </div>








    </div>

    <!-- Нижняя панель статуса -->
    <div style="display: flex; gap: 1rem; margin-top: 1.5rem; background: var(--bg-panel); border-radius: 2rem; padding: 1rem; flex-wrap: wrap; justify-content: space-between;">
        <span>🔘 ТЭН ТА: активен (солнечный избыток)</span>
        <span>⚙️ насос скважины: 0A</span>
        <span>🧪 давление ТА: 1.8 бар</span>
        <span>💧 купель: автодолив отстоянной водой</span>
        <span>👥 людей сегодня: макс 5</span>
    </div>

</div>

</body>
</html>
