<?php
$topic = $_GET['topic'] ?? '';
$payload = $_GET['payload'] ?? '{"command":"toggle"}';

if (!$topic || !$payload) {
    die('Не хватает параметров');
}

// Проверка: если топик содержит %, то ошибка
if (strpos($topic, '%') !== false) {
    die('Ошибка: неверная кодировка топика');
}

exec("mosquitto_pub -h localhost -t '$topic' -m '$payload'", $output, $return_code);

if ($return_code === 0) {
    echo "Отправлено в $topic: $payload";
} else {
    echo "Ошибка отправки";
}
?>
