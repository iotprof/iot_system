<?php
require_once '/var/www/html/iot/config/iot_config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

if (!isset($_SESSION['iot_admin'])) {
    header('Location: /admin/sensors.php');
    exit;
}

try {
    $pdo = iot_pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Ошибка подключения: " . $e->getMessage());
}

// Добавляем колонки для email если их нет
try {
    $pdo->exec("ALTER TABLE automations ADD COLUMN push_notify TINYINT(1) DEFAULT 0 AFTER email_condition_duration");
} catch (PDOException $e) {}
try {
    $pdo->exec("ALTER TABLE automations ADD COLUMN push_topic VARCHAR(255) NULL AFTER push_notify");
} catch (PDOException $e) {}
try {
    $pdo->exec("ALTER TABLE automations ADD COLUMN push_priority ENUM('low', 'high', 'urgent') DEFAULT 'high' AFTER push_topic");
} catch (PDOException $e) {}
try {
    $pdo->exec("ALTER TABLE automations ADD COLUMN last_triggered TIMESTAMP NULL AFTER cooldown_seconds");
} catch (PDOException $e) {}
try {
    $pdo->exec("ALTER TABLE automations ADD COLUMN email_notify TINYINT(1) DEFAULT 0 AFTER persistent");
} catch (PDOException $e) {}
try {
    $pdo->exec("ALTER TABLE automations ADD COLUMN email_recipient VARCHAR(255) NULL AFTER email_notify");
} catch (PDOException $e) {}
try {
    $pdo->exec("ALTER TABLE automations ADD COLUMN email_condition_duration INT DEFAULT 0 AFTER email_recipient");
} catch (PDOException $e) {}

$error = '';
$success = '';

// ========== БЕЗОПАСНЫЙ ИНТЕРПРЕТАТОР СКРИПТОВ ==========
function evaluateScriptCondition($script, $sensorData) {
    $script = preg_replace('/\bsensor\.([a-zA-Z0-9_]+)\b/', '$sensorData[\'$1\']', $script);
    $script = preg_replace('/\bsensor\[([\'"])([a-zA-Z0-9_]+)\1\]/', '$sensorData[\'$2\']', $script);
    $script = str_replace('data', '$data', $script);

    if (!preg_match('/^[a-zA-Z0-9_\[\]\.\(\)\+\-\*\/\!\&\|\s\=\>\<\,\{\}\'\"]+$/', $script)) {
        throw new Exception("Недопустимые символы в выражении");
    }

    $forbidden = ['eval', 'exec', 'system', 'shell_exec', 'passthru', 'assert', 'include', 'require'];
    foreach ($forbidden as $word) {
        if (stripos($script, $word) !== false) {
            throw new Exception("Запрещённая функция: " . $word);
        }
    }

    $tmpFile = sys_get_temp_dir() . '/eval_' . uniqid() . '.php';
    file_put_contents($tmpFile, "<?php return (" . $script . ");");

    $result = null;
    try {
        $result = include $tmpFile;
    } catch (Exception $e) {
        unlink($tmpFile);
        throw new Exception("Ошибка в выражении: " . $e->getMessage());
    }
    unlink($tmpFile);

    return (bool)$result;
}

// ============================================
// ОБРАБОТКА POST ЗАПРОСА
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    $id = $_POST['id'] ?? null;
    $name = trim($_POST['name'] ?? '');
    $rule_group = trim($_POST['group_name'] ?? '');   // группа правила (28.10.2026)
    $condition_type = $_POST['condition_type'] ?? 'simple';
    $trigger_topic = trim($_POST['trigger_topic'] ?? '');
    $action_topic = trim($_POST['action_topic'] ?? '');
    $action_payload = trim($_POST['action_payload'] ?? '');
    
    $email_notify = isset($_POST['email_notify']) ? 1 : 0;
    $email_recipient = trim($_POST['email_recipient'] ?? '');
    $email_condition_duration = (int)($_POST['email_condition_duration'] ?? 0);
    
    $condition_script = null;
    $condition_operator = null;
    $condition_value = null;
    $delay_seconds = (int)($_POST['delay_seconds'] ?? 0);
    $schedule_type = $_POST['schedule_type'] ?? 'none';
    $push_notify = isset($_POST['push_notify']) ? 1 : 0;
    $push_topic = trim($_POST['push_topic'] ?? 'iot-alerts');
    $push_priority = $_POST['push_priority'] ?? 'high';
    
    $schedule_time = trim($_POST['schedule_time'] ?? '');
    if (!empty($schedule_time)) {
        if (preg_match('/^([01][0-9]|2[0-3]):([0-5][0-9])$/', $schedule_time)) {
            $schedule_time .= ':00';
        } elseif (!preg_match('/^([01][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$/', $schedule_time)) {
            $schedule_time = '00:00:00';
        }
    } else {
        $schedule_time = '00:00:00';
    }

    $schedule_days = isset($_POST['schedule_days']) ? implode(',', $_POST['schedule_days']) : null;
    $condition_duration = (int)($_POST['condition_duration'] ?? 0);
    $enabled = isset($_POST['enabled']) ? 1 : 0;
    $persistent = isset($_POST['persistent']) ? 1 : 0;
    
    $time_restriction_start = !empty($_POST['time_restriction_start']) ? $_POST['time_restriction_start'] : null;
    $time_restriction_end = !empty($_POST['time_restriction_end']) ? $_POST['time_restriction_end'] : null;
    
    if ($email_notify && !filter_var($email_recipient, FILTER_VALIDATE_EMAIL)) {
        $error = "Неверный формат email адреса";
    }

    if ($schedule_type === 'none') {
        if ($condition_type === 'simple') {
            $condition_operator = $_POST['condition_operator'] ?? '==';
            // ИСПРАВЛЕНО 29.09.2026: форма (или старая версия правила) может прислать оператор
            // в «человеческом» порядке (=> , =<) или одиночное «=». Колонка condition_operator —
            // ENUM, такое значение в неё не влезает, и MariaDB отвечала
            // «Data truncated for column 'condition_operator'» — правило не сохранялось вообще.
            // Теперь оператор приводится к каноническому виду и проверяется по белому списку.
            // В >= и <= сама колонка ENUM расширена 29.09.2026.
            $opMap = ['=<' => '<=', '=>' => '>=', '=' => '==', '<>' => '!=', '>' => '>', '<' => '<',
                      '==' => '==', '!=' => '!=', '>=' => '>=', '<=' => '<='];
            if (isset($opMap[$condition_operator])) {
                $condition_operator = $opMap[$condition_operator];
            }
            $condition_value = trim($_POST['condition_value'] ?? '');
            if (!$condition_operator || $condition_value === '' || $condition_value === null) {
                $error = "Для простого условия нужно указать оператор и значение";
            } elseif (!in_array($condition_operator, ['>', '<', '==', '!=', '>=', '<='], true)) {
                $error = "Недопустимый оператор условия: " . $condition_operator;
            }
        } else {
            $condition_script = trim($_POST['condition_script'] ?? '');
            $condition_operator = null;
            $condition_value = null;
            if ($condition_script === '') {
                $error = "Для скриптового условия нужно ввести выражение";
            }
        }
    } else {
        $condition_operator = null;
        $condition_value = null;
        $condition_script = null;
    }

    $hasMqttAction = !empty($action_topic) && !empty($action_payload);
    $hasEmailAction = ($email_notify == 1 && !empty($email_recipient));

    if (!$name) {
        $error = "Название правила обязательно.";
    } elseif (!$trigger_topic && $schedule_type === 'none') {
        $error = "Для триггерного правила нужно указать топик условия.";
    } elseif (!$hasMqttAction && !$hasEmailAction) {
        $error = "Нужно указать хотя бы одно действие: MQTT команду или Email уведомление.";
    } elseif ($error === '') {
        try {
            if ($id && $id !== '') {
                $stmt = $pdo->prepare("
                    UPDATE automations SET
                        name = ?, group_name = ?, trigger_topic = ?, condition_type = ?, condition_operator = ?,
                        condition_value = ?, condition_script = ?, condition_duration = ?,
                        action_topic = ?, action_payload = ?, confirmation_topic = ?,
                        confirmation_timeout = ?, max_retries = ?, retry_delay = ?,
                        delay_seconds = ?, cooldown_seconds = ?, schedule_type = ?,
                        schedule_time = ?, schedule_days = ?, time_restriction_start = ?,
                        time_restriction_end = ?, dependency_topic = ?, dependency_value = ?,
                        enabled = ?, persistent = ?, email_notify = ?, email_recipient = ?,
                        email_condition_duration = ?, push_notify = ?, push_topic = ?,
                        push_priority = ?
                    WHERE id = ?
                ");
                $stmt->execute([
                    $name, $rule_group, $trigger_topic, $condition_type, $condition_operator,
                    $condition_value, $condition_script, $condition_duration,
                    $action_topic, $action_payload, $_POST['confirmation_topic'] ?? null,
                    (int)($_POST['confirmation_timeout'] ?? 30),
                    (int)($_POST['max_retries'] ?? 3),
                    (int)($_POST['retry_delay'] ?? 5),
                    $delay_seconds, (int)($_POST['cooldown_seconds'] ?? 30),
                    $schedule_type, $schedule_time, $schedule_days,
                    $time_restriction_start, $time_restriction_end,
                    $_POST['dependency_topic'] ?? null, $_POST['dependency_value'] ?? null,
                    $enabled, $persistent, $email_notify, $email_recipient,
                    $email_condition_duration, $push_notify, $push_topic,
                    $push_priority, $id
                ]);
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO automations (
                        name, group_name, trigger_topic, condition_type, condition_operator,
                        condition_value, condition_script, condition_duration,
                        action_topic, action_payload, confirmation_topic,
                        confirmation_timeout, max_retries, retry_delay,
                        delay_seconds, cooldown_seconds, schedule_type, schedule_time, schedule_days,
                        time_restriction_start, time_restriction_end, dependency_topic,
                        dependency_value, enabled, persistent,
                        email_notify, email_recipient, email_condition_duration,
                        push_notify, push_topic, push_priority
                    ) VALUES (
                        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                    )
                ");
                $stmt->execute([
                    $name, $rule_group, $trigger_topic, $condition_type, $condition_operator,
                    $condition_value, $condition_script, $condition_duration,
                    $action_topic, $action_payload, $_POST['confirmation_topic'] ?? null,
                    (int)($_POST['confirmation_timeout'] ?? 30),
                    (int)($_POST['max_retries'] ?? 3),
                    (int)($_POST['retry_delay'] ?? 5),
                    $delay_seconds, (int)($_POST['cooldown_seconds'] ?? 30),
                    $schedule_type, $schedule_time, $schedule_days,
                    $time_restriction_start, $time_restriction_end,
                    $_POST['dependency_topic'] ?? null, $_POST['dependency_value'] ?? null,
                    $enabled, $persistent, $email_notify, $email_recipient,
                    $email_condition_duration, $push_notify, $push_topic,
                    $push_priority
                ]);
            }
            $success = "Правило успешно сохранено!";
        } catch (Exception $e) {
            $error = "Ошибка сохранения: " . $e->getMessage();
        }
    }
}

// Обработка удаления
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM automations WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: logic.php");
    exit;
}

// Включение/выключение правила
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $stmt = $pdo->prepare("UPDATE automations SET enabled = NOT enabled WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: logic.php");
    exit;
}

$stmt = $pdo->query("SELECT DISTINCT topic FROM sensor_data ORDER BY topic");
$topics = $stmt->fetchAll(PDO::FETCH_COLUMN);

$stmt = $pdo->query("SELECT * FROM automations ORDER BY created_at DESC");
$rules = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ===== ГРУППИРОВКА ПРАВИЛ (28.10.2026) =====
// Правила делятся по automations.group_name; «Без группы» — в самый низ.
$ruleGroups = [];
foreach ($rules as $r) {
    $g = trim((string)($r['group_name'] ?? ''));
    if ($g === '') $g = 'Без группы';
    $ruleGroups[$g][] = $r;
}
uksort($ruleGroups, function ($a, $b) {
    if ($a === 'Без группы') return 1;
    if ($b === 'Без группы') return -1;
    return strcasecmp($a, $b);
});

// подсказки для поля «Группа»: то, что уже есть в базе + понятные варианты
$ruleGroupNames = array_values(array_filter(array_keys($ruleGroups), function ($g) {
    return $g !== 'Без группы';
}));
foreach (['Аквариум', 'Свет', 'Полив', 'Климат', 'Безопасность', 'Тесты'] as $sug) {
    if (!in_array($sug, $ruleGroupNames, true)) $ruleGroupNames[] = $sug;
}

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <meta name="theme-color" content="#0a0e12">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <link rel="manifest" href="/manifest.json">
    <meta name="apple-mobile-web-app-title" content="IoT Home">
    <title>🧠 Логика автоматизации</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<div class="container">
<?php include '/var/www/html/iot/public_html/include/links_panel.php';?>

    <h1>🧠 Логика автоматизации</h1>

    <!-- ============================================ -->
    <!-- 📖 СПРАВКА ПО СОЗДАНИЮ ПРАВИЛ (СКРЫТА ПО УМОЛЧАНИЮ) -->
    <!-- ============================================ -->
    <div class="help-section" style="margin-bottom: 25px; padding: 20px; background: var(--bg-card); border-radius: 16px; border-left: 4px solid var(--accent);">
        <h2 style="margin-top: 0; display: flex; align-items: center; gap: 10px; cursor: pointer; margin-bottom: 0;" onclick="toggleHelp()">
            <span>📖 Шпаргалка по созданию правил</span>
            <span id="helpToggleBtn" style="margin-left: auto; background: var(--bg-input); padding: 4px 14px; border-radius: 8px; font-size: 0.8em; user-select: none;">
                ▶ Развернуть
            </span>
        </h2>
        
        <div id="helpContent" style="display: none; padding-top: 15px;">
            <!-- ===== ОСНОВНЫЕ ПОНЯТИЯ ===== -->
            <div style="background: var(--bg-input); padding: 15px; border-radius: 10px; margin-bottom: 15px;">
                <h3 style="margin-top: 0; color: var(--accent);">🎯 Основные понятия</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px;">
                    <div><strong>📌 Триггер</strong> — событие, которое запускает проверку правила</div>
                    <div><strong>📊 Условие</strong> — что нужно проверить (температура > 25)</div>
                    <div><strong>⚡ Действие</strong> — что сделать (отправить команду)</div>
                    <div><strong>⏱️ Длительность</strong> — сколько секунд должно выполняться условие</div>
                    <div><strong>🛡️ Cooldown</strong> — защита от частых срабатываний</div>
                </div>
            </div>

            <!-- ===== ТИПЫ АКТИВАЦИИ ===== -->
            <div style="margin-bottom: 15px;">
                <h3 style="color: var(--accent);">⏰ Типы активации</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 12px;">
                    <div style="background: var(--bg-input); padding: 12px; border-radius: 8px; border-left: 3px solid #4caf50;">
                        <strong>🎯 По триггеру (MQTT)</strong><br>
                        <small>Срабатывает при изменении значения в топике.<br>
                        <code>Пример: температура стала > 25</code></small>
                    </div>
                    <div style="background: var(--bg-input); padding: 12px; border-radius: 8px; border-left: 3px solid #ffa726;">
                        <strong>📅 Каждый день</strong><br>
                        <small>Срабатывает в заданное время каждый день.<br>
                        <code>Пример: каждый день в 19:00</code></small>
                    </div>
                    <div style="background: var(--bg-input); padding: 12px; border-radius: 8px; border-left: 3px solid #ab47bc;">
                        <strong>📆 По дням недели</strong><br>
                        <small>Срабатывает в заданное время в выбранные дни.<br>
                        <code>Пример: по будням в 08:00</code></small>
                    </div>
                </div>
            </div>

            <!-- ===== ТИПЫ УСЛОВИЙ ===== -->
            <div style="margin-bottom: 15px;">
                <h3 style="color: var(--accent);">🔍 Типы условий</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 12px;">
                    <div style="background: var(--bg-input); padding: 12px; border-radius: 8px;">
                        <strong>✅ Простое условие</strong><br>
                        <small>Сравнивает значение с числом или строкой.</small><br>
                        <code style="font-size: 0.85em;">температура > 25</code><br>
                        <code style="font-size: 0.85em;">state == "ON"</code><br>
                        <code style="font-size: 0.85em;">влажность < 50</code>
                    </div>
                    <div style="background: var(--bg-input); padding: 12px; border-radius: 8px;">
                        <strong>🧠 Скриптовое условие</strong><br>
                        <small>Сложная логика с несколькими переменными.</small><br>
                        <code style="font-size: 0.85em;">sensor.temperature > 24 && sensor.humidity < 60</code><br>
                        <code style="font-size: 0.85em;">sensor.motion_1 || sensor.motion_2</code><br>
                        <code style="font-size: 0.85em;">sensor.state == "ON" && sensor.stall_time > 5</code>
                    </div>
                </div>
            </div>

            <!-- ===== ОПЕРАТОРЫ ===== -->
            <div style="margin-bottom: 15px;">
                <h3 style="color: var(--accent);">⚙️ Операторы для простых условий</h3>
                <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                    <span style="background: var(--bg-input); padding: 4px 12px; border-radius: 12px; font-family: monospace;">> &nbsp; больше</span>
                    <span style="background: var(--bg-input); padding: 4px 12px; border-radius: 12px; font-family: monospace;">< &nbsp; меньше</span>
                    <span style="background: var(--bg-input); padding: 4px 12px; border-radius: 12px; font-family: monospace;">== &nbsp; равно</span>
                    <span style="background: var(--bg-input); padding: 4px 12px; border-radius: 12px; font-family: monospace;">!= &nbsp; не равно</span>
                    <span style="background: var(--bg-input); padding: 4px 12px; border-radius: 12px; font-family: monospace;">>= &nbsp; больше или равно</span>
                    <span style="background: var(--bg-input); padding: 4px 12px; border-radius: 12px; font-family: monospace;"><= &nbsp; меньше или равно</span>
                </div>
            </div>

            <!-- ===== ПРИМЕРЫ ПРАВИЛ ===== -->
            <div style="margin-bottom: 15px;">
                <h3 style="color: var(--accent);">📋 Примеры готовых правил</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 12px;">
                    <div style="background: var(--bg-input); padding: 12px; border-radius: 8px; border: 1px solid rgba(76, 175, 80, 0.3);">
                        <div style="color: #4caf50; font-weight: bold;">🌡️ Включить обогрев</div>
                        <small>Триггер: <code>sensors/temperature</code></small><br>
                        <small>Условие: <code>< 18</code></small><br>
                        <small>Длительность: <code>60 сек</code></small><br>
                        <small>Действие: <code>heater/set {"state": "ON"}</code></small>
                    </div>
                    
                    <div style="background: var(--bg-input); padding: 12px; border-radius: 8px; border: 1px solid rgba(255, 167, 38, 0.3);">
                        <div style="color: #ffa726; font-weight: bold;">💡 Включить свет по движению</div>
                        <small>Триггер: <code>motion/sensor</code></small><br>
                        <small>Условие: <code>== "1"</code></small><br>
                        <small>Действие: <code>light/set {"state": "ON"}</code></small><br>
                        <small>Cooldown: <code>30 сек</code></small>
                    </div>
                    
                    <div style="background: var(--bg-input); padding: 12px; border-radius: 8px; border: 1px solid rgba(239, 83, 80, 0.3);">
                        <div style="color: #ef5350; font-weight: bold;">🔒 Защита от заливания</div>
                        <small>Триггер: <code>valve/state</code></small><br>
                        <small>Условие: <code>== "ON"</code></small><br>
                        <small>Длительность: <code>300 сек</code></small><br>
                        <small>Действие: <code>valve/set {"state": "OFF"}</code></small>
                    </div>
                    
                    <div style="background: var(--bg-input); padding: 12px; border-radius: 8px; border: 1px solid rgba(171, 71, 188, 0.3);">
                        <div style="color: #ab47bc; font-weight: bold;">📅 Утренний сценарий</div>
                        <small>Расписание: <code>ежедневно 07:00</code></small><br>
                        <small>Действие: <code>light/set {"state": "ON"}</code></small><br>
                        <small>Действие: <code>coffee/set {"state": "ON"}</code></small>
                    </div>
                </div>
            </div>

            <!-- ===== ВАЖНЫЕ ЗАМЕЧАНИЯ ===== -->
            <div style="background: rgba(255, 167, 38, 0.1); padding: 15px; border-radius: 10px; border-left: 3px solid #ffa726; margin-bottom: 15px;">
                <h4 style="margin-top: 0; color: #ffa726;">⚠️ Важные замечания</h4>
                <ul style="margin: 5px 0; padding-left: 20px;">
                    <li><strong>Топики:</strong> используйте <code>/state</code> для проверки состояния, <code>/set</code> для команд</li>
                    <li><strong>Строки:</strong> значения в кавычках — <code>"ON"</code>, <code>"OFF"</code>, <code>"open"</code></li>
                    <li><strong>Числа:</strong> без кавычек — <code>25</code>, <code>50</code>, <code>3.14</code></li>
                    <li><strong>Длительность:</strong> 0 = срабатывает мгновенно, >0 = ждет N секунд</li>
                    <li><strong>Cooldown:</strong> защита от повторных срабатываний (в секундах)</li>
                    <li><strong>Persistent:</strong> если отмечено — правило не удаляется после срабатывания</li>
                </ul>
            </div>

            <!-- ===== ПЕРЕМЕННЫЕ ДЛЯ СКРИПТОВ ===== -->
            <div style="background: var(--bg-input); padding: 15px; border-radius: 10px; margin-bottom: 15px;">
                <h4 style="margin-top: 0; color: var(--accent);">🧠 Переменные для скриптовых условий</h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 8px;">
                    <div><code>sensor.температура</code> — значение из топика</div>
                    <div><code>sensor.влажность</code> — значение из топика</div>
                    <div><code>sensor.state</code> — состояние устройства</div>
                    <div><code>sensor.battery</code> — уровень батареи</div>
                </div>
                <div style="margin-top: 8px; font-size: 0.9em; color: var(--text-muted);">
                    <strong>Пример:</strong> <code>sensor.temperature > 24 && sensor.humidity < 60</code>
                </div>
            </div>

            <!-- ===== EMAIL И PUSH ===== -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px;">
                <div style="background: var(--bg-input); padding: 10px; border-radius: 8px;">
                    <strong>📧 Email уведомления</strong><br>
                    <small>Отправляет письмо при срабатывании правила.<br>
                    <code>email_recipient: admin@example.com</code></small>
                </div>
                <div style="background: var(--bg-input); padding: 10px; border-radius: 8px;">
                    <strong>📱 Push уведомления</strong><br>
                    <small>Отправляет на телефон через ntfy.sh.<br>
                    <code>push_topic: iot-alerts</code></small>
                </div>
            </div>
        </div>
    </div>

    <?php if ($error): ?>
        <div class="message error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="message success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <div class="form-box">
        <h2>➕ Добавить / Редактировать правило</h2>
        <form method="post">
            <input type="hidden" name="id" id="rule_id" value="">
            <datalist id="rule_groups">
                <?php foreach ($ruleGroupNames as $rg): ?>
                    <option value="<?= htmlspecialchars($rg) ?>">
                <?php endforeach; ?>
            </datalist>

            <label>Название правила<br>
                <input type="text" name="name" required placeholder="Например: Включить свет в 19:00">
            </label>

            <label>📁 Группа правила<br>
                <input type="text" name="group_name" id="rule_group" list="rule_groups" placeholder="Например: Аквариум, Свет, Полив">
                <small style="opacity:.7;">Правила с одинаковой группой показываются вместе, группы можно сворачивать. Пусто = «Без группы».</small>
            </label>

            <label>Тип активации<br>
                <select name="schedule_type" onchange="toggleSchedule(this.value)">
                    <option value="none">По триггеру (MQTT)</option>
                    <option value="daily">Каждый день в заданное время</option>
                    <option value="weekly">По дням недели</option>
                </select>
            </label>

            <div id="triggerSection">
                <label>Топик для условия (опционально)<br>
                    <input list="topics" name="trigger_topic" placeholder="sensors/temperature/outside">
                    <datalist id="topics">
                        <?php foreach ($topics as $topic): ?>
                            <option value="<?= htmlspecialchars($topic) ?>">
                        <?php endforeach; ?>
                    </datalist>
                    <small>Используется для проверки условия (например, температура < 5). Оставьте пустым, чтобы игнорировать.</small>
                </label>
            </div>

            <label>Тип условия<br>
                <select name="condition_type" onchange="toggleConditionType(this.value)">
                    <option value="simple">Простое (A > B)</option>
                    <option value="script">Скрипт (выражение)</option>
                </select>
            </label>

            <div id="simpleCondition" style="display:block;">
                <label>Оператор<br>
                    <select name="condition_operator" style="width: auto; margin-right: 10px;">
                        <option value=">">></option>
                        <option value="<"><</option>
                        <option value="==" selected>=</option>
                        <option value="!=">!=</option>
                        <option value=">=">>=</option>
                        <option value="<="><=</option>
                    </select>
                </label>
                <label>Значение<br>
                    <input type="text" name="condition_value" placeholder="25">
                </label>
            </div>

            <div id="scriptCondition" style="display:none; margin-top: 15px;">
                <label>Условие (используй переменные: sensor.{topic}, data)<br>
                    <textarea name="condition_script" rows="4" placeholder="// Примеры:
sensor.temperature > 24 && sensor.humidity < 60
sensor.motion_1 || sensor.motion_2"></textarea>
                    <small>Поддерживаются: <code>sensor.{topic}</code>, <code>data</code>, числа, &&, ||, ==, >, <, !, (), [], .</small>
                </label>
            </div>

            <label>Условие должно соблюдаться (сек)<br>
                <input type="number" name="condition_duration" value="0" min="0" placeholder="0 = мгновенно">
                <small>Например: температура > 25 в течение 300 сек — только тогда срабатывает.</small>
            </label>
            
            <div id="scheduleSection" style="display:none;">
                <label>Время срабатывания (HH:MM:SS)<br>
                    <input type="text" name="schedule_time" value="00:00:00" placeholder="20:30:00">
                    <small>Формат: ЧЧ:ММ:СС (24-часовой)</small>
                </label>

                <div id="weeklyDays" style="display:none; margin-top:10px;">
                    <label>Дни недели<br>
                        <div class="schedule-days">
                            <?php
                            $days = ['mon'=>'Пн', 'tue'=>'Вт', 'wed'=>'Ср', 'thu'=>'Чт', 'fri'=>'Пт', 'sat'=>'Сб', 'sun'=>'Вс'];
                            foreach ($days as $k => $v): ?>
                                <label>
                                    <input type="checkbox" name="schedule_days[]" value="<?= $k ?>">
                                    <?= $v ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </label>
                    <label>Ограничение по времени суток (не раньше)<br>
                        <input type="time" name="time_restriction_start">
                    </label>
                    <label>Ограничение по времени суток (не позже)<br>
                        <input type="time" name="time_restriction_end">
                    </label>
                    <label>Зависимость от другого устройства (опционально)<br>
                        <input list="topics" name="dependency_topic" placeholder="sensors/window/kitchen">
                        <small>Правило сработает ТОЛЬКО если это устройство имеет нужное значение.</small>
                    </label>
                    <label>Требуемое значение зависимости<br>
                        <input type="text" name="dependency_value" placeholder="closed / true / 0">
                    </label>
                </div>
            </div>
            
            <label>
                <input type="checkbox" name="persistent"> Повторять (не удалять после выполнения)
            </label>

            <!-- Email секция -->
            <div class="email-section">
                <label style="color: #ff6b6b;">
                    <input type="checkbox" name="email_notify" onchange="toggleEmail(this.checked)">
                    📧 Отправлять email при срабатывании
                </label>
                
                <div id="emailSettings" style="display:none; margin-top: 10px;">
                    <label>Email получателя:<br>
                        <input type="email" name="email_recipient" placeholder="admin@example.com">
                    </label>
                    
                    <label>Отправлять только если условие держится (сек):<br>
                        <input type="number" name="email_condition_duration" value="0" min="0">
                        <small>0 = сразу, 3600 = через час</small>
                    </label>
                </div>
                
                <!-- Push секция -->
                <div class="push-section" style="margin-top: 15px; border-top: 1px solid #333; padding-top: 15px;">
                    <label style="color: #4ecdc4;">
                        <input type="checkbox" name="push_notify" onchange="togglePush(this.checked)">
                        📱 Отправлять push-уведомление на телефон
                    </label>
                    
                    <div id="pushSettings" style="display:none; margin-top: 10px;">
                        <label>Топик в ntfy:<br>
                            <input type="text" name="push_topic" placeholder="my-phone" value="iot-alerts">
                            <small>Подпишитесь на этот топик в приложении ntfy</small>
                        </label>
                        
                        <label>Приоритет:<br>
                            <select name="push_priority">
                                <option value="low">🟢 Низкий</option>
                                <option value="high" selected>🟠 Высокий</option>
                                <option value="urgent">🔴 Срочный (звук)</option>
                            </select>
                        </label>
                    </div>
                </div>
            </div>

            <label>Топик для действия (куда отправить)<br>
                <input list="topics" name="action_topic" placeholder="devices/light/living_room/set">
            </label>

            <label>Payload (что отправить)<br>
                <textarea name="action_payload" rows="2" placeholder='{"state": "ON"}'>{"state": "ON"}</textarea>
            </label>
            
            <label>Топик подтверждения (опционально)<br>
                <input list="topics" name="confirmation_topic" placeholder="devices/valve/state">
                <small>Устройство должно опубликовать сюда состояние после выполнения действия.</small>
            </label>
            
            <label>Таймаут подтверждения (сек)<br>
                <input type="number" name="confirmation_timeout" value="30" min="5">
            </label>

            <label>Максимум попыток<br>
                <input type="number" name="max_retries" value="3" min="0" max="10">
            </label>

            <label>Задержка между попытками (сек)<br>
                <input type="number" name="retry_delay" value="5" min="1">
            </label>

            <label>Задержка перед действием (сек)<br>
                <input type="number" name="delay_seconds" value="0" min="0">
            </label>
            
            <label>🛡️ Защита от частых срабатываний (Cooldown, сек)<br>
                <input type="number" name="cooldown_seconds" value="30" min="0" max="3600">
                <small>Минимальное время между срабатываниями правила (0 = без защиты)</small>
            </label>

            <label>
                <input type="checkbox" name="enabled" checked> Активно
            </label>

            <br><br>
            <input type="submit" name="save" value="💾 Сохранить правило">
        </form>
    </div>

    <h2>📋 Все правила <span style="font-size:0.6em; opacity:.6;"><?= count($rules) ?> шт. в <?= count($ruleGroups) ?> группах</span></h2>

    <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center; margin-bottom:14px;">
        <input type="text" id="ruleFilter" placeholder="🔍 Поиск по названию, топику, группе"
               oninput="filterRules(this.value)" style="flex:1 1 260px; min-width:200px;">
        <button type="button" onclick="toggleAllRuleGroups(true)">📂 Раскрыть все</button>
        <button type="button" onclick="toggleAllRuleGroups(false)">📁 Свернуть все</button>
    </div>

    <?php if (empty($rules)): ?>
        <div class="empty-state">
            🕯️ Нет созданных правил. Создайте своё первое правило выше!
        </div>
    <?php else: ?>
        <?php foreach ($ruleGroups as $grpName => $grules): ?>
        <details class="rule-group" data-group="<?= htmlspecialchars($grpName, ENT_QUOTES) ?>"
                 <?= ($grpName === 'Без группы') ? '' : 'open' ?>
                 style="margin-bottom:14px; background: var(--bg-card); border-radius:16px; border-left:4px solid var(--accent);">
            <summary style="cursor:pointer; padding:14px 18px; font-weight:600;">
                📁 <?= htmlspecialchars($grpName) ?>
                <span style="font-size:0.8em; opacity:.65; background: var(--bg-input); border-radius:10px; padding:2px 10px; margin-left:6px;"><?= count($grules) ?></span>
                <span style="font-size:0.8em; opacity:.6; margin-left:8px;">
                    <?php $onCount = count(array_filter($grules, function ($x) { return !empty($x['enabled']); })); ?>
                    ✅ <?= $onCount ?> / ❌ <?= count($grules) - $onCount ?>
                </span>
                <span style="float:right; font-size:0.75em; opacity:.5;">скрыть / показать</span>
            </summary>
            <div class="sensors-grid" style="padding:0 14px 14px;">
            <?php foreach ($grules as $rule): ?>
                <div class="sensor-card">
                    <div class="card-header">
                        <span class="sensor-icon">
                            <?php 
                                $type = $rule['schedule_type'];
                                if ($type === 'none') echo '🎯';
                                elseif ($type === 'daily') echo '📅';
                                else echo '📆';
                            ?>
                        </span>
                        <span class="sensor-topic"><?= htmlspecialchars($rule['name']) ?></span>
                        <span class="history-badge <?= $rule['enabled'] ? 'history-yes' : 'history-no' ?>">
                            <?= $rule['enabled'] ? '✅ Вкл' : '❌ Выкл' ?>
                        </span>
                    </div>
                    
                    <div class="card-body">
                        <div class="sensor-property">
                            <span class="property-label">
                                <?php if ($rule['schedule_type'] !== 'none'): ?>
                                    ⏰ Расписание
                                <?php else: ?>
                                    🎯 Триггер
                                <?php endif; ?>
                            </span>
                            <span class="property-value">
                                <?php if ($rule['schedule_type'] !== 'none'): ?>
                                    <code><?= substr($rule['schedule_time'], 0, 5) ?></code>
                                    <?php if ($rule['schedule_type'] === 'weekly' && $rule['schedule_days']): ?>
                                        <br><small>📅 <?= htmlspecialchars($rule['schedule_days']) ?></small>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <code><?= htmlspecialchars($rule['trigger_topic'] ?: '(не указан)') ?></code>
                                    <?php if ($rule['condition_type'] === 'simple' && $rule['condition_operator'] && $rule['condition_value'] !== ''): ?>
                                        <br><small>Условие: <?= htmlspecialchars($rule['condition_operator']) ?> <?= htmlspecialchars($rule['condition_value']) ?></small>
                                    <?php elseif ($rule['condition_type'] === 'script' && $rule['condition_script']): ?>
                                        <br><small>Скрипт: <?= htmlspecialchars(mb_substr($rule['condition_script'], 0, 40)) ?>...</small>
                                    <?php endif; ?>
                                    <?php if ($rule['condition_duration'] > 0): ?>
                                        <br><small>⏱️ Длит: <?= $rule['condition_duration'] ?> сек</small>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </span>
                        </div>
                        
                        <div class="sensor-property">
                            <span class="property-label">⚡ Действие</span>
                            <span class="property-value">
                                <code><?= htmlspecialchars($rule['action_topic']) ?></code>
                                <br><small><?= htmlspecialchars($rule['action_payload']) ?></small>
                                <?php if ($rule['delay_seconds'] > 0): ?>
                                    <br><small>⏱️ Задержка: <?= $rule['delay_seconds'] ?> сек</small>
                                <?php endif; ?>
                            </span>
                        </div>
                        
                        <?php if (!empty($rule['email_notify']) && !empty($rule['email_recipient'])): ?>
                            <div class="sensor-property">
                                <span class="property-label">📧 Email</span>
                                <span class="property-value">
                                    <?= htmlspecialchars($rule['email_recipient']) ?>
                                    <?php if ($rule['email_condition_duration'] > 0): ?>
                                        <br><small>(через <?= $rule['email_condition_duration'] ?> сек)</small>
                                    <?php endif; ?>
                                </span>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($rule['dependency_topic']): ?>
                            <div class="sensor-property">
                                <span class="property-label">🔗 Зависимость</span>
                                <span class="property-value">
                                    <code><?= htmlspecialchars($rule['dependency_topic']) ?></code> = <?= htmlspecialchars($rule['dependency_value'] ?: 'любое') ?>
                                </span>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="card-footer">
                        <a href="#" onclick="editRule(<?= htmlspecialchars(json_encode($rule), ENT_QUOTES, 'UTF-8') ?>)">✏️ Редактировать</a>
                        <a href="?toggle=<?= $rule['id'] ?>">🔄 Вкл/Выкл</a>
                        <a href="?delete=<?= $rule['id'] ?>" onclick="return confirm('Удалить правило?')">🗑️ Удалить</a>
                    </div>
                </div>
            <?php endforeach; ?>
            </div>
        </details>
        <?php endforeach; ?>
    <?php endif; ?>

    <form method="post" action="/admin/logout.php" style="margin-top: 30px;">
        <button type="submit">🚪 Выйти</button>
    </form>
</div>

<!-- ===== JAVASCRIPT ===== -->
<script>
function toggleSchedule(type) {
    const scheduleSection = document.getElementById('scheduleSection');
    const weeklyDays = document.getElementById('weeklyDays');
    if (type !== 'none') {
        scheduleSection.style.display = 'block';
        weeklyDays.style.display = (type === 'weekly') ? 'block' : 'none';
    } else {
        scheduleSection.style.display = 'none';
        weeklyDays.style.display = 'none';
    }
}

function toggleConditionType(type) {
    document.getElementById('simpleCondition').style.display = (type === 'simple') ? 'block' : 'none';
    document.getElementById('scriptCondition').style.display = (type === 'script') ? 'block' : 'none';
}

function toggleEmail(checked) {
    document.getElementById('emailSettings').style.display = checked ? 'block' : 'none';
}

function togglePush(checked) {
    document.getElementById('pushSettings').style.display = checked ? 'block' : 'none';
}

// ===== Группы правил: помним, что свёрнуто (28.10.2026) =====
const RULE_GROUP_KEY = 'iot_rule_groups_closed';
let closedRuleGroups = new Set();
try { closedRuleGroups = new Set(JSON.parse(localStorage.getItem(RULE_GROUP_KEY) || '[]')); } catch (e) {}

function applyRuleGroupState() {
    document.querySelectorAll('details.rule-group').forEach(function (d) {
        if (closedRuleGroups.has(d.dataset.group)) d.removeAttribute('open');
        else d.setAttribute('open', 'open');
    });
}
function saveRuleGroupState() {
    try { localStorage.setItem(RULE_GROUP_KEY, JSON.stringify(Array.from(closedRuleGroups))); } catch (e) {}
}
document.querySelectorAll('details.rule-group').forEach(function (d) {
    d.addEventListener('toggle', function () {
        if (d.open) closedRuleGroups.delete(d.dataset.group);
        else closedRuleGroups.add(d.dataset.group);
        saveRuleGroupState();
    });
});
if (localStorage.getItem(RULE_GROUP_KEY) !== null) applyRuleGroupState();

function toggleAllRuleGroups(open) {
    document.querySelectorAll('details.rule-group').forEach(function (d) {
        if (open) { d.setAttribute('open', 'open'); closedRuleGroups.delete(d.dataset.group); }
        else { d.removeAttribute('open'); closedRuleGroups.add(d.dataset.group); }
    });
    saveRuleGroupState();
}

function filterRules(q) {
    q = (q || '').trim().toLowerCase();
    document.querySelectorAll('details.rule-group').forEach(function (d) {
        let visible = 0;
        d.querySelectorAll('.sensor-card').forEach(function (card) {
            const hit = !q || card.textContent.toLowerCase().indexOf(q) !== -1;
            card.style.display = hit ? '' : 'none';
            if (hit) visible++;
        });
        d.style.display = (visible === 0) ? 'none' : '';
        if (q && visible > 0) d.setAttribute('open', 'open');
    });
}

function toggleHelp() {
    const content = document.getElementById('helpContent');
    const btn = document.getElementById('helpToggleBtn');
    if (content.style.display === 'none') {
        content.style.display = 'block';
        btn.textContent = '▼ Свернуть';
    } else {
        content.style.display = 'none';
        btn.textContent = '▶ Развернуть';
    }
}

function editRule(rule) {
    var rg = document.getElementById('rule_group');
    if (rg) rg.value = rule.group_name || '';
    document.querySelector("[name='name']").value = rule.name || '';
    document.querySelector("[name='cooldown_seconds']").value = rule.cooldown_seconds || 30;
    document.querySelector("[name='condition_type']").value = rule.condition_type || 'simple';
    document.querySelector("[name='trigger_topic']").value = rule.trigger_topic || '';
    document.querySelector("[name='condition_operator']").value = rule.condition_operator || '==';
    document.querySelector("[name='condition_value']").value = rule.condition_value || '';
    document.querySelector("[name='condition_script']").value = rule.condition_script || '';
    document.querySelector("[name='condition_duration']").value = rule.condition_duration || 0;
    document.querySelector("[name='action_topic']").value = rule.action_topic || '';
    document.querySelector("[name='action_payload']").value = rule.action_payload || '';
    document.querySelector("[name='confirmation_topic']").value = rule.confirmation_topic || '';
    document.querySelector("[name='confirmation_timeout']").value = rule.confirmation_timeout || 30;
    document.querySelector("[name='max_retries']").value = rule.max_retries || 3;
    document.querySelector("[name='retry_delay']").value = rule.retry_delay || 5;
    document.querySelector("[name='delay_seconds']").value = rule.delay_seconds || 0;
    document.querySelector("[name='schedule_type']").value = rule.schedule_type || 'none';
    document.querySelector("[name='schedule_time']").value = rule.schedule_time ? rule.schedule_time.substring(0,8) : '00:00:00';
    document.querySelector("[name='time_restriction_start']").value = rule.time_restriction_start || '';
    document.querySelector("[name='time_restriction_end']").value = rule.time_restriction_end || '';
    document.querySelector("[name='dependency_topic']").value = rule.dependency_topic || '';
    document.querySelector("[name='dependency_value']").value = rule.dependency_value || '';
    document.querySelector("[name='enabled']").checked = rule.enabled == 1;
    document.getElementById('rule_id').value = rule.id || '';
    
    document.querySelector("[name='email_notify']").checked = rule.email_notify == 1;
    document.querySelector("[name='email_recipient']").value = rule.email_recipient || '';
    document.querySelector("[name='email_condition_duration']").value = rule.email_condition_duration || 0;
    
    toggleSchedule(rule.schedule_type || 'none');
    toggleConditionType(rule.condition_type || 'simple');
    toggleEmail(rule.email_notify == 1);
    togglePush(document.querySelector("[name='push_notify']")?.checked || false);
    
    const checkboxes = document.querySelectorAll("input[name='schedule_days[]']");
    const selectedDays = rule.schedule_days ? rule.schedule_days.split(',') : [];
    checkboxes.forEach(cb => {
        cb.checked = selectedDays.includes(cb.value);
    });
    
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', function() {
    toggleSchedule(document.querySelector("[name='schedule_type']").value);
    const pushCheckbox = document.querySelector("[name='push_notify']");
    if (pushCheckbox) {
        togglePush(pushCheckbox.checked);
    }
    // Справка скрыта по умолчанию
    const helpContent = document.getElementById('helpContent');
    const helpBtn = document.getElementById('helpToggleBtn');
    if (helpContent) {
        helpContent.style.display = 'none';
        if (helpBtn) helpBtn.textContent = '▶ Развернуть';
    }
});
</script>

</body>
</html>
