<?php
require_once '/var/www/html/iot/config/iot_config.php';

// config.php
$db_host = 'localhost';
$db_user = 'IOT_DB_USER';
$db_pass = IOT_DB_PASS;
$db_name = 'iot_db';


// Подключение к БД
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получаем последние данные
$sql = "SELECT * FROM rpi_monitor ORDER BY timestamp DESC LIMIT 1";
$result = $conn->query($sql);
$rpi_data = $result->fetch_assoc();

// Закрываем соединение
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Raspberry Pi Monitor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        .card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .critical {
            color: #e74c3c;
            font-weight: bold;
        }
        .warning {
            color: #f39c12;
        }
        .ok {
            color: #2ecc71;
        }
        h1 {
            color: #2c3e50;
        }
        .progress-container {
            width: 100%;
            background-color: #e0e0e0;
            border-radius: 5px;
            margin: 10px 0;
        }
        .progress-bar {
            height: 20px;
            border-radius: 5px;
            background-color: #3498db;
            text-align: center;
            color: white;
            line-height: 20px;
        }
    </style>
</head>
<body>
    <h1>Raspberry Pi Monitoring</h1>
    <p>Last update: <?php echo htmlspecialchars($rpi_data['timestamp'] ?? 'Never'); ?></p>
    
    <div class="dashboard">
        <!-- CPU Card -->
        <div class="card">
            <h2>CPU</h2>
            <p>Temperature: 
                <span class="<?php 
                    $temp = $rpi_data['cpu_temp'] ?? 0;
                    if ($temp > 70) echo 'critical';
                    elseif ($temp > 60) echo 'warning';
                    else echo 'ok';
                ?>">
                <?php echo htmlspecialchars($temp); ?>°C
                </span>
            </p>
            <p>Load: <?php echo htmlspecialchars($rpi_data['cpu_load'] ?? 'N/A'); ?>%</p>
            <div class="progress-container">
                <div class="progress-bar" style="width: <?php echo min(100, $rpi_data['cpu_load'] ?? 0); ?>%">
                    <?php echo min(100, $rpi_data['cpu_load'] ?? 0); ?>%
                </div>
            </div>
        </div>
        
        <!-- Memory Card -->
        <div class="card">
            <h2>Memory</h2>
            <p>Used: <?php echo htmlspecialchars($rpi_data['mem_used'] ?? 'N/A'); ?>MB / 
                <?php echo htmlspecialchars($rpi_data['mem_total'] ?? 'N/A'); ?>MB</p>
            <p>Usage: <?php echo htmlspecialchars($rpi_data['mem_percent'] ?? 'N/A'); ?>%</p>
            <div class="progress-container">
                <div class="progress-bar" style="width: <?php echo min(100, $rpi_data['mem_percent'] ?? 0); ?>%">
                    <?php echo min(100, $rpi_data['mem_percent'] ?? 0); ?>%
                </div>
            </div>
        </div>
        
        <!-- Disk Card -->
        <div class="card">
            <h2>Disk</h2>
            <p>Usage: <?php echo htmlspecialchars($rpi_data['disk_usage'] ?? 'N/A'); ?>%</p>
            <div class="progress-container">
                <div class="progress-bar" style="width: <?php echo min(100, $rpi_data['disk_usage'] ?? 0); ?>%">
                    <?php echo min(100, $rpi_data['disk_usage'] ?? 0); ?>%
                </div>
            </div>
        </div>
        
        <!-- System Info Card -->
        <div class="card">
            <h2>System Info</h2>
            <p>Uptime: <?php echo htmlspecialchars($rpi_data['uptime'] ?? 'N/A'); ?></p>
            <p>IP Addresses: <?php echo htmlspecialchars($rpi_data['ip_addresses'] ?? 'N/A'); ?></p>
        </div>
    </div>
</body>
</html>
