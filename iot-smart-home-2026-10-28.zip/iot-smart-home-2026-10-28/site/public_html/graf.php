<?php
require_once '/var/www/html/iot/config/iot_config.php';

date_default_timezone_set('Europe/Moscow');

try {
    $pdo = iot_pdo();

    // Напряжение батарейки приходит в МИЛЛИВОЛЬТАХ, напряжение сети — в вольтах.
    // Без этого график батарейки подписывался бы «В» и вводил в заблуждение.
    $battery_mv_topics = [];
    try {
        foreach ($pdo->query("SELECT device FROM battery_spec WHERE active=1 AND has_voltage=1")
                     ->fetchAll(PDO::FETCH_COLUMN) as $__bd) {
            $battery_mv_topics["zigbee2mqtt/$__bd/voltage"] = true;
        }
    } catch (Throwable $e) {}

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare("
        SELECT 
            s.topic,
            s.value,
            s.timestamp as last_time,
            i.name,
            i.room,
            i.group_name,
            i.icon,
            h.first_seen
        FROM sensor_info i
        INNER JOIN sensor_data s ON i.topic = s.topic
        INNER JOIN (
            SELECT topic, MAX(timestamp) as max_time
            FROM sensor_data
            GROUP BY topic
        ) latest ON s.topic = latest.topic AND s.timestamp = latest.max_time
        INNER JOIN (
            SELECT topic, MIN(timestamp) as first_seen
            FROM sensor_history
            GROUP BY topic
        ) h ON i.topic = h.topic
        ORDER BY i.group_name, i.name
    ");

    $stmt->execute();
    $rows = $stmt->fetchAll();

    $topics = [];
    foreach ($rows as $row) {
        $type = basename($row['topic']);
        $is_batt_mv = isset($battery_mv_topics[$row['topic']]);

        $unit = match($type) {
            'temperature' => '°C',
            'humidity' => '%',
            'light', 'illuminance' => 'лк',
            'pm25' => 'мкг/м³',
            'co2' => 'ppm',
            'voltage' => $is_batt_mv ? 'мВ' : 'В',
            'current' => 'А',
            'power' => 'Вт',
            'energy' => 'кВт·ч',
            'battery' => '%',
            'voc' => 'мкг/м³',
            'pressure' => 'гПа',
            default => ''
        };

        $topics[] = [
            'topic' => $row['topic'],
            'value' => $row['value'] ?? 'Нет данных',
            'timestamp' => $row['last_time'] ?? '—',
            'name' => $row['name'] ?: ucfirst($type),
            'room' => $row['room'] ?: 'Неизвестная комната',
            'group' => $row['group_name'] ?: 'Без группы',
            'type' => $type,
            'unit' => $unit,
            'icon' => $row['icon'] ?? '📡',
            'first_seen' => $row['first_seen'] 
        ];
    }

    // Группировка
    $groups = [];
    foreach ($topics as $data) {
        $groupName = $data['group'];
        if (empty($groupName) || $groupName === 'Без группы') {
            $groupName = 'Общие';
        }
        if (!isset($groups[$groupName])) $groups[$groupName] = [];
        $groups[$groupName][] = $data;
    }

    $preferredOrder = ['Дом', 'Дача', 'Общие'];
    uksort($groups, function($a, $b) use ($preferredOrder) {
        $posA = array_search($a, $preferredOrder);
        $posB = array_search($b, $preferredOrder);
        if ($posA === false) $posA = 999;
        if ($posB === false) $posB = 999;
        return $posA - $posB;
    });

} catch (Exception $e) {
    die("Ошибка БД: " . htmlspecialchars($e->getMessage()));
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <meta name="theme-color" content="#0a0e12">
    <title>📊 IoT Датчики с графиками</title>
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#0a0e12">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="IoT Home">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="/css/style.css">
    <style>
        canvas {
            max-height: 140px;
            width: 100%;
            margin-top: 0.75rem;
        }
        .sensor-card {
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        .sensor-card .card-body {
            flex: 1;
        }
        .sensor-value {
            text-align: center;
            padding: 0.5rem 0;
        }
        .sensor-value .value {
            font-size: 1.8rem;
            font-weight: 700;
        }
        .sensor-value .unit {
            color: var(--text-muted);
            font-size: 0.9rem;
        }
        @media (max-width: 480px) {
            .sensor-value .value {
                font-size: 1.4rem;
            }
            canvas {
                max-height: 100px;
            }
        }
        h2 {
            margin-top: 1.5rem;
            margin-bottom: 1rem;
        }
        h2:first-of-type {
            margin-top: 0;
        }
        
        /* Периоды */
        .period-selector {
            display: flex;
            gap: 4px;
            flex-wrap: wrap;
            margin-top: 6px;
        }
        .period-btn {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            color: var(--text-muted);
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.7rem;
            cursor: pointer;
            transition: all 0.2s;
            font-family: inherit;
        }
        .period-btn:hover {
            background: var(--bg-hover);
            color: var(--text-primary);
        }
        .period-btn.active {
            background: var(--accent-color);
            border-color: var(--accent-color);
            color: #fff;
        }
        .card-header {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 4px;
        }
        .card-header .sensor-topic {
            flex: 1;
            min-width: 100px;
        }
        .card-header .period-selector {
            margin-left: auto;
        }
        @media (max-width: 480px) {
            .card-header .period-selector {
                width: 100%;
                justify-content: flex-start;
            }
        }
        .chart-wrapper {
            position: relative;
        }
        .chart-loading {
            text-align: center;
            color: var(--text-muted);
            font-size: 0.7rem;
            padding: 10px 0;
        }

        /* ===== СТИЛИ ДЛЯ МОДАЛЬНОГО ОКНА ===== */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.85);
            z-index: 9999;
            justify-content: center;
            align-items: center;
            padding: 20px;
            box-sizing: border-box;
            backdrop-filter: blur(8px);
            animation: fadeIn 0.3s ease;
        }
        .modal-overlay.active {
            display: flex;
        }
        .modal-content {
            background: var(--bg-primary);
            border-radius: 20px;
            max-width: 1200px;
            width: 100%;
            max-height: 95vh;
            padding: 30px 30px 20px 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.8);
            display: flex;
            flex-direction: column;
            animation: slideUp 0.35s ease;
            border: 1px solid var(--border-color);
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            flex-shrink: 0;
        }
        .modal-header h2 {
            margin: 0;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .modal-header h2 small {
            font-size: 0.9rem;
            color: var(--text-muted);
            font-weight: normal;
        }
        .modal-close {
            background: none;
            border: none;
            color: var(--text-muted);
            font-size: 2rem;
            cursor: pointer;
            padding: 0 10px;
            transition: color 0.2s;
            line-height: 1;
        }
        .modal-close:hover {
            color: #ff6b6b;
        }
        .modal-chart-wrapper {
            flex: 1;
            min-height: 0;
            position: relative;
        }
        .modal-chart-wrapper canvas {
            max-height: none !important;
            height: 100% !important;
            width: 100% !important;
            margin-top: 0;
        }
        .modal-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-shrink: 0;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid var(--border-color);
            flex-wrap: wrap;
            gap: 10px;
        }
        .modal-info .sensor-value-big {
            font-size: 2rem;
            font-weight: 700;
        }
        .modal-info .sensor-value-big .unit {
            font-size: 1.2rem;
            color: var(--text-muted);
        }
        .modal-period-selector {
            display: flex;
            gap: 6px;
        }
        .modal-period-selector .period-btn {
            padding: 4px 14px;
            font-size: 0.85rem;
        }

        /* Анимации */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideUp {
            from { transform: translateY(40px) scale(0.96); opacity: 0; }
            to { transform: translateY(0) scale(1); opacity: 1; }
        }

        /* Кнопка "Во весь экран" */
        .fullscreen-btn {
            background: none;
            border: 1px solid var(--border-color);
            color: var(--text-muted);
            border-radius: 12px;
            padding: 2px 10px;
            font-size: 0.7rem;
            cursor: pointer;
            transition: all 0.2s;
            font-family: inherit;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            margin-left: auto;
        }
        .fullscreen-btn:hover {
            background: var(--bg-hover);
            color: var(--text-primary);
            border-color: var(--accent-color);
        }
        .card-header .fullscreen-btn {
            margin-left: auto;
        }

        @media (max-width: 600px) {
            .modal-content {
                padding: 15px;
                border-radius: 12px;
                max-height: 98vh;
            }
            .modal-header h2 {
                font-size: 1.1rem;
            }
            .modal-info .sensor-value-big {
                font-size: 1.4rem;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <?php include '/var/www/html/iot/public_html/include/links_panel.php';?>

    <h1>📊 Датчики с графиками</h1>

    <?php if (empty($topics)): ?>
        <div class="empty-state">Нет доступных датчиков с графиками</div>
    <?php else: ?>
        <?php foreach ($groups as $groupName => $groupItems): ?>
            <h2><?= htmlspecialchars($groupName) ?></h2>
            <div class="sensors-grid">
                <?php foreach ($groupItems as $data): 
                    $safeId = 'sensor-' . base64_encode($data['topic']);
                    $chartId = 'chart-' . preg_replace('/[^a-zA-Z0-9]/', '_', $data['topic']);
                    $modalChartId = 'modal-chart-' . preg_replace('/[^a-zA-Z0-9]/', '_', $data['topic']);
                    
                    $valueClass = '';
                    if ($data['type'] === 'temperature') {
                        $temp = floatval($data['value']);
                        if ($temp > 30) $valueClass = 'error';
                        elseif ($temp > 25) $valueClass = 'warning';
                        else $valueClass = 'success';
                    } elseif ($data['type'] === 'humidity') {
                        $hum = floatval($data['value']);
                        if ($hum > 70 || $hum < 30) $valueClass = 'warning';
                        else $valueClass = 'success';
                    } elseif ($data['type'] === 'battery') {
                        $bat = floatval($data['value']);
                        if ($bat < 20) $valueClass = 'error';
                        elseif ($bat < 50) $valueClass = 'warning';
                        else $valueClass = 'success';
                    }
                ?>
                    <div class="sensor-card" data-topic="<?= htmlspecialchars($data['topic']) ?>">
                        <div class="card-header">
                            <span class="sensor-icon"><?= htmlspecialchars($data['icon']) ?></span>
                            <span class="sensor-topic">
                                <?= htmlspecialchars($data['name']) ?>
                                <small style="color: var(--text-muted);">(<?= htmlspecialchars($data['room']) ?>)</small>
                            </span>
                            <span class="history-badge history-yes">📊</span>
                            
                            <!-- ===== КНОПКА ВО ВЕСЬ ЭКРАН ===== -->
                            <button class="fullscreen-btn" data-topic="<?= htmlspecialchars($data['topic']) ?>" data-name="<?= htmlspecialchars($data['name']) ?>" data-unit="<?= htmlspecialchars($data['unit']) ?>" data-value="<?= htmlspecialchars($data['value']) ?>">
                                🔍 Во весь экран
                            </button>
                            
                            <div class="period-selector">
                                <button class="period-btn active" data-period="hour">1ч</button>
                                <button class="period-btn" data-period="day">24ч</button>
                                <button class="period-btn" data-period="week">7д</button>
                                <button class="period-btn" data-period="month">30д</button>
                                <button class="period-btn" data-period="year">12м</button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="sensor-value">
                                <span class="value <?= $valueClass ?>"><?= htmlspecialchars($data['value']) ?></span>
                                <span class="unit"><?= htmlspecialchars($data['unit']) ?></span>
                            </div>
                            <div class="sensor-timestamp" style="text-align: center;">
                                🕔 <?= htmlspecialchars(date('j M Y, H:i', strtotime($data['timestamp']))) ?>
                            </div>
                            <?php if (!empty($data['first_seen'])): ?>
                                <div class="sensor-timestamp" style="text-align: center; font-size: 0.65rem;">
                                    📅 с <?= htmlspecialchars(date('j M Y', strtotime($data['first_seen']))) ?>
                                </div>
                            <?php endif; ?>
<button class="clear-history-btn" data-topic="<?= htmlspecialchars($data['topic']) ?>" style="
    background: none;
    border: none;
    color: #ff6b6b;
    font-size: 0.7rem;
    cursor: pointer;
    padding: 2px 8px;
    border-radius: 12px;
    transition: all 0.2s;
    margin-top: 6px;
    display: inline-block;
" onmouseover="this.style.background='rgba(255,107,107,0.1)'" onmouseout="this.style.background='none'">
    🗑️ Очистить
</button>
                            <div class="chart-wrapper">
                                <canvas id="chart-<?= $chartId ?>"></canvas>
                                <div class="chart-loading" id="loading-<?= $chartId ?>">⏳ Загрузка...</div>
                            </div>

                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- ===== МОДАЛЬНОЕ ОКНО ===== -->
<div class="modal-overlay" id="chartModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 id="modalTitle">📊 <span id="modalSensorName"></span> <small id="modalRoom"></small></h2>
            <button class="modal-close" id="modalCloseBtn">&times;</button>
        </div>
        <div class="modal-chart-wrapper">
            <canvas id="modalChart"></canvas>
        </div>
        <div class="modal-info">
            <div class="sensor-value-big">
                <span id="modalValue"></span>
                <span class="unit" id="modalUnit"></span>
                <span style="font-size:0.8rem; color:var(--text-muted); margin-left:12px;" id="modalTimestamp"></span>
            </div>
            <div class="modal-period-selector" id="modalPeriodSelector">
                <button class="period-btn active" data-period="hour">1ч</button>
                <button class="period-btn" data-period="day">24ч</button>
                <button class="period-btn" data-period="week">7д</button>
                <button class="period-btn" data-period="month">30д</button>
                <button class="period-btn" data-period="year">12м</button>
            </div>
        </div>
    </div>
</div>

<script>
    const charts = {};
    const chartData = {};

    // Цвета для разных типов датчиков
    const colors = {
        temperature: '#ff6b6b',
        humidity: '#4ecdc4',
        co2: '#ffd93d',
        battery: '#6bcb77',
        voc: '#a29bfe',
        hcho: '#fd79a8',
        default: '#58a6ff'
    };

    // ===== ИНИЦИАЛИЗАЦИЯ ГРАФИКОВ =====
    document.querySelectorAll('canvas[id^="chart-"]').forEach(canvas => {
        const card = canvas.closest('.sensor-card');
        const topic = card ? card.getAttribute('data-topic') : null;
        if (!topic) return;

        let color = colors.default;
        if (topic.includes('temperature')) color = colors.temperature;
        else if (topic.includes('humidity')) color = colors.humidity;
        else if (topic.includes('co2')) color = colors.co2;
        else if (topic.includes('battery')) color = colors.battery;
        else if (topic.includes('voc')) color = colors.voc;
        else if (topic.includes('hcho')) color = colors.hcho;

        const chart = new Chart(canvas.getContext('2d'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: '',
                    data: [],
                    borderColor: color,
                    backgroundColor: color + '20',
                    fill: true,
                    tension: 0.3,
                    pointRadius: 0,
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: { 
                    legend: { display: false },
                    tooltip: { 
                        enabled: true,
                        callbacks: {
                            label: function(context) {
                                return context.parsed.y;
                            }
                        }
                    }
                },
                scales: { 
                    x: { 
                        display: true,
                        ticks: { 
                            color: '#8b949e', 
                            font: { size: 8 },
                            maxTicksLimit: 8,
                            maxRotation: 0
                        },
                        grid: { display: false }
                    },
                    y: { 
                        display: true,
                        grid: { color: 'rgba(255,255,255,0.05)' },
                        ticks: { color: '#8b949e', font: { size: 9 } }
                    }
                },
                animation: false
            }
        });
        charts[topic] = chart;
        chartData[topic] = { period: 'day' };
        
        loadChartData(topic, 'day');
    });

    // ===== ЗАГРУЗКА ДАННЫХ ДЛЯ ГРАФИКА =====
    async function loadChartData(topic, period) {
        if (!period) period = 'day';
        
        try {
            const url = '/api/history.php?topic=' + encodeURIComponent(topic) + '&period=' + period;
            const response = await fetch(url);
            const data = await response.json();
            
            if (!Array.isArray(data) || data.length < 2) return;
            
            const labels = data.map(p => {
                const parts = p.timestamp.split(' ');
                const date = parts[0];
                const time = parts[1] || '';
                
                if (period === 'hour' || period === 'day') {
                    return time ? time.substring(0, 5) : date;
                } else if (period === 'week') {
                    const days = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
                    const d = new Date(p.timestamp);
                    return days[d.getDay()] + ' ' + (time ? time.substring(0, 5) : '');
                } else if (period === 'month') {
                    return date ? date.substring(5) : p.timestamp;
                } else {
                    return date ? date.substring(0, 7) : p.timestamp;
                }
            });
            
            const values = data.map(p => parseFloat(p.value)).filter(v => !isNaN(v));
            if (values.length === 0) return;
            
            // Обновляем обычный график
            const chart = charts[topic];
            if (chart) {
                chart.data.labels = labels;
                chart.data.datasets[0].data = values;
                chart.update('none');
            }

            // Обновляем модальный график, если он открыт для этого топика
            if (modalTopic === topic && modalChartInstance) {
                modalChartInstance.data.labels = labels;
                modalChartInstance.data.datasets[0].data = values;
                modalChartInstance.update('none');
            }
        } catch (error) {
            console.error('Ошибка загрузки графика:', error);
        }
    }

    // ===== ПЕРЕКЛЮЧАТЕЛИ ПЕРИОДОВ =====
    document.addEventListener('click', function(e) {
        const btn = e.target.closest('.period-btn');
        if (!btn) return;
        
        const card = btn.closest('.sensor-card');
        if (card) {
            const topic = card.getAttribute('data-topic');
            if (!topic) return;
            
            const parent = btn.closest('.period-selector');
            if (parent) {
                parent.querySelectorAll('.period-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            }
            
            const period = btn.dataset.period;
            chartData[topic] = { period: period };
            loadChartData(topic, period);
        }

        // Для модального окна
        if (btn.closest('#modalPeriodSelector')) {
            const parent = btn.closest('.modal-period-selector');
            if (parent) {
                parent.querySelectorAll('.period-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            }
            const period = btn.dataset.period;
            if (modalTopic) {
                loadChartData(modalTopic, period);
            }
        }
    });

    // ===== МОДАЛЬНОЕ ОКНО =====
    let modalTopic = null;
    let modalChartInstance = null;

    const modalOverlay = document.getElementById('chartModal');
    const modalCloseBtn = document.getElementById('modalCloseBtn');
    const modalSensorName = document.getElementById('modalSensorName');
    const modalRoom = document.getElementById('modalRoom');
    const modalValue = document.getElementById('modalValue');
    const modalUnit = document.getElementById('modalUnit');
    const modalTimestamp = document.getElementById('modalTimestamp');
    const modalCanvas = document.getElementById('modalChart');

    // Открытие модального окна
    document.querySelectorAll('.fullscreen-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const topic = this.getAttribute('data-topic');
            const name = this.getAttribute('data-name');
            const unit = this.getAttribute('data-unit');
            const value = this.getAttribute('data-value');
            
            // Находим карточку
            const card = this.closest('.sensor-card');
            const room = card ? card.querySelector('.sensor-topic small')?.textContent?.replace(/[()]/g, '') || '' : '';
            const timeEl = card ? card.querySelector('.sensor-timestamp') : null;
            const time = timeEl ? timeEl.textContent.replace('🕔', '').trim() : '';

            // Заполняем информацию
            modalSensorName.textContent = name;
            modalRoom.textContent = room ? '(' + room + ')' : '';
            modalValue.textContent = value;
            modalUnit.textContent = unit;
            modalTimestamp.textContent = '🕔 ' + time;

            modalTopic = topic;

            // Получаем цвет для датчика
            let color = colors.default;
            if (topic.includes('temperature')) color = colors.temperature;
            else if (topic.includes('humidity')) color = colors.humidity;
            else if (topic.includes('co2')) color = colors.co2;
            else if (topic.includes('battery')) color = colors.battery;
            else if (topic.includes('voc')) color = colors.voc;
            else if (topic.includes('hcho')) color = colors.hcho;

            // Создаём график в модалке
            if (modalChartInstance) {
                modalChartInstance.destroy();
                modalChartInstance = null;
            }

            const ctx = modalCanvas.getContext('2d');
            modalChartInstance = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: name,
                        data: [],
                        borderColor: color,
                        backgroundColor: color + '25',
                        fill: true,
                        tension: 0.3,
                        pointRadius: 2,
                        pointBackgroundColor: color,
                        borderWidth: 2.5
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { 
                            display: true,
                            labels: { color: '#e6edf3', font: { size: 12 } }
                        },
                        tooltip: {
                            enabled: true,
                            callbacks: {
                                label: function(context) {
                                    return context.parsed.y + ' ' + unit;
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            display: true,
                            ticks: {
                                color: '#8b949e',
                                font: { size: 11 },
                                maxTicksLimit: 15,
                                maxRotation: 30
                            },
                            grid: { display: false }
                        },
                        y: {
                            display: true,
                            grid: { color: 'rgba(255,255,255,0.07)' },
                            ticks: { color: '#8b949e', font: { size: 11 } }
                        }
                    },
                    animation: {
                        duration: 500
                    }
                }
            });

            // Загружаем данные для текущего периода
            const activePeriod = document.querySelector('#modalPeriodSelector .period-btn.active');
            const period = activePeriod ? activePeriod.dataset.period : 'day';
            loadChartData(topic, period);

            // Показываем модалку
            modalOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    });

    // Закрытие модалки
    function closeModal() {
        modalOverlay.classList.remove('active');
        document.body.style.overflow = '';
        if (modalChartInstance) {
            modalChartInstance.destroy();
            modalChartInstance = null;
        }
        modalTopic = null;
    }

    modalCloseBtn.addEventListener('click', closeModal);
    modalOverlay.addEventListener('click', function(e) {
        if (e.target === this) closeModal();
    });
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') closeModal();
    });

    // ===== ОБНОВЛЕНИЕ ЗНАЧЕНИЙ В РЕАЛЬНОМ ВРЕМЕНИ =====
    async function updateValues() {
        try {
            const response = await fetch('/api/live_data.php');
            const data = await response.json();
            if (!data.topics) return;
            
            data.topics.forEach(item => {
                const card = document.querySelector(`.sensor-card[data-topic="${item.topic}"]`);
                if (!card) return;
                
                const valueEl = card.querySelector('.value');
                const timeEl = card.querySelector('.sensor-timestamp');
                
                if (valueEl) {
                    valueEl.textContent = item.value;
                    
                    if (item.topic.includes('temperature')) {
                        const val = parseFloat(item.value);
                        valueEl.classList.remove('success', 'warning', 'error');
                        if (val > 30) valueEl.classList.add('error');
                        else if (val > 25) valueEl.classList.add('warning');
                        else valueEl.classList.add('success');
                    }
                }
                if (timeEl && timeEl.textContent.includes('🕔')) {
                    const newTimeEl = card.querySelector('.sensor-timestamp');
                    if (newTimeEl && !newTimeEl.textContent.includes('📅')) {
                        newTimeEl.innerHTML = '🕔 ' + item.timestamp;
                    }
                }

                // Обновляем модалку, если она открыта для этого топика
                if (modalTopic === item.topic) {
                    modalValue.textContent = item.value;
                    modalTimestamp.textContent = '🕔 ' + item.timestamp;
                }
            });
        } catch (error) {
            console.error('Ошибка обновления:', error);
        }
    }

    // ===== ЗАПУСК =====
    document.addEventListener('DOMContentLoaded', () => {
        updateValues();
        setInterval(updateValues, 30000);
        setInterval(() => {
            Object.keys(charts).forEach(topic => {
                const period = chartData[topic]?.period || 'day';
                loadChartData(topic, period);
            });
        }, 120000);
    });

    // ===== КНОПКИ ОЧИСТКИ =====
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.clear-history-btn').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                const topic = this.getAttribute('data-topic');
                if (!topic) {
                    alert('❌ Топик не найден!');
                    return;
                }
                if (!confirm(`⚠️ Очистить историю для датчика:\n"${topic}"?\nЭто действие НЕЛЬЗЯ отменить!`)) {
                    return;
                }
                fetch('/api/clear_history.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ topic: topic })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('✅ История для "' + topic + '" очищена!');
                        location.reload();
                    } else {
                        alert('❌ Ошибка: ' + (data.error || 'Неизвестная ошибка'));
                    }
                })
                .catch(err => {
                    console.error('❌ Ошибка запроса:', err);
                    alert('❌ Ошибка: ' + err.message);
                });
            });
        });
    });
</script>

</body>
</html>
