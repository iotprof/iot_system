-- Таблица отметок об отправленных письмах по правилам автоматизации.
--
-- Зачем: чтобы одно и то же правило не писало письмо каждый час, пока условие
-- держится. Скрипт рассылки (cron_automation_emails.php) смотрит сюда: если за
-- текущий час по правилу уже отправляли — молчит.
--
-- Создавать под root. Учётка сайта iot_app права CREATE не имеет (так и задумано —
-- 29.09.2026 права урезаны), поэтому запрос «CREATE TABLE IF NOT EXISTS» из скрипта
-- падал бы с «1142 CREATE command denied» даже при живой таблице, и в лог каждую
-- минуту летела ложная тревога. 12.10.2026 скрипт научили проверять таблицу чтением,
-- а создание оставили администратору:
--
--     mysql iot_db < /var/www/html/iot/db/automation_email_sent.sql
--
-- Таблица уже существует на малине (создана ранее), этот файл — чтобы можно было
-- восстановить её после переустановки или случайного удаления.

CREATE TABLE IF NOT EXISTS automation_email_sent (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_id INT NOT NULL,
    trigger_topic VARCHAR(255),
    trigger_value TEXT,
    recipient VARCHAR(255) NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    hour_key VARCHAR(50),
    INDEX idx_rule_hour (rule_id, hour_key),
    FOREIGN KEY (rule_id) REFERENCES automations(id) ON DELETE CASCADE
);
