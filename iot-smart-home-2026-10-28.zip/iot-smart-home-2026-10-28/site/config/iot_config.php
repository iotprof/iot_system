<?php
/**
 * Единая точка получения секретов для всего IoT.
 * Файл лежит ВНЕ корня сайта (/var/www/html/iot/config, а сайт — public_html),
 * поэтому по HTTP недоступен. Секреты — в /etc/iot/credentials.ini (640 root:www-data).
 */
if (defined('IOT_CONFIG_LOADED')) { return; }
define('IOT_CONFIG_LOADED', true);

define('IOT_CONF_FILE', '/etc/iot/credentials.ini');
$__iot_conf = @parse_ini_file(IOT_CONF_FILE, true);
if ($__iot_conf === false) {
    error_log('iot_config.php: не могу прочитать ' . IOT_CONF_FILE);
    die('Конфигурация недоступна: проверь /etc/iot/credentials.ini (права 640 root:www-data)');
}

define('IOT_DB_DSN',  $__iot_conf['db']['dsn']);
define('IOT_DB_HOST', $__iot_conf['db']['host']);
define('IOT_DB_NAME', $__iot_conf['db']['name']);
define('IOT_DB_USER', $__iot_conf['db']['user']);
define('IOT_DB_PASS', $__iot_conf['db']['password']);
define('IOT_DB_ADMIN_USER', $__iot_conf['db']['admin_user']);
define('IOT_DB_ADMIN_PASS', $__iot_conf['db']['admin_password']);

define('IOT_MQTT_HOST', $__iot_conf['mqtt']['host']);
define('IOT_MQTT_PORT', $__iot_conf['mqtt']['port']);
define('IOT_MQTT_USER', $__iot_conf['mqtt']['user']);
define('IOT_MQTT_PASS', $__iot_conf['mqtt']['password']);

define('IOT_PANEL_USER', $__iot_conf['panel']['user']);
define('IOT_PANEL_HASH', $__iot_conf['panel']['password_hash']);

define('IOT_AI_ENABLED',  (int)$__iot_conf['ai']['enabled']);
define('IOT_AI_PROVIDER', $__iot_conf['ai']['provider']);
define('IOT_AI_BASE_URL', $__iot_conf['ai']['base_url']);
define('IOT_AI_API_KEY',  $__iot_conf['ai']['api_key']);
define('IOT_AI_MODEL',    $__iot_conf['ai']['model']);

/** PDO к базе домена. Использовать везде вместо своих new PDO(...). */
function iot_pdo(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(IOT_DB_DSN, IOT_DB_USER, IOT_DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    return $pdo;
}

/** Есть ли активная сессия админа (панель). */
function iot_require_admin(): void {
    if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
    if (empty($_SESSION['iot_admin'])) {
        header('Location: /admin/sensors.php');
        exit;
    }
}
