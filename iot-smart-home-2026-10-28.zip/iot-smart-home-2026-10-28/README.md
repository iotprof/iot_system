# Умный дом на Raspberry Pi — рабочий проект

Самописная домашняя автоматизация: датчики Zigbee → MQTT → база → движок правил → веб-панель.
Всё, что нужно, чтобы поднять такую же систему с нуля, и чтобы было понятно, как она устроена.

> **Это публичная копия архива.** Пароли заменены на заглушки `CHANGE_ME_*`:
> перед запуском впиши свои в `secrets/credentials.ini` и `secrets/credentials.env`.
> Рабочие пароли этой системы в публичную копию не попадают.

## Как устроено (одной строкой на звено)

```
Zigbee-устройства
      │  (радио)
zigbee2mqtt  ──►  Mosquitto (MQTT-брокер, 127.0.0.1:1883, с логином)
                      │
        ┌─────────────┴───────────────┐
        │                             │
 mqtt_to_mysql.py                 mqtt_listener.php
 (логгер: раскладывает JSON      (движок правил: слушает брокер,
  в таблицы sensor_data/          сравнивает с правилами из таблицы
  sensor_history)                 automations, публикует команды в .../set)
        │                             │
        └────────► MariaDB ◄──────────┘
                      │
              веб-панель (nginx + PHP 8.2)
```

Ключевая мысль: **брокер — шина событий, база — состояние и правила**. Движок не опрашивает
базу раз в секунду, а подписывается на темы и реагирует сразу (переделка 12.10.2026: реакция
была до 1 с, стала мгновенной, расход процессора упал примерно на 20 %).

## Состав архива

```
site/public_html/          корень сайта (nginx root)
  index.php                главная: карточки датчиков, графики
  admin/
    sensors.php            вход в панель + справочник датчиков (имя, комната, группа, иконка)
    logic.php              редактор правил автоматизации (таблица automations)
    mqtt_listener.php      ДВИЖОК ПРАВИЛ (systemd iot-automation, от www-data)
    mqtt_client.php        свой клиент MQTT 3.1.1 на сокетах (только для движка)
    mqtt_to_mysql.py       ЛОГГЕР MQTT → БД (systemd mqtt-to-mysql, от mazzick)
    batteries.php          состояние элементов питания
    automation_log.php     журнал срабатываний
    anomalies.php          модуль аномалий (в оригинале выключен сознательно)
  include/battery_lib.php  общая логика «села/не села батарейка»
  css/, icons/, api/       оформление и мелкие HTTP-эндпоинты
site/config/iot_config.php общий конфиг PHP: подключение к БД и константы IOT_*
site/db/*.sql              таблицы, которые создаёт ТОЛЬКО администратор БД
cron/cron_*.php            задачи в обход движка (кормушка, нагрев, свет, письма)
cron/crontab_mazzick.txt   задания пользователя
cron/crontab_root.txt      задания root
scripts/                   healthcheck.sh, iot_watchdog.sh, check_battery.py,
                           iot_anomaly.py, push_sender.py, backup.sh, clean_iot_db.sh
bash_scripts/              log_analyzer.sh, rpi_monitor.sh, alert_dispatcher.py
systemd/                   4 юнита: iot-automation, mqtt-to-mysql, iot-anomaly, zigbee2mqtt
nginx/iot.conf             конфиг сайта (доступ по подсети + запрет не-веб файлов)
mosquitto/                 mosquitto.conf и conf.d/mqtt.conf (логин обязателен)
zigbee2mqtt/configuration.yaml  конфиг Z2M (сеть Zigbee, MQTT, список устройств)
secrets/credentials.ini    все секреты приложения (права 640, владелец root:www-data)
secrets/credentials.env    те же секреты для shell и cron (640, root:mazzick)
db/schema_iot_db.sql       СТРУКТУРА базы (CREATE TABLE, триггеры, процедуры) — без данных
docs/article.html          статья «что обновили 28.10.2026» (для блога)
docs/project.html          это же описание проекта в виде страницы (для читателя архива)
logrotate-*.conf           ротация журналов
```

**Чего в архиве нет и почему:**
- данные датчиков (`sensor_history`, `rpi_monitor` — сотни тысяч строк). Оставлена только схема:
  структуру видно, а накопленную историю при развёртывании всё равно собирать заново.
- `node_modules` zigbee2mqtt, `vendor`-библиотеки ставятся пакетным менеджером.
- логи, бэкапы, карантин мусора — это не проект, а следы эксплуатации.

## Пароли (новые)

| Что | Логин | Пароль | Где лежит |
|---|---|---|---|
| База, приложение (`iot_app`) | `iot_app` | `CHANGE_ME_DB_PASSWORD` |
| База, администратор | `iot_admin` | `CHANGE_ME_DB_ADMIN_PASSWORD` |
| MQTT-брокер | `iot` | `CHANGE_ME_MQTT_PASSWORD` |
| Панель управления (вход) | `mazzick` | `CHANGE_ME_PANEL_PASSWORD` |
| SMTP (почта, фиктивный) | `user@example.com` | `CHANGE_ME_SMTP_PASSWORD` |

Все они уже прописаны в `secrets/credentials.ini`, `secrets/credentials.env` и в
`zigbee2mqtt/configuration.yaml`. Пароль панели хранится в `credentials.ini` **хешем**
(bcrypt), в открытом виде его в проекте нет — он только в этой таблице.

Почта: адреса в файлах заменены на `@example.com`, пароль SMTP фиктивный. Чтобы работали
письма (сторож, батарейки, тревоги), впиши свои `smtp.user` и `smtp.password`.

## Как развернуть

1. **Пакеты.** `sudo apt install nginx php8.2-fpm php8.2-mysql mariadb-server mosquitto mosquitto-clients python3-venv nodejs npm`
2. **База.** `sudo mysql -e "CREATE DATABASE iot_db CHARACTER SET utf8mb4;"` → `sudo mysql iot_db < db/schema_iot_db.sql`
   Затем завести двух пользователей: прикладного (`iot_app` — только SELECT/INSERT/UPDATE/DELETE/REFERENCES/INDEX)
   и администратора (для миграций). Пароли — из таблицы выше.
3. **Секреты.** `sudo mkdir -p /etc/iot && sudo install -m 640 -o root -g www-data secrets/credentials.ini /etc/iot/credentials.ini`
   и так же `credentials.env` (владелец `root:mazzick`). Подставь свои пароли, если менял.
4. **Сайт.** Скопировать `site/public_html`, `site/config`, `site/db` в `/var/www/html/iot/`,
   поправить пути в `nginx/iot.conf` и включить сайт (`ln -s` в `sites-enabled`, `nginx -t`, `systemctl reload nginx`).
5. **Службы.** `systemd/*.service` → `/etc/systemd/system/`, затем `systemctl daemon-reload`
   и `systemctl enable --now iot-automation mqtt-to-mysql`.
6. **MQTT.** `mosquitto/` → `/etc/mosquitto/`, пользователей завести через `mosquitto_passwd`
   (`mosquitto_passwd -c /etc/mosquitto/passwd iot`). Анонимный доступ не нужен и не должен быть включён.
7. **zigbee2mqtt.** `zigbee2mqtt/configuration.yaml` в каталог Z2M, вписать сетевой ключ
   (`advanced.network_key`) и координатор в `serial.port`.
8. **Cron и сторож.** Задания из `cron/crontab_*.txt` (`crontab -e` для пользователя и для root),
   `scripts/healthcheck.sh` в `~/`, `crontab: 5 * * * * ~/iot_watchdog.sh`.
9. **Проверка.** `systemctl is-active iot-automation mqtt-to-mysql mosquitto zigbee2mqtt mariadb nginx`
   — все `active`; свежие строки в `sensor_data`; `journalctl -u iot-automation -n 20` без ошибок.

## Группировка датчиков и правил (добавлено 28.10.2026)

Было: все датчики и все правила одной кучей карточек. Стало: **сворачиваемые группы**.

- На странице датчиков группа берётся из поля «Группа» справочника. Если поле пустое — из
  комнаты, а если и её нет, используется группа любого другого поля того же устройства
  (поставил группу батарейке — вся устройство переехало туда же).
- Технические топики (`linkquality`, калибровки, команды `/set`, полный JSON устройства)
  собраны в отдельную секцию **«Служебные»** — она скрыта по умолчанию и включается галочкой.
  Иначе они и создают «кучу»: 63 служебных против 61 настоящего датчика.
- В карточке датчика видно последнее значение и когда оно пришло — сразу понятно, живой он или молчит.
- В правилах группа хранится в колонке `automations.group_name`. Секция показывает счётчик
  «✅ включено / ❌ выключено».
- Состояние «свёрнуто/развёрнуто» каждая группа помнит в браузере (`localStorage`), есть кнопки
  «Раскрыть все / Свернуть все» и поиск по имени, комнате и топику.

Как поменять принадлежность: страница датчиков → «Редактировать» → поле «Группа»;
для правил — «Группа правила» в форме. Код правок помечен комментарием `28.10.2026`.

## Грабли, которые дорого стоили (чтобы не наступить снова)

1. **Милливольты против вольт.** У батарейных Zigbee-устройств `voltage` — это мВ (2500…3000),
   у розетки с измерением мощности то же поле — вольты сети (207…253). Пороги в `battery_spec`
   записаны в вольтах, сравнивать надо с мВ (умножать на 1000).
2. **`output: json`.** zigbee2mqtt публикует одно сообщение на устройство; отдельных тем
   `zigbee2mqtt/<имя>/поле` в брокере НЕТ. Движок обязан разбирать JSON и проверять правила по
   каждому полю, иначе правила на датчики молча не срабатывают (по расписанию работают, по топику нет).
3. **Payload обязан соответствовать топику.** Для многоканальных реле: либо `.../set/state_l3` +
   `{"state":"ON"}`, либо `.../set` + `{"state_l3":"ON"}`. Перепутал — в журнале «успешно отправлено»,
   а реле молчит.
4. **`condition_duration`** (выдержка «условие держится N секунд») должна проверяться и у простых
   триггерных правил, иначе кран закрывается в ту же секунду, когда открылся.
5. **Приложение не должно создавать таблицы.** У прикладной учётки нет CREATE/ALTER — так и задумано.
   Наличие таблицы проверять чтением, а создавать её под администратором из `db/*.sql`.
6. **Состояние в памяти процесса.** Отложенные действия и ожидания подтверждений переживают
   перезапуск только потому, что пишутся в таблицу `pending_actions`.
7. **Справочник датчиков vs `sensor_data`.** Топики, которые перестали приходить, остаются в базе
   навсегда: в панели датчик выглядит «живым». Поэтому у карточки теперь есть возраст значения.

## Откат

- `site/public_html/admin/sensors.php` и `logic.php` — версия до 28.10.2026 лежит в
  `przorka_backup/groups_20261028/*.orig` на самой малине.
- Колонку `group_name` можно убрать: `ALTER TABLE automations DROP COLUMN group_name;`
  (сами правила при этом не пострадают).
- Всё остальное — обычные текстовые конфиги, откат = вернуть файл и `systemctl restart`.
