#!/bin/bash
# iot_watchdog.sh — ежечасная проверка умного дома с письмом при проблемах.
#
# Логика:
#   - запускает healthcheck.sh, собирает строки [FAIL];
#   - если проблем нет — пишет строку в лог и молчит (никакого спама);
#   - если проблемы есть — письмо владельцу. Повторно о той же самой проблеме
#     не пишет: шлёт, только если набор проблем изменился или прошло больше 12 часов.
#
# Тест канала:  IOT_WATCHDOG_TEST=1 /home/mazzick/iot_watchdog.sh
set -u

HC=/home/mazzick/healthcheck.sh
LOG=/home/mazzick/iot_watchdog.log
STATE_DIR=/home/mazzick/.iot_watchdog
STATE=$STATE_DIR/last_problem.txt
RESEND_AFTER_SEC=43200          # 12 часов
RECIPIENT="${IOT_WATCHDOG_TO:-it@example.com}"

mkdir -p "$STATE_DIR" 2>/dev/null || STATE_DIR=/tmp

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; }

send_mail() {  # send_mail "тема" "тело"
    local subject="$1" body="$2"
    [ -f /etc/iot/credentials.env ] && . /etc/iot/credentials.env
    local from="${IOT_SMTP_USER:-iot@localhost}"
    {
        echo "To: $RECIPIENT"
        echo "From: Умный дом <$from>"
        echo "Subject: $subject"
        echo "MIME-Version: 1.0"
        echo "Content-Type: text/plain; charset=utf-8"
        echo
        printf '%s\n' "$body"
    } | /usr/bin/msmtp -t && return 0 || return 1
}

# --- тестовое письмо ---
if [ "${IOT_WATCHDOG_TEST:-0}" = "1" ]; then
    if send_mail "[Умный дом] проверка связи" "Тестовое письмо сторожа.
Если ты его видишь — канал уведомлений работает.
Проверка запускается каждый час: /home/mazzick/iot_watchdog.sh
Полный прогон проверок: /home/mazzick/healthcheck.sh"; then
        log "ТЕСТ: письмо отправлено на $RECIPIENT"
        echo "тестовое письмо отправлено на $RECIPIENT"
    else
        log "ТЕСТ: письмо НЕ отправлено"
        echo "письмо не ушло (смотреть ~/.msmtp.log)"
        exit 1
    fi
    exit 0
fi

# --- обычная проверка ---
OUT=$(bash "$HC" 2>&1)
RC=$?
FAILS=$(printf '%s\n' "$OUT" | grep '^  \[FAIL\]' || true)
N=$(printf '%s' "$FAILS" | grep -c '\[FAIL\]' || true)
[ -z "$FAILS" ] && N=0

if [ "$N" -eq 0 ] && [ "${RC:-0}" -eq 0 ]; then
    log "ок: проблем нет"
    echo "проблем нет"
    # сбрасываем состояние, чтобы следующая проблема пришла письмом сразу
    rm -f "$STATE"
    exit 0
fi

# сигнатура проблем — чтобы не писать одно и то же каждый час
SIG=$(printf '%s' "$FAILS" | md5sum | cut -d' ' -f1)
NOW=$(date +%s)
SEND=1
if [ -f "$STATE" ]; then
    PREV_SIG=$(head -1 "$STATE" 2>/dev/null)
    PREV_TS=$(sed -n '2p' "$STATE" 2>/dev/null)
    if [ "$PREV_SIG" = "$SIG" ] && [ -n "${PREV_TS:-}" ] && [ $((NOW - PREV_TS)) -lt $RESEND_AFTER_SEC ]; then
        SEND=0
    fi
fi

if [ "$SEND" -eq 1 ]; then
    BODY="Проверка умного дома нашла проблемы: $N

$FAILS

Полный отчёт по проверкам — ниже.

--------------------------------------------------------------------
$(printf '%s\n' "$OUT")

--------------------------------------------------------------------
Как посмотреть руками:
  plink -batch -pw <пароль> mazzick@192.168.88.237 'bash /home/mazzick/healthcheck.sh'
Панель: http://192.168.88.237/admin/anomalies.php
Лог сторожа: /var/log/iot_watchdog.log"
    if send_mail "[Умный дом] проблем: $N" "$BODY"; then
        log "ПРОБЛЕМЫ ($N): письмо отправлено"
        printf '%s\n%s\n' "$SIG" "$NOW" > "$STATE"
    else
        log "ПРОБЛЕМЫ ($N): письмо НЕ ушло"
    fi
else
    log "ПРОБЛЕМЫ ($N): те же, что и раньше — письмо не дублируем"
fi

printf '%s' "$FAILS"
exit 0
