#!/usr/bin/env python3
"""
iot_anomaly.py — сервис сбора данных и анализа аномалий для умного дома.

Что делает каждые 15 секунд:
  1. По каждой включённой карточке (anomaly_watchers) снимает текущее значение её топика
     из sensor_data и кладёт точку в anomaly_samples (не чаще collect_interval).
  2. Считает норму по окну window_hours (медиана, MAD-сигма, min/max) и ищет аномалии:
       limit_low / limit_high — жёсткие пределы из карточки,
       dip / spike           — выход за spike_factor сигм от нормы,
       no_data               — данные перестали поступать совсем.
     Найденное пишет в anomaly_events (с cooldown, чтобы не спамить).
  3. Забирает из anomaly_requests невыполненные запросы «проанализируй нейросетью»:
     собирает статистику + список аномалий, подставляет её в промпт карточки,
     отправляет в нейросеть и кладёт ответ в anomaly_reports.

Настройки (БД, MQTT, ИИ) — из /etc/iot/credentials.env и /etc/iot/credentials.ini.
Запускается как systemd-сервис iot-anomaly.service от пользователя mazzick.
"""
import configparser
import logging
import os
import statistics
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta

import pymysql.cursors

LOOP_SECONDS = 15
SEVERITY_ORDER = {'info': 0, 'warning': 1, 'critical': 2}
LOG_FILE = '/home/mazzick/iot_anomaly.log'
CONF_INI = '/etc/iot/credentials.ini'

logger = logging.getLogger('iot_anomaly')
INI = None


def setup_logging():
    logger.setLevel(logging.INFO)
    fmt = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    fh = logging.FileHandler(LOG_FILE)
    fh.setFormatter(fmt)
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    logger.addHandler(fh)
    logger.addHandler(sh)


def load_ini():
    cp = configparser.ConfigParser()
    if not cp.read(CONF_INI):
        logger.warning('не прочитал %s — работаю на переменных окружения', CONF_INI)
    return cp


def send_mail(ini, to_addr, subject, body):
    """Письмо об аномалии через msmtp (настроен в системе как sendmail)."""
    import subprocess as sp
    smtp = ini['smtp'] if ini.has_section('smtp') else {}
    sender = smtp.get('from') or smtp.get('user') or 'iot@localhost'
    msg = (f"To: {to_addr}\n"
           f"From: IoT Аномалии <{sender}>\n"
           f"Subject: {subject}\n"
           f"MIME-Version: 1.0\n"
           f"Content-Type: text/plain; charset=utf-8\n\n"
           f"{body}\n")
    try:
        p = sp.run(['/usr/bin/msmtp', '-t'], input=msg.encode('utf-8'),
                   capture_output=True, timeout=30)
        if p.returncode == 0:
            logger.info('письмо об аномалии отправлено на %s', to_addr)
            return True
        logger.error('msmtp вернул %s: %s', p.returncode, p.stderr.decode('utf-8', 'replace')[:200])
    except Exception as e:
        logger.error('письмо не ушло: %s: %s', type(e).__name__, e)
    return False


def db_connect():
    return pymysql.connect(
        host=os.environ.get('IOT_DB_HOST', '127.0.0.1'),
        user=os.environ.get('IOT_DB_USER', 'iot_app'),
        password=os.environ.get('IOT_DB_PASS'),
        database=os.environ.get('IOT_DB_NAME', 'iot_db'),
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=True,
    )


# ----------------------------------------------------------------------------- сбор точек

def collect_samples(conn, now):
    """Снять текущие значения по карточкам. Возвращает число добавленных точек."""
    added = 0
    with conn.cursor() as cur:
        cur.execute("""
            SELECT w.id, w.name, w.topic, w.collect_interval, w.last_sample_at
            FROM anomaly_watchers w
            WHERE w.enabled = 1
        """)
        watchers = cur.fetchall()

        for w in watchers:
            due = True
            if w['last_sample_at']:
                due = (now - w['last_sample_at']).total_seconds() >= max(10, int(w['collect_interval']))
            if not due:
                continue

            cur.execute("SELECT value, timestamp FROM sensor_data WHERE topic = %s", (w['topic'],))
            row = cur.fetchone()
            if not row:
                continue
            raw = row['value']
            try:
                value = float(str(raw).strip().strip('"'))
            except (TypeError, ValueError):
                logger.debug('карточка %s: значение %r не число, пропуск', w['name'], raw)
                continue

            cur.execute(
                "INSERT INTO anomaly_samples (watcher_id, value, taken_at) VALUES (%s, %s, %s)",
                (w['id'], value, row['timestamp'] or now))
            cur.execute("""
                UPDATE anomaly_watchers
                   SET last_sample_at = NOW(),
                       samples_count = (SELECT COUNT(*) FROM anomaly_samples WHERE watcher_id = %s),
                       status = CASE WHEN status = 'collecting' AND
                                     (SELECT COUNT(*) FROM anomaly_samples WHERE watcher_id = %s) >= min_samples
                                     THEN 'ready' ELSE status END
                 WHERE id = %s
            """, (w['id'], w['id'], w['id']))
            added += 1
    return added


# ----------------------------------------------------------------------------- анализ

KIND_LABELS = {
    'limit_low': 'напряжение/значение ниже предела',
    'limit_high': 'значение выше предела',
    'dip': 'просадка относительно нормы',
    'spike': 'выброс относительно нормы',
    'no_data': 'данные не поступают',
}


def kind_labels(kind):
    return KIND_LABELS.get(kind, kind)


def median_abs_dev(values):
    """Устойчивая «сигма»: 1.4826 * MAD."""
    med = statistics.median(values)
    mad = statistics.median([abs(v - med) for v in values])
    return med, 1.4826 * mad


def analyse(conn, now):
    """Поиск аномалий по всем карточкам. Возвращает число новых событий."""
    found = 0
    with conn.cursor() as cur:
        cur.execute("SELECT * FROM anomaly_watchers WHERE enabled = 1")
        watchers = cur.fetchall()

        for w in watchers:
            wid = w['id']
            since = now - timedelta(hours=int(w['window_hours']))
            cur.execute("""
                SELECT value, taken_at FROM anomaly_samples
                 WHERE watcher_id = %s AND taken_at >= %s ORDER BY taken_at
            """, (wid, since))
            rows = cur.fetchall()
            values = [float(r['value']) for r in rows]

            if len(values) < int(w['min_samples']):
                continue

            med, sigma = median_abs_dev(values)
            last = values[-1]
            last_at = rows[-1]['taken_at']
            events = []

            # жёсткие пределы
            if w['limit_min'] is not None and last < float(w['limit_min']):
                events.append(('limit_low', 'critical',
                               f"ниже предела {w['limit_min']}", last - float(w['limit_min'])))
            if w['limit_max'] is not None and last > float(w['limit_max']):
                events.append(('limit_high', 'critical',
                               f"выше предела {w['limit_max']}", last - float(w['limit_max'])))

            # порог «нормального» отклонения от нормы
            k = float(w['spike_factor'])
            if sigma > 0:
                threshold = k * sigma
                how = f"сигма {sigma:.3f}"
            else:
                # Значения не меняются: сигма нулевая. Порог нельзя брать от нуля,
                # иначе аномалией станет любой шаг округления (мощность 19 -> 20 Вт).
                # Берём шаг квантования датчика и требуем отклонение не меньше трёх шагов.
                uniq = sorted(set(values))
                steps = [b - a for a, b in zip(uniq, uniq[1:]) if b - a > 0]
                step = min(steps) if steps else max(abs(med) * 0.02, 0.02)
                threshold = max(3 * step, abs(med) * 0.02, 0.02)
                how = f"норма без разброса, шаг датчика {step:g}, порог {threshold:g}"

            if last > med + threshold:
                events.append(('spike', 'warning',
                               f"выброс вверх: {last:.2f} при норме {med:.2f} ({how})",
                               last - med))
            elif last < med - threshold:
                events.append(('dip', 'warning',
                               f"просадка: {last:.2f} при норме {med:.2f} ({how})",
                               last - med))

            # пропали данные
            gap_limit = int(w['collect_interval']) * int(w['gap_intervals'])
            if (now - last_at).total_seconds() > gap_limit:
                events.append(('no_data', 'warning',
                               f"данные не поступают {(now - last_at).total_seconds() / 60:.0f} мин",
                               None))

            for kind, severity, note, deviation in events:
                cur.execute("""
                    SELECT id FROM anomaly_events
                     WHERE watcher_id = %s AND kind = %s AND detected_at > NOW() - INTERVAL %s SECOND
                     LIMIT 1
                """, (wid, kind, int(w['cooldown_events'])))
                if cur.fetchone():
                    continue
                cur.execute("""
                    INSERT INTO anomaly_events (watcher_id, kind, severity, value, baseline, deviation, note)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """, (wid, kind, severity, last, med, deviation, note[:250]))
                logger.info('аномалия [%s] %s: %s', kind, w['name'], note)
                found += 1

                # письмо, если в карточке задан адрес и важность не ниже порога
                to_addr = (w.get('notify_email') or '').strip()
                min_sev = (w.get('notify_min_severity') or 'critical')
                if to_addr and SEVERITY_ORDER.get(severity, 1) >= SEVERITY_ORDER.get(min_sev, 2):
                    subject = f"[Умный дом] {kind_labels(kind)}: {w['name']}"
                    body = (
                        f"АНОМАЛИЯ В ДОМЕ\n\n"
                        f"Карточка:  {w['name']}\n"
                        f"Топик:     {w['topic']}\n"
                        f"Тип:       {kind_labels(kind)} ({severity})\n"
                        f"Значение:  {last}\n"
                        f"Норма:     {med}\n"
                        f"Отклонение:{(' %+.2f' % deviation) if deviation is not None else ' —'}\n"
                        f"Пояснение: {note}\n"
                        f"Время:     {now:%d.%m.%Y %H:%M:%S}\n\n"
                        f"Живые данные и отчёты: http://192.168.88.237/admin/anomalies.php\n"
                        f"Порог уведомлений в карточке: {min_sev}\n"
                    )
                    send_mail(INI, to_addr, subject, body)
    return found


# ----------------------------------------------------------------------------- запрос в нейросеть

def build_summary(conn, w, now):
    """Статистика по карточке за окно + список аномалий. Возвращает (текст, from, to, n_samples, n_events)."""
    since = now - timedelta(hours=int(w['window_hours']))
    with conn.cursor() as cur:
        cur.execute("""
            SELECT value, taken_at FROM anomaly_samples
             WHERE watcher_id = %s AND taken_at >= %s ORDER BY taken_at
        """, (w['id'], since))
        rows = cur.fetchall()
        cur.execute("""
            SELECT kind, severity, value, baseline, note, detected_at FROM anomaly_events
             WHERE watcher_id = %s AND detected_at >= %s ORDER BY detected_at
        """, (w['id'], since))
        events = cur.fetchall()

    if not rows:
        return None, since, now, 0, 0

    values = [float(r['value']) for r in rows]
    med, sigma = median_abs_dev(values)
    per_day = {}
    for r in rows:
        day = r['taken_at'].strftime('%Y-%m-%d')
        per_day.setdefault(day, []).append(float(r['value']))

    lines = [
        f"Карточка: {w['name']}",
        f"Топик: {w['topic']}",
        f"Единица: {w['unit'] or '—'}",
        f"Период: {since:%d.%m.%Y %H:%M} — {now:%d.%m.%Y %H:%M} ({int(w['window_hours'])} ч)",
        f"Точек собрано: {len(values)} (интервал съёма {w['collect_interval']} с)",
        "",
        "=== Статистика ===",
        f"минимум:  {min(values):.2f}",
        f"максимум: {max(values):.2f}",
        f"среднее:  {statistics.fmean(values):.2f}",
        f"медиана:  {med:.2f}",
        f"сигма (MAD): {sigma:.3f}",
        f"размах:   {max(values) - min(values):.2f}",
        f"пределы карточки: {w['limit_min']} … {w['limit_max']}",
        "",
        "=== По суткам (мин / среднее / макс) ===",
    ]
    for day in sorted(per_day):
        v = per_day[day]
        lines.append(f"{day}: {min(v):.2f} / {statistics.fmean(v):.2f} / {max(v):.2f}  (точек {len(v)})")

    lines += ["", f"=== Автоматически найденные аномалии: {len(events)} ==="]
    if events:
        for e in events[:120]:
            lines.append(f"{e['detected_at']:%d.%m %H:%M}  {e['kind']} ({e['severity']})  "
                         f"значение {e['value']}  норма {e['baseline']}  {e['note']}")
    else:
        lines.append("нет — все значения в пределах нормы")

    return '\n'.join(lines), since, now, len(values), len(events)


def ask_ai(text, system_prompt, ini, watcher):
    """Отправить запрос в нейросеть. Пусто в настройках = вернуть пояснение."""
    api = ini['ai'] if ini.has_section('ai') else {}
    provider = (watcher.get('ai_provider') or api.get('provider') or 'disabled').strip()
    enabled = int(api.get('enabled') or 0)

    if provider in ('', 'disabled') or not enabled:
        return ('ok_disabled',
                'Анализ нейросетью пока не подключён.\n\n'
                'Данные собраны и статистика посчитана (см. ниже). Чтобы включить разбор ИИ:\n'
                '1) в /etc/iot/credentials.ini в секции [ai] указать enabled = 1, provider (openai/mistral/локальный), '
                'base_url, model и api_key;\n'
                '2) нажать «Проанализировать» на карточке заново.',
                provider or 'disabled', '')

    if provider not in ('openai', 'openai-compatible', 'ollama', 'mistral'):
        return ('failed', '', provider, f'провайдер {provider} пока не поддержан')

    base = (api.get('base_url') or 'https://api.openai.com/v1').rstrip('/')
    model = watcher.get('ai_model') or api.get('model') or 'gpt-4o-mini'
    key = api.get('api_key') or ''

    payload = {
        'model': model,
        'messages': [
            {'role': 'system', 'content': system_prompt},
            {'role': 'user', 'content': text},
        ],
        'temperature': 0.2,
    }
    import json
    req = urllib.request.Request(
        base + '/chat/completions',
        data=json.dumps(payload).encode('utf-8'),
        headers={'Content-Type': 'application/json',
                 **({'Authorization': 'Bearer ' + key} if key else {})},
        method='POST')
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        answer = data['choices'][0]['message']['content']
        return 'ok', answer, provider, ''
    except urllib.error.HTTPError as e:
        return 'failed', '', provider, f'HTTP {e.code}: {e.read()[:200].decode("utf-8", "replace")}'
    except Exception as e:
        return 'failed', '', provider, f'{type(e).__name__}: {e}'[:250]


def process_requests(conn, ini, now):
    """Выполнить ожидающие запросы «проанализировать»."""
    done = 0
    with conn.cursor() as cur:
        cur.execute("SELECT * FROM anomaly_requests WHERE status = 'pending' ORDER BY id LIMIT 5")
        reqs = cur.fetchall()
        for r in reqs:
            cur.execute("UPDATE anomaly_requests SET status = 'running', started_at = NOW() WHERE id = %s", (r['id'],))
            cur.execute("SELECT * FROM anomaly_watchers WHERE id = %s", (r['watcher_id'],))
            w = cur.fetchone()
            if not w:
                cur.execute("UPDATE anomaly_requests SET status='failed', error='карточка удалена', finished_at=NOW() WHERE id=%s", (r['id'],))
                continue

            text, pfrom, pto, n_samples, n_events = build_summary(conn, w, now)
            if text is None:
                cur.execute("UPDATE anomaly_requests SET status='failed', error='нет собранных данных', finished_at=NOW() WHERE id=%s", (r['id'],))
                logger.warning('запрос %s: нет данных по карточке %s', r['id'], w['name'])
                continue

            prompt = (r['prompt'] or w['prompt'] or '').strip()
            status, response, provider, error = ask_ai(text, prompt, ini, w)
            cur.execute("""
                INSERT INTO anomaly_reports
                    (watcher_id, request_id, provider, model, period_from, period_to,
                     samples_used, events_used, summary, response, status, error)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (w['id'], r['id'], provider, w['ai_model'] or '', pfrom, pto,
                  n_samples, n_events, text, response, status, error or None))
            cur.execute("UPDATE anomaly_requests SET status = %s, error = %s, finished_at = NOW() WHERE id = %s",
                        ('done' if status != 'failed' else 'failed', error or None, r['id']))
            cur.execute("UPDATE anomaly_watchers SET last_report_at = NOW() WHERE id = %s", (w['id'],))
            logger.info('запрос %s по карточке «%s»: %s', r['id'], w['name'], status)
            done += 1
    return done


# ----------------------------------------------------------------------------- основной цикл

def main():
    setup_logging()
    global INI
    ini = load_ini()
    INI = ini
    try:
        conn = db_connect()
    except Exception as e:
        logger.error('нет подключения к БД: %s', e)
        sys.exit(1)
    logger.info('iot_anomaly запущен')

    while True:
        try:
            now = datetime.now()
            conn.ping(reconnect=True)
            n_new = collect_samples(conn, now)
            n_events = analyse(conn, now)
            n_reports = process_requests(conn, ini, now)
            if n_new or n_events or n_reports:
                logger.info('цикл: точек +%s, аномалий +%s, отчётов %s', n_new, n_events, n_reports)
        except Exception as e:
            logger.error('ошибка цикла: %s: %s', type(e).__name__, e)
        time.sleep(LOOP_SECONDS)


if __name__ == '__main__':
    main()
