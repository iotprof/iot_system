#!/bin/bash
source /etc/iot/credentials.env

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/tmp/backup_$DATE"
FINAL_BACKUP="/home/mazzick/backup_smart_home_$DATE.tar.gz"

mkdir -p "$BACKUP_DIR"
cd "$BACKUP_DIR" || exit

echo "📦 Начинаем бэкап RPi 5 (mazzick)..."

# 1. MariaDB/MySQL
if command -v mysqldump &> /dev/null; then
    echo "💾 Бэкап MariaDB..."
    mysqldump -u "$IOT_DB_ADMIN_USER" -p"$IOT_DB_ADMIN_PASS" --all-databases > mysql_backup.sql 2>/dev/null || echo "⚠️  MySQL: пропускаем (нет пароля)"
fi

# 2. Zigbee2MQTT (ПРАВИЛЬНЫЙ ПУТЬ - /home/mazzick/zigbee2mqtt)
echo "📡 Бэкап Zigbee2MQTT..."
if [ -d "/home/mazzick/zigbee2mqtt" ]; then
    cp -r /home/mazzick/zigbee2mqtt ./zigbee2mqtt
    # Сохраняем список установленных npm-пакетов
    cd /home/mazzick/zigbee2mqtt && npm list --depth=0 > /tmp/npm_packages.txt 2>/dev/null
    cp /tmp/npm_packages.txt ./zigbee2mqtt/ 2>/dev/null
    cd "$BACKUP_DIR" || exit
    echo "✅ Zigbee2MQTT скопирован"
else
    echo "❌ Zigbee2MQTT не найден в /home/mazzick/zigbee2mqtt"
fi

# 3. Mosquitto
echo "📨 Бэкап Mosquitto..."
mkdir -p ./mosquitto
[ -f /etc/mosquitto/mosquitto.conf ] && cp /etc/mosquitto/mosquitto.conf ./mosquitto/
[ -f /etc/mosquitto/passwd ] && cp /etc/mosquitto/passwd ./mosquitto/
[ -f /etc/mosquitto/acl ] && cp /etc/mosquitto/acl ./mosquitto/
echo "✅ Mosquitto скопирован"

# 4. Веб-файлы (/var/www)
echo "🌐 Бэкап веб-файлов..."
if [ -d "/var/www" ]; then
    cp -r /var/www ./www
    echo "✅ /var/www скопирован"
else
    echo "❌ /var/www не найден"
fi

# 5. Nginx и Apache конфиги
echo "⚙️  Бэкап конфигов веб-серверов..."
mkdir -p ./etc_configs
[ -d /etc/nginx ] && cp -r /etc/nginx ./etc_configs/
[ -d /etc/apache2 ] && cp -r /etc/apache2 ./etc_configs/
echo "✅ Конфиги веб-серверов скопированы"

# 6. Systemd-сервисы (ВАЖНО!)
echo "⚙️  Бэкап systemd-сервисов..."
mkdir -p ./systemd_services
[ -f /etc/systemd/system/zigbee2mqtt.service ] && cp /etc/systemd/system/zigbee2mqtt.service ./systemd_services/
[ -f /etc/systemd/system/mosquitto.service ] && cp /etc/systemd/system/mosquitto.service ./systemd_services/
# Копируем все пользовательские сервисы
ls /etc/systemd/system/*.service 2>/dev/null | grep -v "syslog\|dbus\|systemd" | xargs -I {} cp {} ./systemd_services/ 2>/dev/null
echo "✅ Systemd-сервисы скопированы"

# 7. Cron-задачи
echo "⏰ Бэкап Cron..."
mkdir -p ./cron_backups
crontab -l > ./cron_backups/crontab_mazzick.txt 2>/dev/null || echo "# Нет задач cron для mazzick" > ./cron_backups/crontab_mazzick.txt
sudo crontab -l > ./cron_backups/crontab_root.txt 2>/dev/null || echo "# Нет задач cron для root" > ./cron_backups/crontab_root.txt
[ -f /etc/crontab ] && cp /etc/crontab ./cron_backups/
[ -d /etc/cron.d ] && cp -r /etc/cron.d ./cron_backups/ 2>/dev/null
[ -d /etc/cron.hourly ] && cp -r /etc/cron.hourly ./cron_backups/ 2>/dev/null
[ -d /etc/cron.daily ] && cp -r /etc/cron.daily ./cron_backups/ 2>/dev/null
echo "✅ Cron-задачи скопированы"

# 8. Списки установленных пакетов
echo "📦 Бэкап списков пакетов..."
dpkg --get-selections | grep -v deinstall > packages.txt
pip3 list --format=freeze > pip_packages.txt 2>/dev/null || echo "# Нет pip" > pip_packages.txt
# NPM-пакеты (глобальные)
npm list -g --depth=0 > npm_global_packages.txt 2>/dev/null || echo "# Нет npm" > npm_global_packages.txt
echo "✅ Списки пакетов сохранены"

# 9. Домашние конфиги пользователя
echo "🏠 Бэкап пользовательских конфигов..."
mkdir -p ./home_configs
[ -d /home/mazzick/.config ] && cp -r /home/mazzick/.config ./home_configs/ 2>/dev/null
[ -f /home/mazzick/.bashrc ] && cp /home/mazzick/.bashrc ./home_configs/
[ -f /home/mazzick/.profile ] && cp /home/mazzick/.profile ./home_configs/
[ -f /home/mazzick/.bash_aliases ] && cp /home/mazzick/.bash_aliases ./home_configs/ 2>/dev/null
echo "✅ Пользовательские конфиги скопированы"

# 10. Node-RED (если есть)
if [ -d /home/mazzick/.node-red ]; then
    echo "🔴 Бэкап Node-RED..."
    mkdir -p ./nodered
    cp -r /home/mazzick/.node-red/flows_*.json ./nodered/ 2>/dev/null
    cp /home/mazzick/.node-red/settings.js ./nodered/ 2>/dev/null
    cp /home/mazzick/.node-red/package.json ./nodered/ 2>/dev/null
    echo "✅ Node-RED скопирован"
fi

# 11. Дополнительно: сетевые настройки (БЕЗ hostname!)
echo "🌐 Бэкап сетевых настроек..."
mkdir -p ./network
[ -f /etc/dhcpcd.conf ] && cp /etc/dhcpcd.conf ./network/
[ -f /etc/wpa_supplicant/wpa_supplicant.conf ] && cp /etc/wpa_supplicant/wpa_supplicant.conf ./network/
[ -d /etc/netplan ] && cp -r /etc/netplan ./network/ 2>/dev/null
echo "✅ Сетевые настройки скопированы"

# Архивируем
echo "📦 Создание архива..."
cd /tmp || exit
tar -czf "$FINAL_BACKUP" "backup_$DATE" 2>/dev/null
rm -rf "$BACKUP_DIR"

echo ""
echo "=========================================="
echo "✅ Бэкап сохранён: $FINAL_BACKUP"
echo "📊 Размер: $(du -h "$FINAL_BACKUP" | cut -f1)"
echo "=========================================="
echo ""
echo "📋 Содержимое бэкапа:"
tar -tzf "$FINAL_BACKUP" | head -20
echo "..."
echo "=========================================="
