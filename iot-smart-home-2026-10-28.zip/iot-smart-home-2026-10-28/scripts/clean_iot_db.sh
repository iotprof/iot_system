#!/bin/bash
source /etc/iot/credentials.env
# Очистка данных старше 1 часа из sensor_data

# ИСПРАВЛЕНО 29.09.2026: нужен только DELETE в sensor_data — хватит учётки приложения.
MYSQL_USER="$IOT_DB_USER"
MYSQL_PASS="$IOT_DB_PASS"
MYSQL_DB="iot_db"

echo "[$(date)] Начинаем очистку..."

# Проверяем текущее количество строк
BEFORE=$(mysql -u "$MYSQL_USER" -p"$MYSQL_PASS" -sN -e "
USE $MYSQL_DB;
SELECT COUNT(*) FROM sensor_data;
")

echo "До очистки: $BEFORE строк"

# Удаляем старые данные
mysql -u "$MYSQL_USER" -p"$MYSQL_PASS" -e "
USE $MYSQL_DB;
DELETE FROM sensor_data WHERE timestamp < NOW() - INTERVAL 1 HOUR;
"

# Проверяем результат
AFTER=$(mysql -u "$MYSQL_USER" -p"$MYSQL_PASS" -sN -e "
USE $MYSQL_DB;
SELECT COUNT(*) FROM sensor_data;
")

DELETED=$((BEFORE - AFTER))

echo "После очистки: $AFTER строк"
echo "Удалено: $DELETED строк"
echo "[$(date)] Очистка завершена"
