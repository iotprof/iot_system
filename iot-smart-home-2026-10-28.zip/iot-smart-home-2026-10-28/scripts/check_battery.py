#!/home/mazzick/venv/bin/python3
"""Проверка элементов питания Zigbee-устройств (cron, раз в сутки).

ПОЧЕМУ ПЕРЕПИСАН
Старый вариант падал в логе с "Access denied for user 'iot_user'": он ходил в
базу под учёткой iot_user, а пароли давно вынесены в /etc/iot/credentials.env.
Плюс он сравнивал процент с одним порогом 11 % для всех устройств подряд, не
различая CR2032 (3,0 В) и 4xAA (6,0 В) — и заодно считал бы «розетку» с 218 В
батарейкой, если бы у неё был топик battery.

ТЕПЕРЬ
Пороги берутся из той же таблицы battery_spec, что использует веб-панель:
одна логика — один ответ на вопрос «пора менять или нет». Учитываются и процент,
и напряжение (берётся худший из двух сигналов), и флаг battery_low от устройства,
и молчание дольше 3 суток.

Письмо уходит только когда состояние изменилось — иначе это ежедневный спам
одинаковым текстом, который через неделю улетает в спам-папку.
"""
import json
import os
import subprocess
import sys
from datetime import datetime

import pymysql

ENV_FILE = '/etc/iot/credentials.env'
STATE_FILE = '/home/mazzick/.battery_state.json'
EMAIL_TO = ['user@example.com', 'it@example.com']
EMAIL_FROM = 'it@example.com'
STALE_DAYS = 3          # молчание дольше — «нет связи»
RESEND_DAYS = 7         # не повторять одно и то же письмо чаще, чем раз в неделю

STATE_LABEL = {
    'dead': 'ВЫШЛА ИЗ СТРОЯ',
    'replace': 'ПОРА МЕНЯТЬ',
    'stale': 'НЕТ СВЯЗИ',
    'unknown': 'НЕТ ДАННЫХ',
    'ok': 'в норме',
}
RANK = {'dead': 0, 'replace': 1, 'stale': 2, 'unknown': 3, 'ok': 4}


def log(msg):
    print('%s %s' % (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), msg), flush=True)


def read_env(path=ENV_FILE):
    """Читаем /etc/iot/credentials.env (права 640 root:mazzick — скрипт от mazzick)."""
    conf = {}
    try:
        with open(path, encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#') or '=' not in line:
                    continue
                key, val = line.split('=', 1)
                conf[key.strip()] = val.strip().strip('"').strip("'")
    except OSError as exc:
        log('ОШИБКА: не могу прочитать %s (%s)' % (path, exc))
    return conf


def collect(conn):
    """Состояние каждого устройства из справочника battery_spec."""
    with conn.cursor(pymysql.cursors.DictCursor) as cur:
        cur.execute("""SELECT device, title, room, battery_type, cells, nominal_v,
                              warn_v, dead_v, warn_pct, dead_pct, has_voltage
                       FROM battery_spec WHERE active = 1 ORDER BY sort_order, device""")
        specs = cur.fetchall()
        if not specs:
            return []

        # Последнее значение по каждому нужному топику
        topics = []
        for s in specs:
            topics.append('zigbee2mqtt/%s/battery' % s['device'])
            topics.append('zigbee2mqtt/%s/battery_low' % s['device'])
            if int(s['has_voltage']):
                topics.append('zigbee2mqtt/%s/voltage' % s['device'])
        placeholders = ','.join(['%s'] * len(topics))
        cur.execute("SELECT topic, value, timestamp FROM sensor_data WHERE topic IN (%s)" % placeholders, topics)
        live = {r['topic']: r for r in cur.fetchall()}

        # Свежесть: самое новое сообщение по устройству вообще
        cur.execute("""SELECT topic, MAX(timestamp) AS t FROM sensor_data
                       WHERE topic LIKE 'zigbee2mqtt/%%' GROUP BY topic""")
        fresh = {}
        for r in cur.fetchall():
            parts = r['topic'].split('/')
            if len(parts) < 3:
                continue
            dev = parts[1]
            if dev not in fresh or r['t'] > fresh[dev]:
                fresh[dev] = r['t']

    now = datetime.now()
    out = []
    for s in specs:
        dev = s['device']
        batt = live.get('zigbee2mqtt/%s/battery' % dev)
        volt = live.get('zigbee2mqtt/%s/voltage' % dev)
        low = live.get('zigbee2mqtt/%s/battery_low' % dev)

        pct = None
        if batt and batt['value'] not in (None, ''):
            try:
                pct = float(batt['value'])
            except (TypeError, ValueError):
                pct = None

        mv = None
        if int(s['has_voltage']) and volt and volt['value'] not in (None, ''):
            try:
                v = float(volt['value'])
            except (TypeError, ValueError):
                v = 0
            # Меньше 1000 — это не милливольты батарейки: не считаем.
            if v >= 1000:
                mv = v

        low_flag = bool(low) and str(low['value']) == '1'

        seen = fresh.get(dev)
        stale_days = None
        if seen:
            stale_days = (now - seen).total_seconds() / 86400.0

        warn_v = float(s['warn_v']) if s['warn_v'] is not None else None
        dead_v = float(s['dead_v']) if s['dead_v'] is not None else None
        warn_p = float(s['warn_pct']) if s['warn_pct'] is not None else 20.0
        dead_p = float(s['dead_pct']) if s['dead_pct'] is not None else 5.0

        # ВАЖНО О ЕДИНИЦАХ. Пороги в battery_spec — в ВОЛЬТАХ (2.70), а с
        # устройства voltage приходит в МИЛЛИВОЛЬТАХ (2700). Без перевода
        # сравнение "2500 <= 2.70" даёт ложь и разряженный элемент молча
        # попадёт в «в норме».
        warn_mv = warn_v * 1000 if warn_v is not None else None
        dead_mv = dead_v * 1000 if dead_v is not None else None

        state, reason = 'ok', ''
        if low_flag:
            state, reason = 'dead', 'устройство само сообщает «батарея разряжена»'
        elif mv is not None and dead_mv is not None and mv <= dead_mv:
            state, reason = 'dead', 'напряжение %.0f мВ не выше предела %.2f В' % (mv, dead_v)
        elif pct is not None and pct <= dead_p:
            state, reason = 'dead', 'заряд %.1f %% не выше %.0f %%' % (pct, dead_p)
        elif mv is not None and warn_mv is not None and mv <= warn_mv:
            state, reason = 'replace', 'напряжение %.0f мВ дошло до порога %.2f В' % (mv, warn_v)
        elif pct is not None and pct <= warn_p:
            state, reason = 'replace', 'заряд %.1f %% дошёл до порога %.0f %%' % (pct, warn_p)
        elif pct is None and mv is None:
            state, reason = 'unknown', 'устройство не отдаёт ни заряда, ни напряжения'

        if state != 'dead':
            if seen is None:
                state, reason = 'unknown', 'устройства нет в базе значений'
            elif stale_days is not None and stale_days > STALE_DAYS:
                state = 'stale'
                reason = 'нет данных %d дн. — цифры устарели' % int(round(stale_days))

        parts = []
        if int(s['cells'] or 0):
            parts.append('%s x%s' % (s['battery_type'], int(s['cells'])))
        else:
            parts.append(str(s['battery_type']))
        if s['nominal_v'] is not None:
            parts.append('%.1f В' % float(s['nominal_v']))

        out.append({
            'device': dev,
            'title': s['title'] or dev,
            'element': ' '.join(parts),
            'pct': pct,
            'mv': mv,
            'state': state,
            'reason': reason,
            'stale_days': round(stale_days, 1) if stale_days is not None else None,
            'seen': seen.strftime('%Y-%m-%d %H:%M') if seen else None,
            '_rank': RANK.get(state, 9),
        })

    out.sort(key=lambda r: (r['_rank'], r['pct'] if r['pct'] is not None else 999, r['device']))
    return out


def render(rows):
    """Текст письма: сначала то, что требует действия."""
    problems = [r for r in rows if r['state'] in ('dead', 'replace')]
    stale = [r for r in rows if r['state'] == 'stale']
    unknown = [r for r in rows if r['state'] == 'unknown']
    ok = [r for r in rows if r['state'] == 'ok']

    lines = []
    lines.append('Проверка элементов питания. Устройств в справочнике: %d.' % len(rows))
    lines.append('')
    if problems:
        lines.append('ТРЕБУЕТ ДЕЙСТВИЯ (%d):' % len(problems))
        for r in problems:
            num = []
            if r['pct'] is not None:
                num.append('%.1f %%' % r['pct'])
            if r['mv'] is not None:
                num.append('%.0f мВ' % r['mv'])
            lines.append('  [%s] %s — %s (%s)' % (
                STATE_LABEL[r['state']], r['title'], ', '.join(num) or 'без цифр', r['reason']))
            lines.append('       элемент: %s' % r['element'])
        lines.append('')
    if stale:
        lines.append('НЕТ СВЯЗИ (%d) — молчат дольше %d суток:' % (len(stale), STALE_DAYS))
        for r in stale:
            lines.append('  %s — %s' % (r['title'], r['reason']))
        lines.append('')
    if unknown:
        lines.append('НЕТ ДАННЫХ (%d):' % len(unknown))
        for r in unknown:
            lines.append('  %s — %s' % (r['title'], r['reason']))
        lines.append('')
    if ok:
        lines.append('В НОРМЕ (%d):' % len(ok))
        for r in ok:
            num = []
            if r['pct'] is not None:
                num.append('%.1f %%' % r['pct'])
            if r['mv'] is not None:
                num.append('%.0f мВ' % r['mv'])
            lines.append('  %s — %s' % (r['title'], ', '.join(num) or 'без цифр'))
        lines.append('')
    lines.append('Полная таблица с порогами и историей напряжений: панель -> Батарейки.')
    lines.append('Пороги берутся из таблицы battery_spec (элементы разные: CR2032 3,0 В, 2xAAA 3,0 В, 4xAA 6,0 В).')
    return '\n'.join(lines)


def send_mail(subject, body):
    """Отправка письма. Сначала msmtp (он в этом доме уже настроен), затем
    локальный sendmail, затем smtplib на localhost."""
    msg = 'From: %s\nTo: %s\nSubject: %s\nDate: %s\n\n%s\n' % (
        EMAIL_FROM, ', '.join(EMAIL_TO), subject,
        datetime.now().strftime('%a, %d %b %Y %H:%M:%S %z'), body)

    for cmd in (['msmtp'] + EMAIL_TO, ['/usr/sbin/sendmail', '-t', '-i']):
        try:
            proc = subprocess.run(cmd, input=msg.encode('utf-8'),
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        except (OSError, subprocess.SubprocessError):
            continue
        if proc.returncode == 0:
            log('письмо отправлено через %s' % cmd[0])
            return True
        log('%s вернул ошибку: %s' % (cmd[0], proc.stderr.decode('utf-8', 'replace').strip()[:300]))

    try:
        import smtplib
        from email.message import EmailMessage
        em = EmailMessage()
        em.set_content(body)
        em['Subject'] = subject
        em['From'] = EMAIL_FROM
        em['To'] = ', '.join(EMAIL_TO)
        with smtplib.SMTP('localhost', timeout=30) as srv:
            srv.send_message(em)
        log('письмо отправлено через smtplib/localhost')
        return True
    except Exception as exc:
        log('ОШИБКА отправки письма: %s' % exc)
        return False


def load_state():
    try:
        with open(STATE_FILE, encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_state(data):
    try:
        with open(STATE_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
    except OSError as exc:
        log('не могу сохранить состояние: %s' % exc)


def main():
    env = read_env()
    if not env.get('IOT_DB_USER') or not env.get('IOT_DB_PASS'):
        log('ОШИБКА: в %s нет IOT_DB_USER/IOT_DB_PASS' % ENV_FILE)
        return 2

    try:
        conn = pymysql.connect(host=env.get('IOT_DB_HOST', '127.0.0.1'),
                               user=env['IOT_DB_USER'], password=env['IOT_DB_PASS'],
                               database=env.get('IOT_DB_NAME', 'iot_db'),
                               charset='utf8mb4', cursorclass=pymysql.cursors.DictCursor)
    except Exception as exc:
        log('ОШИБКА подключения к базе: %s' % exc)
        return 2

    try:
        rows = collect(conn)
    finally:
        conn.close()

    if not rows:
        log('справочник battery_spec пуст — проверять нечего')
        return 0

    counts = {}
    for r in rows:
        counts[r['state']] = counts.get(r['state'], 0) + 1
    log('состояния: %s' % ', '.join('%s=%d' % (k, v) for k, v in sorted(counts.items())))

    problems = [r for r in rows if r['state'] in ('dead', 'replace')]
    signature = ';'.join('%s:%s' % (r['device'], r['state']) for r in rows)

    state = load_state()
    prev_sig = state.get('signature')
    last_sent = state.get('last_sent')

    should_send = False
    why = ''
    if problems and signature != prev_sig:
        should_send = True
        why = 'состояние изменилось'
    elif problems and last_sent:
        try:
            days = (datetime.now() - datetime.fromisoformat(last_sent)).total_seconds() / 86400.0
        except ValueError:
            days = 999
        if days >= RESEND_DAYS:
            should_send = True
            why = 'прошло %.0f дн с прошлого письма, проблема не устранена' % days

    if should_send:
        subject = 'Батарейки: %s' % ', '.join(
            '%s %d' % (STATE_LABEL[r['state']].lower(), counts.get(r['state'], 0))
            for r in rows if r['state'] in ('dead', 'replace'))
        if send_mail(subject, render(rows)):
            last_sent = datetime.now().isoformat(timespec='seconds')
            log('письмо: %s (%s)' % (subject, why))
        else:
            log('письмо не ушло, состояние не сохраняю — попробуем в следующий раз')
            return 1
    else:
        if problems:
            log('проблемы есть, но состояние не менялось и письмо уходило недавно — молчу')
        else:
            log('требующих действия устройств нет — письмо не нужно')

    save_state({'signature': signature, 'last_sent': last_sent,
                'checked_at': datetime.now().isoformat(timespec='seconds'),
                'counts': counts})
    return 0


if __name__ == '__main__':
    sys.exit(main())
