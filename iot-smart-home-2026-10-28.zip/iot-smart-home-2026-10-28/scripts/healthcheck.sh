#!/bin/bash
# healthcheck.sh — проверки умного дома. Запуск:  bash healthcheck.sh
# База опрашивается без пароля (креды из ~/.my.cnf).
# Полная проверка входа в панель — только если задан IOT_PANEL_PASSWORD.
M="mysql iot_db -N -e"
SRV=/var/www/html/iot/public_html
fails=0

ok()  { echo "  [OK]   $1"; }
bad() { echo "  [FAIL] $1"; fails=$((fails+1)); }

chk() { # chk "описание" "команда" "ожидаемая подстрока"
  local out
  out=$(eval "$2" 2>&1)
  if echo "$out" | grep -q "$3"; then ok "$1"; else bad "$1 -> $(echo "$out" | head -2 | tr '\n' ' ')"; fi
}

echo "=== 1. службы ==="
for s in iot-automation mqtt-to-mysql iot-anomaly mosquitto zigbee2mqtt mariadb nginx; do
  chk "$s активна" "systemctl is-active $s" "^active$"
done
for s in iot-automation mqtt-to-mysql iot-anomaly; do
  nr=$(systemctl show $s -p NRestarts --value 2>/dev/null)
  [ "${nr:-0}" -eq 0 ] && ok "$s: перезапусков не было" || bad "$s: перезапусков $nr (падала и поднималась)"
done

echo "=== 2. данные идут ==="
fresh=$($M "SELECT COUNT(*) FROM sensor_data WHERE timestamp > NOW() - INTERVAL 5 MINUTE;" 2>/dev/null)
[ "${fresh:-0}" -gt 0 ] && ok "свежих значений за 5 мин: $fresh" || bad "нет свежих значений в sensor_data за 5 минут"
topics=$($M "SELECT COUNT(DISTINCT topic) FROM sensor_data;" 2>/dev/null)
[ "${topics:-0}" -gt 50 ] && ok "топиков в базе: $topics" || bad "подозрительно мало топиков: ${topics:-нет ответа}"

echo "=== 3. модуль аномалий ==="
# Модуль аномалий может быть выключен сознательно: нет ключа нейросети, поэтому
# в /etc/iot/credentials.ini стоит [ai] enabled = 0, а карточки наблюдения —
# enabled = 0. Это НЕ поломка, и писать про это письмо каждый час нельзя:
# одинаковое «ПРОБЛЕМЫ (2)» через неделю уходит в спам вместе с настоящими.
# Считаем модуль выключенным только если ВЫКЛЮЧЕНЫ И карточки, И нейросеть;
# если карточки есть, а точек нет — это настоящая поломка, и [FAIL] остаётся.
ai_on=$($M "SELECT 1;" >/dev/null 2>&1; grep -A6 '^\[ai\]' /etc/iot/credentials.ini 2>/dev/null | grep -m1 '^enabled' | tr -d ' ' | cut -d= -f2)
wch=$($M "SELECT COUNT(*) FROM anomaly_watchers WHERE enabled = 1;" 2>/dev/null)
if [ "${wch:-0}" -eq 0 ] && [ "${ai_on:-0}" != "1" ]; then
  echo "  [SKIP] модуль аномалий выключен сознательно ([ai] enabled = 0, активных карточек 0)"
  echo "         включить: секция [ai] в /etc/iot/credentials.ini (нужен ключ) и enabled = 1 у карточки"
else
  pts=$($M "SELECT COUNT(*) FROM anomaly_samples WHERE taken_at > NOW() - INTERVAL 10 MINUTE;" 2>/dev/null)
  [ "${pts:-0}" -gt 0 ] && ok "точки аномалий собираются (за 10 мин: $pts)" || bad "точки аномалий не собираются"
  [ "${wch:-0}" -gt 0 ] && ok "карточек наблюдения активно: $wch" || bad "нет включённых карточек наблюдения"
fi
pend=$($M "SELECT COUNT(*) FROM anomaly_requests WHERE status = 'pending';" 2>/dev/null)
[ "${pend:-0}" -eq 0 ] && ok "очередь запросов к нейросети пуста" || bad "запросов в очереди: $pend (сервис не выполняет?)"
# ложные срабатывания: события при неизменных данных
false_pos=$($M "SELECT COUNT(*) FROM anomaly_events e WHERE e.detected_at > NOW() - INTERVAL 1 DAY
                AND e.kind = 'spike' AND ABS(e.value - e.baseline) <= 3;" 2>/dev/null)
[ "${false_pos:-0}" -eq 0 ] && ok "ложных выбросов за сутки нет" || bad "подозрительных выбросов за сутки: $false_pos (порог слишком узкий?)"

echo "=== 4. ошибки в журналах (только от текущего процесса) ==="
# Смотрим не «за 30 минут», а от текущего процесса службы: иначе в отчёт попадает шум
# от прошлых версий кода и уже удалённых тестовых правил.
for u in iot-automation mqtt-to-mysql iot-anomaly; do
  pid=$(systemctl show $u -p MainPID --value 2>/dev/null)
  if [ -z "$pid" ] || [ "$pid" = "0" ]; then
    bad "$u: нет главного процесса"
    continue
  fi
  up=$(systemctl show $u -p ActiveEnterTimestamp --value 2>/dev/null)
  n=$(journalctl _PID=$pid --since "15 min ago" --no-pager 2>/dev/null | grep -icE "fatal error|traceback|uncaught|compilation failed")
  if [ "$n" -eq 0 ]; then
    ok "$u: серьёзных ошибок с момента старта нет (pid $pid, с $up)"
  else
    bad "$u: $n серьёзных ошибок у текущего процесса (pid $pid)"
  fi
done
pid=$(systemctl show iot-automation -p MainPID --value 2>/dev/null)
sc=$(journalctl _PID=$pid --since "15 min ago" --no-pager 2>/dev/null | grep -c "Недопустимые символы\|вызовы функций\|Запрещённая функция")
if [ "${sc:-0}" -eq 0 ]; then
  ok "кривых скриптовых условий нет"
else
  bad "скриптовых условий с жалобами: $sc (проверить правила с condition_type=script)"
fi

echo "=== 5. дубли и следы триггера в журнале автоматизаций ==="
dup=$($M "SELECT COUNT(*) FROM (SELECT 1 FROM automation_log WHERE triggered_at > NOW()-INTERVAL 1 HOUR GROUP BY triggered_at, rule_name HAVING COUNT(*)>1) t;" 2>/dev/null)
[ "${dup:-1}" -eq 0 ] && ok "дублей за час нет" || bad "дублей строк за час: $dup (вернулся триггер after_automation_update?)"
orph=$($M "SELECT COUNT(*) FROM automation_log WHERE rule_id IS NULL;" 2>/dev/null)
[ "${orph:-1}" -eq 0 ] && ok "строк без rule_id нет" || bad "строк без rule_id: $orph"

echo "=== 6. секреты не в коде ==="
# ИСПРАВЛЕНО 29.09.2026: раньше пароль был НАПИСАН ПРЯМО ЗДЕСЬ (пусть и по кусочкам) — файл читается
# обычным пользователем, то есть проверка «нет ли паролей в коде» сама была утечкой.
# Теперь искомые строки берутся из /etc/iot/credentials.env (640 root:mazzick) и на экран не печатаются.
PTMP=$(mktemp)
grep -E '^IOT_(DB_PASS|DB_ADMIN_PASS|MQTT_PASS|SMTP_PASS)=' /etc/iot/credentials.env 2>/dev/null \
  | cut -d= -f2- | grep -v '^$' > "$PTMP"
leak=$(grep -rlI -F -f "$PTMP" /var/www/html/iot /home/mazzick \
        --include=*.php --include=*.py --include=*.sh 2>/dev/null \
        | grep -v cleanup | grep -v przorka_backup | grep -v healthcheck.sh | wc -l)
rm -f "$PTMP"
[ "${leak:-1}" -eq 0 ] && ok "паролей в коде нет" || bad "файлов с паролями: $leak"
[ -f /etc/iot/credentials.ini ] && ok "конфиг секретов на месте" || bad "нет /etc/iot/credentials.ini"
perm=$(stat -c '%a %U:%G' /etc/iot/credentials.ini 2>/dev/null)
[ "$perm" = "640 root:www-data" ] && ok "права конфига: $perm" || bad "права конфига: $perm (ожидалось 640 root:www-data)"

echo "=== 7. рост логов ==="
sz=$(stat -c%s /home/mazzick/mqtt_logger.log 2>/dev/null || echo 0)
[ "$sz" -lt 1048576 ] && ok "mqtt_logger.log = $sz байт" || bad "mqtt_logger.log = $((sz/1024/1024)) МБ (логгер пишет каждое сообщение?)"
sz=$(stat -c%s /home/mazzick/iot_anomaly.log 2>/dev/null || echo 0)
[ "$sz" -lt 5242880 ] && ok "iot_anomaly.log = $((sz/1024)) КБ" || bad "iot_anomaly.log = $((sz/1024/1024)) МБ"
for f in /etc/logrotate.d/mqtt-logger /etc/logrotate.d/iot-logs /etc/logrotate.d/iot-home; do
  [ -f "$f" ] && ok "logrotate: $(basename $f)" || bad "нет $f"
done

echo "=== 8. код и доступ ==="
for f in mqtt_listener.php anomalies.php; do
  php -l $SRV/admin/$f >/dev/null 2>&1 && ok "$f: синтаксис ок" || bad "$f: ошибка синтаксиса"
done
grep -q 'logging.debug(f"📥 Получено' $SRV/admin/mqtt_to_mysql.py 2>/dev/null && ok "логгер молчит на каждое сообщение" || bad "логгер пишет INFO на каждое сообщение"
c_login=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1/admin/sensors.php)
[ "$c_login" = "200" ] && ok "страница входа отвечает 200" || bad "страница входа отвечает $c_login"
c_prot=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1/admin/anomalies.php)
[ "$c_prot" = "302" ] && ok "админка закрыта сессией (302) и PHP не падает" || bad "админка отвечает $c_prot (ожидалось 302)"
if [ -n "${IOT_PANEL_PASSWORD:-}" ]; then
  J=$(mktemp); curl -s -c $J -b $J -o /dev/null --data-urlencode "username=${IOT_PANEL_USER:-mazzick}" \
       --data-urlencode "password=$IOT_PANEL_PASSWORD" http://127.0.0.1/admin/sensors.php
  c_full=$(curl -s -b $J -o /dev/null -w '%{http_code}' http://127.0.0.1/admin/anomalies.php)
  rm -f $J
  [ "$c_full" = "200" ] && ok "полный вход в панель работает" || bad "вход в панель: страница аномалий отдаёт $c_full"
else
  ok "полная проверка входа пропущена (IOT_PANEL_PASSWORD не задан)"
fi
for f in /admin/mqtt_to_mysql.py /admin/sensors.bak /crontab_root.txt; do
  code=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1$f)
  [ "$code" = "403" ] && ok "$f закрыт" || bad "$f отдаётся как $code"
done
chk "mosquitto слушает только локально" "ss -lnt | grep ':1883'" "127.0.0.1:1883"

echo "=== 9. сторож и диск ==="
cron_ok=$(crontab -l 2>/dev/null | grep -c iot_watchdog)
[ "${cron_ok:-0}" -gt 0 ] && ok "сторож стоит в cron (раз в час)" || bad "нет задания iot_watchdog в cron"
[ -f /home/mazzick/iot_watchdog.log ] && ok "лог сторожа на месте" || bad "нет /home/mazzick/iot_watchdog.log"
use=$(df / | awk 'NR==2{print $5}' | tr -d '%')
[ "$use" -lt 85 ] && ok "диск занят на $use%" || bad "диск занят на $use%"
ju=$(journalctl --disk-usage 2>/dev/null | grep -oE '[0-9.]+[MG]' | head -1)
ok "журнал systemd: $ju"

echo "=== 10. батарейки ==="
# Логика и пороги — в include/battery_lib.php + таблица battery_spec.
# Отдельного письма отсюда нет: про разряженные элементы пишет check_battery.py,
# второе письмо о том же было бы дублем.
bat=$(php -r "require '/var/www/html/iot/config/iot_config.php'; require '/var/www/html/iot/public_html/include/battery_lib.php'; \$r=iot_battery_status(iot_pdo()); \$c=iot_battery_counts(\$r); echo \$c['total'].' '.\$c['dead'].' '.\$c['replace'].' '.\$c['stale'].' '.\$c['unknown']; " 2>/dev/null)
set -- $bat
bt_total=${1:-0}; bt_dead=${2:-0}; bt_repl=${3:-0}; bt_stale=${4:-0}; bt_unk=${5:-0}
if [ "${bt_total:-0}" -eq 0 ]; then
  bad "справочник battery_spec пуст или battery_lib.php не отвечает"
else
  if [ "${bt_dead:-0}" -gt 0 ]; then
    bad "батарейки: вышли из строя $bt_dead (письмо уходит утром; см. /admin/batteries.php)"
  else
    ok "батарейки: вышли из строя 0"
  fi
  ok "батарейки: пора менять $bt_repl, нет связи $bt_stale, без данных $bt_unk, всего устройств $bt_total"
fi
sc=$($M "SELECT COUNT(*) FROM sensor_history WHERE timestamp > NOW() - INTERVAL 1 DAY AND (topic LIKE 'zigbee2mqtt/%/battery' OR topic LIKE 'zigbee2mqtt/%/voltage');" 2>/dev/null)
[ "${sc:-0}" -gt 0 ] && ok "история напряжений батареек копится (точек за сутки: $sc)" || ok "история батареек: точек за сутки пока нет (батарейные топики приходят редко)"

echo
echo "ИТОГ: ошибок $fails"
[ "$fails" -eq 0 ] && echo "ЗДОРОВ" || echo "ЕСТЬ ПРОБЛЕМЫ — см. FAIL выше"
exit $fails
