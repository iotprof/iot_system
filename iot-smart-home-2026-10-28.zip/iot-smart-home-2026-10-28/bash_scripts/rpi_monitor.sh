#!/bin/bash
source /etc/iot/credentials.env
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

# Конфигурация
# ИСПРАВЛЕНО 29.09.2026: скрипту нужно только INSERT в iot_db — ходим учёткой приложения,
# а не администратором базы (принцип «минимум прав»).
MYSQL_USER="$IOT_DB_USER"
MYSQL_PASS="$IOT_DB_PASS"
MYSQL_DB="iot_db"
MQTT_TOPIC="homeassistant/rpi_monitor"
MQTT_HOST="localhost"

# Получаем данные о системе

# Температура NVMe (через smartctl)
NVME_TEMP="N/A"
if command -v smartctl &> /dev/null; then
  TEMP_VAL=$(sudo smartctl -a /dev/nvme0n1 2>/dev/null | grep "^Temperature:" | awk '{print $2}')
  if [[ -n "$TEMP_VAL" && "$TEMP_VAL" =~ ^[0-9]+$ ]]; then
    NVME_TEMP="$TEMP_VAL"
  fi
fi

# Температура CPU
CPU_TEMP=$(vcgencmd measure_temp | cut -d= -f2 | cut -d\' -f1)
[ -z "$CPU_TEMP" ] && CPU_TEMP=$(cat /sys/class/thermal/thermal_zone0/temp | awk '{print $1/1000}')

# Напряжение ядра
VOLT_CORE=$(vcgencmd measure_volts core 2>/dev/null | cut -d= -f2 | tr -d 'V')
[ -z "$VOLT_CORE" ] && VOLT_CORE="N/A"

# Загрузка CPU
CPU_LOAD=$(top -bn1 | grep "Cpu(s)" | sed "s/.*, *\([0-9.]*\)%* id.*/\1/" | awk '{print 100 - $1}')

# Использование памяти
MEM_TOTAL=$(free -m | awk '/Mem:/ {print $2}')
MEM_USED=$(free -m | awk '/Mem:/ {print $3}')
MEM_PERCENT=$(free | awk '/Mem:/ {printf("%.1f"), $3/$2*100}')

# Использование диска
DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}' | tr -d '%')

# Uptime системы
UPTIME=$(uptime -p)

# IP-адреса
IP_ADDRESSES=$(hostname -I | tr '\n' ' ')


# ===== СКОРОСТЬ ВЕНТИЛЯТОРА =====
FAN_SPEED="N/A"

if [ -f /sys/class/thermal/cooling_device0/cur_state ]; then
    CUR_STATE=$(cat /sys/class/thermal/cooling_device0/cur_state 2>/dev/null)
    MAX_STATE=$(cat /sys/class/thermal/cooling_device0/max_state 2>/dev/null)
    
    if [[ -n "$CUR_STATE" && -n "$MAX_STATE" && "$MAX_STATE" -gt 0 ]]; then
        FAN_PERCENT=$((CUR_STATE * 100 / MAX_STATE))
        FAN_SPEED="${FAN_PERCENT}%"
    fi
fi

# Формируем JSON для MQTT
JSON_DATA=$(jq -n \
  --arg cpu_temp "$CPU_TEMP" \
  --arg cpu_load "$CPU_LOAD" \
  --arg mem_total "$MEM_TOTAL" \
  --arg mem_used "$MEM_USED" \
  --arg mem_percent "$MEM_PERCENT" \
  --arg disk_usage "$DISK_USAGE" \
  --arg uptime "$UPTIME" \
  --arg ip_addresses "$IP_ADDRESSES" \
  --arg volt_core "$VOLT_CORE" \
  --arg nvme_temp "$NVME_TEMP" \
  --arg fan_speed "$FAN_SPEED" \
  '{
    "cpu_temp": $cpu_temp,
    "cpu_load": $cpu_load,
    "mem_total": $mem_total,
    "mem_used": $mem_used,
    "mem_percent": $mem_percent,
    "disk_usage": $disk_usage,
    "uptime": $uptime,
    "ip_addresses": $ip_addresses,
    "volt_core": $volt_core,
    "nvme_temp": $nvme_temp,
    "fan_speed": $fan_speed,
    "timestamp": now | todate
  }'
)

# Отправляем в MQTT
# Публикуем с логином и паролем: брокер требует авторизацию (анонимный вход закрыт 12.10.2026)
if [ -n "$IOT_MQTT_USER" ]; then
  mosquitto_pub -h "$MQTT_HOST" -p "${IOT_MQTT_PORT:-1883}" -u "$IOT_MQTT_USER" -P "$IOT_MQTT_PASS" \
                -t "$MQTT_TOPIC" -m "$JSON_DATA" || echo "MQTT: публикация не удалась" >&2
else
  echo "MQTT: нет учётных данных в /etc/iot/credentials.env, публикация пропущена" >&2
fi

# Записываем в MySQL (нужно добавить колонку fan_speed)
mysql -u $MYSQL_USER -p"$MYSQL_PASS" $MYSQL_DB <<EOF
INSERT INTO rpi_monitor (
  cpu_temp, cpu_load, mem_total, mem_used, mem_percent,
  disk_usage, volt_core, uptime, ip_addresses, nvme_temp, fan_speed, timestamp
) VALUES (
  '$CPU_TEMP', '$CPU_LOAD', '$MEM_TOTAL', '$MEM_USED', '$MEM_PERCENT',
  '$DISK_USAGE', '$VOLT_CORE', '$UPTIME', '$IP_ADDRESSES', '$NVME_TEMP', '$FAN_SPEED', NOW()
);
EOF
