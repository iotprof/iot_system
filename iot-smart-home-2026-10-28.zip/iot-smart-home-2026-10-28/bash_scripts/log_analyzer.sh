#!/bin/bash
source /etc/iot/credentials.env

# ИСПРАВЛЕНО 29.09.2026: нужны только DELETE/INSERT в log_stats — хватит учётки приложения.
MYSQL_USER="$IOT_DB_USER"
MYSQL_PASS="$IOT_DB_PASS"
MYSQL_DB="iot_db"
DATE=$(date '+%Y-%m-%d')

KEYWORDS=("error" "failed" "denied" "warning" "reboot")
EXCLUDE="cachedData is not defined"

mysql -u "$MYSQL_USER" -p"$MYSQL_PASS" "$MYSQL_DB" -e "DELETE FROM log_stats WHERE date = '$DATE';"

LOGS_TODAY=$(journalctl --since today --no-pager)

for KEYWORD in "${KEYWORDS[@]}"; do
    if [ "$KEYWORD" = "error" ]; then
        # Исключаем cachedData ошибку
        COUNT=$(echo "$LOGS_TODAY" | grep -i "$KEYWORD" | grep -v "$EXCLUDE" | wc -l)
    else
        COUNT=$(echo "$LOGS_TODAY" | grep -i "$KEYWORD" | wc -l)
    fi
    
    mysql -u "$MYSQL_USER" -p"$MYSQL_PASS" "$MYSQL_DB" -e "
    INSERT INTO log_stats (keyword, count, date) VALUES ('$KEYWORD', $COUNT, '$DATE');
    "
done
