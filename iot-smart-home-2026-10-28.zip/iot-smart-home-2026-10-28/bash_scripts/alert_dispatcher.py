#!/home/mazzick/venv/bin/python3

import os
import pymysql
import smtplib
import json
import sys
from email.message import EmailMessage

# === НАСТРОЙКИ ===
DB_CONFIG = {
    'host': 'localhost',
    'user': os.environ.get('IOT_DB_ADMIN_USER', 'mazzick'),
    'password': os.environ.get('IOT_DB_ADMIN_PASS'),
    'database': 'iot_db',
    'charset': 'utf8mb4'
}


ALERT_TOPIC = 'zigbee2mqtt/_alerts/email'
EMAIL_TO_DEFAULT = "user@example.com"

def fetch_and_delete_alerts():
    """Получает все сообщения из топика уведомлений и удаляет их."""
    conn = pymysql.connect(**DB_CONFIG)
    try:
        with conn.cursor() as cursor:
            # Получаем все записи
            cursor.execute("""
                SELECT id, value FROM sensor_data
                WHERE topic = %s
                ORDER BY id ASC
            """, (ALERT_TOPIC,))
            rows = cursor.fetchall()

            if not rows:
                return []

            # Безопасное удаление по списку ID (параметризованный запрос)
            ids = [row[0] for row in rows]
            format_strings = ','.join(['%s'] * len(ids))
            cursor.execute(
                f"DELETE FROM sensor_data WHERE id IN ({format_strings})",
                ids
            )
            conn.commit()
            print(f"📨 Обработаны уведомления с ID: {ids}", file=sys.stderr)
            return [row[1] for row in rows]

    finally:
        conn.close()

def send_email(subject, body, to=None):
    msg = EmailMessage()
    msg.set_content(body)
    msg["Subject"] = subject
    msg["From"] = "it@example.com"
    msg["To"] = to or EMAIL_TO_DEFAULT

    try:
        with smtplib.SMTP("smtp.mail.ru", 587) as s:
            s.starttls()
            s.login(os.environ.get("IOT_SMTP_USER", "it@example.com"), os.environ.get("IOT_SMTP_PASS"))
            s.send_message(msg)
        print(f"✅ Email отправлен: {subject}")
    except Exception as e:
        print(f"❌ Ошибка SMTP: {e}", file=sys.stderr)


def main():
    alerts = fetch_and_delete_alerts()
    if not alerts:
        print("📭 Нет новых уведомлений")
        return

    for payload in alerts:
        try:
            data = json.loads(payload)
            subject = data.get("subject", "Уведомление IoT")
            body = data.get("body", payload)
            to = data.get("to")
        except (json.JSONDecodeError, TypeError):
            subject = "🚨 Уведомление из IoT"
            body = str(payload)
            to = None

        send_email(subject, body, to)

if __name__ == "__main__":
    main()
